package com.robot.taskmanager.mongo.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.robot.taskmanager.mongo.dao.StatisticDaoImpl;
import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.mongo.vo.StatisticsSearch;

public class StatisticDaoTest {
	
//	@Test
//	public void testTask(){
//		Task rawTask = new Task();
//		rawTask.setCategory("a");
//		rawTask.setTaskId("123456");
//		rawTask.setCreatetime("2016-08-10T10:28:00.409Z");
//		rawTask.setPriority(1);
//		rawTask.setStatus(0);
//		rawTask.setContent("{\"imo\":\"9457622\"}");
//		System.out.println(rawTask.toString());
//	}
	
	@Test
	public void testFindGeneralStatistic() throws ParseException{
		DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date myDate2 = dateFormat2.parse("2010-09-13 22:36:01");
		System.out.println(myDate2);

		StatisticsSearch search = new StatisticsSearch();
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date fromDate = dateFormat1.parse("2016-09-22 08:01:03");
		Date toDate = dateFormat1.parse("2016-09-22 09:40:03");
		search.setFromDate(fromDate);
		search.setToDate(toDate);
//		search.setStatus("success");//success,fail,waiting
		StatisticDaoImpl dao = new StatisticDaoImpl();
		List<Task> tasks = dao.findGeneralStatistic(search);
		System.out.println(tasks.size());
		for(Task task:tasks){
			System.out.println(task.getTaskId());
		}
		
	}
	
//	@Test
	public void testFindDetailStatistic() throws ParseException{
		DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date myDate2 = dateFormat2.parse("2010-09-13 22:36:01");
		System.out.println(myDate2);

		StatisticsSearch search = new StatisticsSearch();
		DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date fromDate = dateFormat1.parse("2016-09-22 08:01:03");
		Date toDate = dateFormat1.parse("2016-09-22 09:40:03");
		search.setFromDate(fromDate);
		search.setToDate(toDate);
//		search.setStatus("success");//success,fail,waiting
		search.setCategory("\"category\":\"AB\"");
		StatisticDaoImpl dao = new StatisticDaoImpl();
		List<Task> tasks = dao.findDetailStatistic(search);
		System.out.println(tasks.size());
		for(Task task:tasks){
			System.out.println(task.getTaskId());
		}
		
	}
}
