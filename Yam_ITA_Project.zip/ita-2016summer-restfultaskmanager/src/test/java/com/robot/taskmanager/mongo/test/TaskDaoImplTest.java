package com.robot.taskmanager.mongo.test;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.robot.taskmanager.mongo.dao.TaskDao;
import com.robot.taskmanager.mongo.dao.TaskDaoImpl;
import com.robot.taskmanager.mongo.dao.TaskITranslatedDao;
import com.robot.taskmanager.mongo.dao.TaskITranslatedDaoImpl;
import com.robot.taskmanager.mongo.model.TaskITranslated;
import com.robot.taskmanager.util.DateUtil;

public class TaskDaoImplTest {

	static TaskDao dao;
	static TaskITranslatedDao translatedDao;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		dao = new TaskDaoImpl();
		translatedDao = new TaskITranslatedDaoImpl();
	}

	@Test
	public void test() {
//		Map<String, Object> map = new HashMap<>();
//		map.put("priority", 0);
//		map.put("projectOwner", "swindy1234567");
//		dao.findByFilter(map);
//		Date startTime = DateUtil.toDate("20160922000000", "yyyyMMddHHmmss");
//		System.out.println(startTime);
//		Date endTime = DateUtil.toDate("20160923000000", "yyyyMMddHHmmss");
//		System.out.println(endTime);
//		dao.findByTime(startTime,null);
//		
		System.out.println(translatedDao.findById("20160922094057_AB"));
		
	}

}
