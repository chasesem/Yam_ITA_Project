package com.robot.taskmanager.mongo.test;

import org.junit.Test;

import com.robot.taskmanager.mongo.model.Task;

public class TaskTest {
	
//	@Test
//	public void testTask(){
//		Task rawTask = new Task();
//		rawTask.setCategory("a");
//		rawTask.setTaskId("123456");
//		rawTask.setCreatetime("2016-08-10T10:28:00.409Z");
//		rawTask.setPriority(1);
//		rawTask.setStatus(0);
//		rawTask.setContent("{\"imo\":\"9457622\"}");
//		System.out.println(rawTask.toString());
//	}

}
