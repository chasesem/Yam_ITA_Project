package com.robot.taskmanager.mongo.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.robot.taskmanager.model.Account;
import com.robot.taskmanager.mongo.dao.AccountDao;
import com.robot.taskmanager.mongo.dao.AccoutImpl;

public class AccoutImplTest {
    AccountDao adao=new AccoutImpl();
    Account user=new Account();
	@Before
	public void setUp() throws Exception {
	}

//	@Test
//	public void testLogin() {
//		fail("Not yet implemented");
//	}

	@Test
	public void testRegister() {
		user.setPassWord("123456");
		user.setUserName("yam");
		adao.register(user);
	}

}
