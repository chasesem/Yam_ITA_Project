//package com.robot.taskmanager.mongo.test;
//
//import java.util.List;
//
//import org.junit.Test;
//
//import com.robot.taskmanager.mongo.dao.RawTaskDaoImpl;
//import com.robot.taskmanager.mongo.model.RawTask;
//
//public class RawTasDaoImplTest {
//	
//	@Test
//	public void testDao(){
//		RawTaskDaoImpl rawTaskDaoImpl = new RawTaskDaoImpl();
//		List<RawTask> rawTasks = rawTaskDaoImpl.findAll();
//		for(RawTask rawTask:rawTasks){
//			System.out.println(rawTask.toString());
//		}
//	}
//	
//	//@Test
//	public void testInsert(){
//		RawTaskDaoImpl rawTaskDaoImpl = new RawTaskDaoImpl();
//		RawTask rawTask = new RawTask();
//		rawTask.setTaskId("123456");
//		rawTask.setContent("465446546874dufhisafhsafhisadfisa");
//		rawTask.setPriority(1);
//		rawTaskDaoImpl.insert(rawTask);
//	}
//
//	
//}
