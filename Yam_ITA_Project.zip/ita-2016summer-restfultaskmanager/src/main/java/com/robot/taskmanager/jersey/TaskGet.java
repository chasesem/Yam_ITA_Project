package com.robot.taskmanager.jersey;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.robot.taskmanager.mongo.dao.TaskDao;
import com.robot.taskmanager.mongo.dao.TaskDaoImpl;
import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.util.JSONUtil;

@Path("/tasks")
public class TaskGet {
	
//	private final static Logger logger = LogManager.getLogger(TaskGet.class);
	
	private TaskDao taskDao;
	
	public TaskGet(){
		taskDao = new TaskDaoImpl();
	}
	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllTasks(){
		List<Task> task = taskDao.findAll();
		Response rp=Response.ok(JSON.toJSONString(task))
				.header("Content-type","application/json")
				//.header("Access-Control-Allow-Origin", "http://127.0.0.1")
				.build();
		//return JSON.toJSONString(task);
		return rp;
	}
	
	@GET
	@Path("/quaryByID/{taskId}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getOneTaskById(@PathParam(value = "taskId") String taskId) throws JsonProcessingException{
		Task task = taskDao.findById(taskId);
		
		String json = JSONUtil.objetc2Json(task);
		return json;
	}
	
	@GET
	@Path("/first")
	@Produces(MediaType.APPLICATION_JSON)
	public String getFirstInTask() throws JsonProcessingException{
		Task task = taskDao.findFirst();
		String json = JSONUtil.objetc2Json(task);
		return json;
	}
	
	
	
	
}
