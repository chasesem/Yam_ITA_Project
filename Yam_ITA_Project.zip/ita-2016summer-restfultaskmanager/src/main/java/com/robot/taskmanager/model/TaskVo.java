package com.robot.taskmanager.model;

import java.util.Date;

import com.alibaba.fastjson.annotation.JSONField;

public class TaskVo {
	private String taskId;
	private String projectOwner;
	private String taskType;
	private String taskContent;
	private String taskStatus;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date taskCreateTime;
	@JSONField(format = "yyyy-MM-dd HH:mm:ss")
	private Date lastUpdateTime;
	private int reprocesTimes;
	private String sender;
	private int priority;
	private String hostName;
	private String ref;
	private int length;

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getProjectOwner() {
		return projectOwner;
	}

	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getTaskContent() {
		return taskContent;
	}

	public void setTaskContent(String taskContent) {
		this.taskContent = taskContent;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public Date getTaskCreateTime() {
		return taskCreateTime;
	}

	public void setTaskCreateTime(Date taskCreateTime) {
		this.taskCreateTime = taskCreateTime;
	}

	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public int getReprocesTimes() {
		return reprocesTimes;
	}

	public void setReprocesTimes(int reprocesTimes) {
		this.reprocesTimes = reprocesTimes;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public TaskVo() {

	}
}
