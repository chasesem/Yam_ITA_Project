package com.robot.taskmanager.mongo.dao;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.model.Account;
import com.robot.taskmanager.mongo.model.TaskITranslated;

public class AccoutImpl extends BasicDao implements AccountDao{
	private final static String TABLE_NAME = "Account";
	MongoCollection<Document> collection;
	public AccoutImpl(){
		super();
		collection =getDataBase().getCollection(TABLE_NAME);
	}

	@Override
	public Account login(String userName) {
		Document document = collection.find(eq("userName", userName)).first();
		return  toAccount(document);
		// TODO Auto-generated method stub	
	}
	private Account toAccount(Document document) {
		Account  user= new Account();
		if (document != null) {
			user.setPassWord(document.getString("passWork"));
		    user.setUserName(document.getString("userName"));
			return user;
		}
		return null;
	}
	public Document toDocument(Account user) {
		Document document = new Document();
		document.append("userName", user.getUserName());
		document.append("passWork", user.getPassWord());
		return document;
	}

	@Override
	public boolean register(Account user) {
		// TODO Auto-generated method stub
		Document document = toDocument(user);
		System.out.println(document);
		try {
			collection.insertOne(document);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		
		
	}

}
