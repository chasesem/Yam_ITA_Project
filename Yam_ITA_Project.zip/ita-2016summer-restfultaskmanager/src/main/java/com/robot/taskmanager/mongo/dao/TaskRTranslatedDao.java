package com.robot.taskmanager.mongo.dao;

import java.util.Date;
import java.util.List;

import com.robot.taskmanager.mongo.model.TaskRTranslated;


public interface TaskRTranslatedDao {
	
	List<TaskRTranslated> findAll();
	List<TaskRTranslated> findByAttribute(String key,String value);
	List<TaskRTranslated> findByTimeByAttributes(Date time,String key,String value);
	TaskRTranslated findById(String taskId);
	void  insert(TaskRTranslated TaskRTranslated);
	void update(TaskRTranslated TaskRTranslated);

}
