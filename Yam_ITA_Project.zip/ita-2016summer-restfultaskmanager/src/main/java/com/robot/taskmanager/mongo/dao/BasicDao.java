package com.robot.taskmanager.mongo.dao;

import com.mongodb.client.MongoDatabase;
import com.robot.taskmanager.mongo.core.DataSource;

public class BasicDao {
	private MongoDatabase dataBase;
	
	public BasicDao(){
		dataBase = DataSource.getInstance().getDatabase();
	}
	
	public MongoDatabase getDataBase(){
		return dataBase;
	}

	

}
