package com.robot.taskmanager.mongo.dao;

import com.robot.taskmanager.model.Account;

public interface AccountDao {
	public Account login(String userName);
	public boolean register(Account user);
}
