package com.robot.taskmanager.model;

import com.alibaba.fastjson.JSONObject;

public class Related {

	private String articleId;
	private String url;
	private String headline;

	public Related() {
		super();

	}

	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String toJSONString() {
		return JSONObject.toJSONString(this);
	}
}
