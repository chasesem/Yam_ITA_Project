package com.robot.taskmanager.jersey;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.robot.taskmanager.model.Account;
import com.robot.taskmanager.mongo.dao.AccountDao;
import com.robot.taskmanager.mongo.dao.AccoutImpl;
import com.robot.taskmanager.mongo.dao.TaskDao;
import com.robot.taskmanager.mongo.dao.TaskDaoImpl;
import com.robot.taskmanager.util.JSONUtil;
@Path("/accout")
public class AccoutJGet {
private AccountDao aDao;
	public AccoutJGet(){
		aDao = new AccoutImpl();
	}
	@GET
	@Path("/login/{userName}")
	@Produces(MediaType.APPLICATION_JSON)
	public String login(@PathParam(value="userName") String userName){
	Account user; 
	String userList = null ;
	try {
		user=aDao.login(userName);
		userList = JSONUtil.objetc2Json(user);
		System.out.println(userList);
	} catch (JsonParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (JsonMappingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return userList;
	}
}
