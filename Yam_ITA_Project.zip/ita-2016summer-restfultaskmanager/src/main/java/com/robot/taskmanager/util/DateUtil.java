package com.robot.taskmanager.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static Date toDate(String time , String format){
		SimpleDateFormat simpleDateFormat  = new SimpleDateFormat(format);
		try {
			return simpleDateFormat.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
