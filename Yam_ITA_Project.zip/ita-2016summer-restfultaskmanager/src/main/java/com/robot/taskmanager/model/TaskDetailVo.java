package com.robot.taskmanager.model;

import java.util.Date;

public class TaskDetailVo {
	private String taskId;
	private String proxyAddress;
	private String url;
	private String resultList;
	private Date startTime;
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public TaskDetailVo(){
		
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getProxyAddress() {
		return proxyAddress;
	}
	public void setProxyAddress(String proxyAddress) {
		this.proxyAddress = proxyAddress;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getResultList() {
		return resultList;
	}
	public void setResultList(String resultList) {
		this.resultList = resultList;
	}
	
}
