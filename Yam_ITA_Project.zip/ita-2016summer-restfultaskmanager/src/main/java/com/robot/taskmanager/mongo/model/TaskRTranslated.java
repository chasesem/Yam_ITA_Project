package com.robot.taskmanager.mongo.model;

import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

public class TaskRTranslated {
	private String rTranslatedTaskId;
	private String projectOwner;
	private String taskType;
	private String rTranslatedTaskResult;
	private String hostName;
	private String appId;
	@JSONField (format="yyyy-MM-dd HH:mm:ss")  
	private Date createTime;
	@JSONField (format="yyyy-MM-dd HH:mm:ss")  
	private Date lastUpdateTime;
	
	
	public String getrTranslatedTaskId() {
		return rTranslatedTaskId;
	}
	public void setrTranslatedTaskId(String rTranslatedTaskId) {
		this.rTranslatedTaskId = rTranslatedTaskId;
	}
	
	public String getProjectOwner() {
		return projectOwner;
	}
	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getrTranslatedTaskResult() {
		return rTranslatedTaskResult;
	}
	public void setrTranslatedTaskResult(String rTranslatedTaskResult) {
		this.rTranslatedTaskResult = rTranslatedTaskResult;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	public String toString(){
		return JSON.toJSONString(this).toString();
	}
}
