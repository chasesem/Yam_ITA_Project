package com.robot.taskmanager.mongo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.Document;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.robot.taskmanager.mongo.model.Task;

import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Updates.*;

public class TaskDaoImpl extends BasicDao implements TaskDao {

	// private final static Logger logger =
	// LogManager.getLogger(TaskDaoImpl.class);

	private final static String TABLE_NAME = "task";
	private final static String MONGODB_URL = "127.0.0.1";
	private final static String DB_NAME = "controller";
	private final static String TEST_NAME = "test";
	MongoCollection<Document> collection;

	MongoClient mongoClient;
	DB get_db_credit;
	DBCollection dbcollection;

	public TaskDaoImpl() {
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
		mongoClient = new MongoClient("10.222.232.40", 27017);
		get_db_credit = mongoClient.getDB("controller");
		dbcollection = get_db_credit.getCollection("task");
	}

	public void saveOrUpdate() {

	}

	public List<Task> findAll() {
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<Task> taskList = new ArrayList<Task>();
		for (Document document : documents) {
			taskList.add(toTask(document));
		}
		return taskList;
	}

	public Task findById(String taskId) {
		Document document = collection.find(eq("_id", taskId)).first();
		return toTask(document);
	}

	public Task findFirst() {
		Document document = collection.find(eq("taskStatus", Task.NEW)).sort(new BasicDBObject("priority", -1)).first();

		if (document != null) {
			Task task = toTask(document);
			task.setLastUpdateTime(new Date());
			task.setTaskStatus(Task.PROCESSING);
			update(task);
			return task;
		}
		return null;
	}

	public List<Task> findByAttribute(String key, String value) {
		List<Document> documents = collection.find().filter(eq(key, value)).into(new ArrayList<Document>());
		List<Task> taskList = new ArrayList<Task>();
		for (Document document : documents) {
			taskList.add(toTask(document));
		}
		return taskList;
	}

	public List<Task> findByTimeByAttributes(BasicDBObject query, Integer page, Integer sort, String sortBy ,Integer limit) {
		List<Document> documents = collection.find(query).limit(limit).sort(new BasicDBObject(sortBy, sort))
				.skip((page - 1) * 10).into(new ArrayList<Document>());
		List<Task> taskList = new ArrayList<Task>();
		for (Document document : documents) {
			taskList.add(toTask(document));
		}
		return taskList;
	}

	// public List<Task> findByTimeByAttributes(Date time,String key,String
	// value){
	// BasicDBObject query= new BasicDBObject();
	// query.put("lastUpdateTime", BasicDBObjectBuilder.start("$gt",
	// time).get());
	// query.put(key, value);
	// List<Document> documents = collection.find(query).into(new
	// ArrayList<Document>());
	// List<Task> taskList = new ArrayList<Task>();
	// for(Document document:documents){
	// taskList.add(toTask(document));
	// }
	// return taskList;
	// }

	public void insert(Task task) {
		ObjectMapper objectMapper=new ObjectMapper();
		System.out.println("!!!!!!!!!!!!@@@@@@@@@@@@@@@^^^^^^^^^^^^^");
		try {
			System.out.println(objectMapper.writeValueAsString(task));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Document document = toDocument(task);
		System.out.println(document);
		collection.insertOne(document);
	}

	public void update(Task task) {
		Document document = toDocument(task);
		collection.replaceOne(eq("_id", task.getTaskId()), document);
	}

	public void update(String taskId, String status) {
		collection.findOneAndUpdate(eq("_id", taskId), set("taskStatus", status));
	}

	public void delete(String task_id) {
		collection.deleteOne(eq("_id", task_id));  
	}

	private Document toDocument(Task task) {
		Document document = new Document();
		document.append("_id", task.getTaskId());
		document.append("projectOwner", task.getProjectOwner());
		document.append("taskType", task.getTaskType());
		document.append("taskContent", task.getTaskContent());
		document.append("taskStatus", task.getTaskStatus());
		document.append("taskCreateTime", task.getTaskCreateTime());
		document.append("lastUpdateTime", task.getLastUpdateTime());
		document.append("reprocessTimes", task.getReprocesTimes());
		document.append("sender", task.getSender());
		document.append("ref", task.getRef());
		document.append("priority", task.getPriority());
//		document.append("ref", task.getRef());
		return document;
	}

	private Task toTask(Document document) {
		Task task = new Task();
		if (document != null) {
			task.setTaskId(document.getString("_id"));
			task.setProjectOwner(document.getString("projectOwner"));
			task.setTaskType(document.getString("taskType"));
			task.setTaskContent(document.getString("taskContent"));
			task.setTaskStatus(document.getString("taskStatus"));
			task.setTaskCreateTime(document.getDate("taskCreateTime"));
			task.setLastUpdateTime(document.getDate("lastUpdateTime"));
			task.setReprocesTimes((Integer) document.get("reprocessTimes"));
			task.setSender(document.getString("sender"));
			task.setPriority(document.getInteger("priority"));
			task.setRef(document.getString("ref"));
			return task;
		}
		return null;
	}

	@Override
	public List<Task> findByFilter(Map<String, Object> map) {
		MongoClient mongoClient = new MongoClient("127.0.0.1", 27017);
		DB get_db_credit = mongoClient.getDB("controller");
		DBCollection dbcollection = get_db_credit.getCollection("test");

		BasicDBObject basicDBObject = new BasicDBObject();

		Set<String> keySet = map.keySet();
		for (String s : keySet) {
			basicDBObject.put(s, map.get(s));
		}
		DBCursor cursor = dbcollection.find(basicDBObject).limit(2).skip(2);
		List<DBObject> list = cursor.toArray();

		System.out.println(list.size());
		System.out.println(list.get(0).get("_id"));
		System.out.println(cursor.count());
		return null;
	}

	public List<Task> findByTime(Date startTime, Date endTime) {
		BasicDBObject query = new BasicDBObject();
		if (startTime != null)
			query.put("taskCreateTime", new BasicDBObject("$gte", startTime));
		if (endTime != null)
			query.put("taskCreateTime", new BasicDBObject("$lte", endTime));
		DBCursor cursor = dbcollection.find(query);
		List<DBObject> list = cursor.toArray();
		System.out.println(list.size());
		return null;
	}

	@Override
	public int findByTimeByAttributesCount(BasicDBObject query) {
		
//		List<Document> documents = collection.find(query).into(new ArrayList<Document>());
		return (int) collection.count(query);
	}

	@Override
	public boolean deleteMany(String key, String value) {
		// TODO Auto-generated method stub
		try {
			collection.deleteMany(Filters.eq(key, value));
			return true;
		
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		
	}

}
