package com.robot.taskmanager.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.robot.taskmanager.mongo.dao.TestDaoImpl;


@Path("hello")
public class Helloworld{
	@POST
	@Path("/hello")
	@Produces("text/plain")
	public String hello(String json){
		
		TestDaoImpl testDao = new TestDaoImpl();
		testDao.insert(json);
		return "helloworld";
	}
	@GET
	@Path("/getHello")
	@Produces("text/plain")
	public String getHello(){
		
		TestDaoImpl testDao = new TestDaoImpl();
		String task = testDao.findFirst();
		return "666"+task;
	}
}

