package com.robot.taskmanager.mongo.dao;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.mongo.model.TaskCaptured;

public class TaskCapturedDaoImpl extends BasicDao implements TaskCapturedDao {

	private final static String TABLE_NAME = "taskCaptured";
	MongoCollection<Document> collection;

	public TaskCapturedDaoImpl() {
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}

	public List<TaskCaptured> findAll() {
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<TaskCaptured> taskCapturedList = new ArrayList<TaskCaptured>();
		for (Document document : documents) {
			taskCapturedList.add(toTask(document));
		}
		return taskCapturedList;
	}

	public TaskCaptured findById(String taskId) {
		Document document = collection.find(eq("_id", taskId)).first();
		return toTask(document);
	}

	public List<TaskCaptured> findByAttribute(String key, String value) {
		List<Document> documents = collection.find().filter(eq(key, value)).into(new ArrayList<Document>());
		List<TaskCaptured> taskList = new ArrayList<TaskCaptured>();
		for (Document document : documents) {
			taskList.add(toTask(document));
		}
		return taskList;
	}

	public List<TaskCaptured> findByTimeByAttributes(Date time, String key, String value , Integer page) {
		BasicDBObject query = new BasicDBObject();
		query.put("lastUpdateTime", BasicDBObjectBuilder.start("$gt", time).get());
		query.put(key, value);
		List<Document> documents = collection.find(query).limit(10).skip((page-1)*10).into(new ArrayList<Document>());
		List<TaskCaptured> taskList = new ArrayList<TaskCaptured>();
		for (Document document : documents) {
			taskList.add(toTask(document));
		}
		return taskList;
	}

	public void insert(TaskCaptured taskCaptured) {
		Document document = toDocument(taskCaptured);
		collection.insertOne(document);
	}

	public void update(TaskCaptured taskCaptured) {
		Document document = toDocument(taskCaptured);
		collection.replaceOne(eq("_id", taskCaptured.getCapturedTaskId()), document);
	}

	public void delete(String taskCaptured_id) {
		collection.deleteOne(eq("_id", taskCaptured_id));
	}

	public Document toDocument(TaskCaptured task) {
		Document document = new Document();
		document.append("_id", task.getCapturedTaskId());
		document.append("projectOwner", task.getProjectOwner());
		document.append("taskType", task.getTaskType());
		document.append("capturedResult", task.getCapturedTaskResult());
		document.append("hostName", task.getHostName());
		document.append("appId", task.getAppId());
		document.append("createTime", task.getCreateTime());
		document.append("lastUpdateTime", task.getLastUpdateTime());
		return document;
	}

	public TaskCaptured toTask(Document document) {
		if (document != null) {
			TaskCaptured task = new TaskCaptured();
			task.setCapturedTaskId(document.getString("_id"));
			task.setProjectOwner(document.getString("projectOwner"));
			task.setTaskType(document.getString("taskType"));
			task.setCapturedTaskResult(document.getString("capturedResult"));
			task.setHostName(document.getString("hostName"));
			task.setAppId(document.getString("appId"));
			task.setCreateTime(document.getDate("createTime"));
			task.setLastUpdateTime(document.getDate("lastUpdateTime"));
			return task;
		}
		return null;
	}

}
