package com.robot.taskmanager.mongo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.Document;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.mongo.vo.StatisticsSearch;

public class StatisticDaoImpl extends BasicDao implements StatisticDao{
	private final static String TABLE_NAME = "task";
	MongoCollection<Document> collection;
	public StatisticDaoImpl(){
		collection = getDataBase().getCollection(TABLE_NAME);
	}
	public List<Task> findGeneralStatistic(StatisticsSearch search){
		BasicDBObject query=  new BasicDBObject();  
		query.put("taskCreateTime", new BasicDBObject("$gte", search.getFromDate()).append("$lte", search.getToDate()));
		BasicDBList statusList = new BasicDBList();
		if (search.getStatus()!=null && !search.getStatus().equals("")) {
			switch (search.getStatus()) {
			case "success":
				statusList.add(Task.R_TRANSLATED);
				break;
			case "fail":
				statusList.add(Task.I_TRANSLATED_FAIL);
				statusList.add(Task.CAPTURED_FAIL);
				statusList.add(Task.R_TRANSLATED_FAIL);
				break;
			case "waiting":
				statusList.add(Task.NEW);
				statusList.add(Task.RETRY);
				statusList.add(Task.PROCESSING);
				statusList.add(Task.REPROCESS);
				statusList.add(Task.CAPTURED);
				statusList.add(Task.CAPTUREING);
				statusList.add(Task.I_TRANSLATING);
				statusList.add(Task.I_TRANSLATED);
				statusList.add(Task.R_TRANSLATING);
				break;
			default:
				break;
			}
		}
		
		if (statusList.size()>0) {
			query.put("taskStatus", BasicDBObjectBuilder.start("$in", statusList).get());
		}
		System.out.println(search.getFromDate());
		List<Document> documents  = collection.find(query).into(new ArrayList<Document>());
		
		List<Task>  taskList = new ArrayList<Task>();
		for(Document document:documents){
			taskList.add(toTask(document));
		}
		return taskList;
	}
	
	public List<Task> findDetailStatistic(StatisticsSearch search){
		BasicDBObject query=  new BasicDBObject();
		System.out.println("---------------------");
		String category = "\"category\":\""+search.getCategory()+"\"";
		System.out.println(category);
		Pattern pattern = Pattern.compile(category, Pattern.CASE_INSENSITIVE);
		query.put("taskContent",pattern);
		query.put("taskCreateTime", new BasicDBObject("$gte", search.getFromDate()).append("$lte", search.getToDate()));
		List<Document> documents  = collection.find(query).sort(new BasicDBObject("taskCreateTime",1)).into(new ArrayList<Document>());
		List<Task>  taskList = new ArrayList<Task>();
		for(Document document:documents){
			taskList.add(toTask(document));
		}
		return taskList;
	}
	
	private Task toTask(Document document){
		Task task = new Task();
		task.setTaskId(document.getString("_id"));
		task.setProjectOwner(document.getString("projectOwner"));
		task.setTaskType(document.getString("taskType"));
		task.setTaskContent(document.getString("taskContent"));
		task.setTaskStatus(document.getString("taskStatus"));
		task.setTaskCreateTime(document.getDate("taskCreateTime"));
		task.setLastUpdateTime(document.getDate("lastUpdateTime"));
		task.setReprocesTimes((Integer)document.get("reprocessTimes"));
		task.setSender(document.getString("sender"));
		task.setPriority(document.getInteger("priority"));
		task.setRef(document.getString("ref"));
		return task;
	}
}
