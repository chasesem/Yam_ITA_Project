package com.robot.taskmanager.model;

public class TaskContent {
	private String category;
	private int withinHour;
	private String imo;
	private String callSign;
	private String NameOfShip;
	private String onCurrentName;
	private String mmsi;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getWithinHour() {
		return withinHour;
	}
	public void setWithinHour(int withinHour) {
		this.withinHour = withinHour;
	}
	public String getImo() {
		return imo;
	}
	public void setImo(String imo) {
		this.imo = imo;
	}
	public String getCallSign() {
		return callSign;
	}
	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}
	public String getNameOfShip() {
		return NameOfShip;
	}
	public void setNameOfShip(String nameOfShip) {
		NameOfShip = nameOfShip;
	}
	public String getOnCurrentName() {
		return onCurrentName;
	}
	public void setOnCurrentName(String onCurrentName) {
		this.onCurrentName = onCurrentName;
	}
	public String getMmsi() {
		return mmsi;
	}
	public void setMmsi(String mmsi) {
		this.mmsi = mmsi;
	}
	public TaskContent(){
		
	}
}
