package com.robot.taskmanager.mongo.dao;

public class TaskQueryDaoImpl extends BasicDao{
	
}
