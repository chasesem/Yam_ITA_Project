package com.robot.taskmanager.mongo.model;

import com.alibaba.fastjson.JSON;

public class JobContent {
	private String category;
	private String sender;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	
	public String toString(){
		return JSON.toJSONString(this);
	}

}
