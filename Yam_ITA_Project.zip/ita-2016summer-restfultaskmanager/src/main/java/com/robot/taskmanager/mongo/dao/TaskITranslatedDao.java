package com.robot.taskmanager.mongo.dao;

import java.util.Date;
import java.util.List;

import com.robot.taskmanager.mongo.model.TaskITranslated;

public interface TaskITranslatedDao {
	
	List<TaskITranslated> findAll();
	List<TaskITranslated> findByAttribute(String key,String value,Integer page, Integer limit);
	List<TaskITranslated> findByTimeByAttributes(Date time,String key,String value );
	TaskITranslated findById(String taskId);
	void  insert(TaskITranslated TaskITranslated);
	void update(TaskITranslated TaskITranslated);

}
