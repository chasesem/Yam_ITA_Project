package com.robot.taskmanager.mongo.dao;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.mongo.model.TaskRTranslated;

public class TaskRTranslatedDaoImpl extends BasicDao implements TaskRTranslatedDao{
	
	private final static String TABLE_NAME = "taskRTranslated";
	MongoCollection<Document> collection;
	public TaskRTranslatedDaoImpl(){
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}
	
	public void saveOrUpdate() {
		
	}
	
	public List<TaskRTranslated> findAll(){
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<TaskRTranslated>  taskRTranslatedList = new ArrayList<TaskRTranslated>();
		for(Document document:documents){
			taskRTranslatedList.add(toTask(document));
		}
		return taskRTranslatedList;
	}
	
	public TaskRTranslated findById(String taskId){
		Document document = collection.find(eq("_id",taskId)).first();
		return  toTask(document);
	}
	
	public TaskRTranslated findFirst(){
		Document document = collection.findOneAndUpdate(eq("status",0),set("status",1));
		if(document!=null)
			return toTask(document);
		return null;
	}
	
	public List<TaskRTranslated> findByAttribute(String key,String value ){
		List<Document> documents  = collection.find().filter(eq(key,value)).into(new ArrayList<Document>());
		List<TaskRTranslated>  taskList = new ArrayList<TaskRTranslated>();
		for(Document document:documents){
			taskList.add(toTask(document));
		}
		return taskList;
	}
	
	public List<TaskRTranslated> findByTimeByAttributes(Date time,String key,String value){
		BasicDBObject query=  new BasicDBObject();  
		query.put("lastUpdateTime", BasicDBObjectBuilder.start("$gt", time).get());  
		query.put(key, value);
		List<Document> documents  = collection.find(query).into(new ArrayList<Document>());
		List<TaskRTranslated>  taskList = new ArrayList<TaskRTranslated>();
		for(Document document:documents){
			taskList.add(toTask(document));
		}
		return taskList;
	}
	
	
	public void  insert(TaskRTranslated taskRTranslated){
		Document document = toDocument(taskRTranslated);
		collection.insertOne(document);
	}
	
	public void update(TaskRTranslated taskRTranslated){
		Document document = toDocument(taskRTranslated);
		collection.replaceOne(eq("_id",taskRTranslated.getrTranslatedTaskId()), document);
	}
	
	public void delete(String taskRTranslated_id){
		collection.deleteOne(eq("_id",taskRTranslated_id));
	}
	
	public Document toDocument(TaskRTranslated task){
		Document document = new Document();
		document.append("_id", task.getrTranslatedTaskId());
		document.append("projectOwner", task.getProjectOwner());
		document.append("taskType",task.getTaskType());
		document.append("rTranslatedTaskResult", task.getrTranslatedTaskResult());
		document.append("hostName", task.getHostName());
		document.append("appId", task.getAppId());
		document.append("createTime", task.getCreateTime());
		document.append("lastUpdateTime", task.getLastUpdateTime());
		return document;
	}
	
	public TaskRTranslated toTask(Document document){
		TaskRTranslated task = new TaskRTranslated();
		task.setrTranslatedTaskId(document.getString("_id"));
		task.setProjectOwner(document.getString("projectOwner"));
		task.setTaskType(document.getString("taskType"));
		task.setrTranslatedTaskResult(document.getString("rTranslatedTaskResult"));
		task.setHostName(document.getString("hostName"));
		task.setAppId(document.getString("appId"));
		task.setCreateTime(document.getDate("createTime"));
		task.setLastUpdateTime(document.getDate("lastUpdateTime"));
		return task;
	}

}
