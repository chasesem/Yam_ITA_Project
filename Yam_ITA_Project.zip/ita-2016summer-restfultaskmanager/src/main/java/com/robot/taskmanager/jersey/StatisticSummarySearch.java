package com.robot.taskmanager.jersey;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.alibaba.fastjson.JSON;
import com.robot.taskmanager.mongo.dao.StatisticDao;
import com.robot.taskmanager.mongo.dao.StatisticDaoImpl;
import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.mongo.vo.StatisticsSearch;

@Path("/statisticSearch")
public class StatisticSummarySearch {
	private StatisticDao statisticDao;
	public StatisticSummarySearch(){
		statisticDao = new StatisticDaoImpl();
	}
	
	@POST
	@Path("/generalStatistic")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String searchByGenearalStatistic(String search){
		System.out.println(search);
		StatisticsSearch statisticsSearch =JSON.parseObject(search,StatisticsSearch.class);
		System.out.println();
		List<Task> tasks = statisticDao.findGeneralStatistic(statisticsSearch);
		
		return JSON.toJSONString(tasks);
	}
	
	@POST
	@Path("/detailStatistic")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String searchByDetailStatistic(String search){
		System.out.println(search);
		StatisticsSearch statisticsSearch =JSON.parseObject(search,StatisticsSearch.class);
		List<Task> tasks = statisticDao.findDetailStatistic(statisticsSearch);
		return JSON.toJSONString(tasks);
	}
}
