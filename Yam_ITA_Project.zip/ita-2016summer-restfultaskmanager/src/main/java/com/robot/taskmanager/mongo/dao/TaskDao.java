package com.robot.taskmanager.mongo.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.mongodb.BasicDBObject;
import com.robot.taskmanager.mongo.model.Task;

public interface TaskDao {
	
	List<Task> findAll();
	List<Task> findByAttribute(String key,String value);
	List<Task> findByTimeByAttributes(BasicDBObject query, Integer page, Integer sort, String sortBy,Integer limit);
	Task findById(String taskId);
	Task findFirst();
	void  insert(Task Task);
	void update(Task Task);
	
	//session 2
	List<Task> findByFilter(Map<String, Object> map);
	
	List<Task> findByTime(Date startTime , Date endTime);
	int findByTimeByAttributesCount(BasicDBObject query);
	boolean deleteMany(String key,String value);
}
