package com.robot.taskmanager.mongo.dao;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.mongo.model.TaskITranslated;

public class TaskITranslatedDaoImpl extends BasicDao implements TaskITranslatedDao {

	private final static String TABLE_NAME = "taskITranslated";
	MongoCollection<Document> collection;

	public TaskITranslatedDaoImpl() {
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}

	public List<TaskITranslated> findAll() {
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<TaskITranslated> taskITranslatedList = new ArrayList<TaskITranslated>();
		for (Document document : documents) {
			taskITranslatedList.add(toTask(document));
		}
		return taskITranslatedList;
	}

	public TaskITranslated findById(String taskId) {
		Document document = collection.find(eq("_id", taskId)).first();
		return toTask(document);
	}

	public TaskITranslated findFirst() {
		Document document = collection.findOneAndUpdate(eq("status", 0), set("status", 1));

		if (document != null)
			return toTask(document);
		return null;
	}

	public List<TaskITranslated> findByAttribute(String key, String value ,Integer page) {
		List<Document> documents = collection.find().filter(eq(key, value)).limit(10).skip((page-1)*10).sort(new BasicDBObject("createTime",-1)).into(new ArrayList<Document>());
		List<TaskITranslated> taskList = new ArrayList<TaskITranslated>();
		for (Document document : documents) {
			taskList.add(toTask(document));limit
		}
		return taskList;
	}

	public List<TaskITranslated> findByTimeByAttributes(Date time, String key, String value) {
		BasicDBObject query = new BasicDBObject();
		query.put("lastUpdateTime", BasicDBObjectBuilder.start("$gt", time).get());
		query.put(key, value);
		List<Document> documents = collection.find(query).into(new ArrayList<Document>());
		List<TaskITranslated> taskList = new ArrayList<TaskITranslated>();
		for (Document document : documents) {
			taskList.add(toTask(document));
		}
		return taskList;
	}

	public void insert(TaskITranslated taskITranslated) {
		Document document = toDocument(taskITranslated);
		collection.insertOne(document);
	}

	public void update(TaskITranslated taskITranslated) {
		Document document = toDocument(taskITranslated);
		collection.replaceOne(eq("_id", taskITranslated.getiTranslatedTaskId()), document);
	}

	public void delete(String taskITranslated_id) {
		collection.deleteOne(eq("_id", taskITranslated_id));
	}

	public Document toDocument(TaskITranslated task) {
		Document document = new Document();
		document.append("_id", task.getiTranslatedTaskId());
		document.append("projectOwner", task.getProjectOwner());
		document.append("taskType", task.getTaskType());
		document.append("iTranslatedTaskResult", task.getiTranslatedTaskResult());
		document.append("hostName", task.getHostName());
		document.append("appId", task.getAppId());
		document.append("createTime", task.getCreateTime());
		document.append("lastUpdateTime", task.getLastUpdateTime());
		return document;
	}

	public TaskITranslated toTask(Document document) {
		TaskITranslated task = new TaskITranslated();
		if (document != null) {
			task.setiTranslatedTaskId(document.getString("_id"));
			task.setProjectOwner(document.getString("projectOwner"));
			task.setTaskType(document.getString("taskType"));
			task.setiTranslatedTaskResult(document.getString("iTranslatedTaskResult"));
			task.setHostName(document.getString("hostName"));
			task.setAppId(document.getString("appId"));
			task.setCreateTime(document.getDate("createTime"));
			task.setLastUpdateTime(document.getDate("lastUpdateTime"));
			return task;
		}
		return null;
	}

}
