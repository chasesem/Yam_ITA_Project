package com.robot.taskmanager.mongo.model;

import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

public class ScheduledJob {
	private String jobId;
	private String projectOwner;
	private String jobContent;
	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")  
	private Date JobCreateTime;
	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")   
	private Date jobLastUpdateTime;
	private String JobCreator;
	private String jobType;
	private String status;
	private String intervalTime;
	
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getProjectOwner() {
		return projectOwner;
	}
	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}
	public String getJobContent() {
		return jobContent;
	}
	public void setJobContent(String jobContent) {
		this.jobContent = jobContent;
	}
	
	public Date getJobCreateTime() {
		return JobCreateTime;
	}
	public void setJobCreateTime(Date jobCreateTime) {
		JobCreateTime = jobCreateTime;
	}
	public Date getJobLastUpdateTime() {
		return jobLastUpdateTime;
	}
	public void setJobLastUpdateTime(Date jobLastUpdateTime) {
		this.jobLastUpdateTime = jobLastUpdateTime;
	}
	public String getJobCreator() {
		return JobCreator;
	}
	public void setJobCreator(String jobCreator) {
		JobCreator = jobCreator;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIntervalTime() {
		return intervalTime;
	}
	public void setIntervalTime(String intervalTime) {
		this.intervalTime = intervalTime;
	}
	
	@JSONField(serialize=false) 
	public JobContent getjobContent(){
		return JSON.parseObject(jobContent, JobContent.class);
	}
	
	public String toString(){
		return JSON.toJSONString(this);
	}
	

}
