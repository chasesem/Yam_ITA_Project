package com.robot.taskmanager.jersey;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONException;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.robot.taskmanager.mongo.dao.TaskRTranslatedDaoImpl;
import com.robot.taskmanager.model.Article;
import com.robot.taskmanager.model.Result;
import com.robot.taskmanager.mongo.dao.TaskCapturedDaoImpl;
import com.robot.taskmanager.mongo.dao.TaskDaoImpl;
import com.robot.taskmanager.mongo.dao.TaskITranslatedDaoImpl;
import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.mongo.model.TaskCaptured;
import com.robot.taskmanager.mongo.model.TaskITranslated;
import com.robot.taskmanager.mongo.model.TaskRTranslated;



@Path("/save")
public class TaskSave {
	
	
	private TaskDaoImpl taskDaoImpl;
	public TaskSave(){
		taskDaoImpl = new TaskDaoImpl();
	}
	
	@POST
	@Path("/input")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String saveNew(String json) throws JSONException{
		Task task = JSON.parseObject(json, Task.class);
		Date date = new Date();
		task.setTaskCreateTime(date);
		task.setLastUpdateTime(date);
		task.setTaskStatus(Task.NEW);
		try{
			taskDaoImpl.insert(task);
		}catch(Exception e){
			
		}
		
		System.out.println("666"+json);
		return "{\"operation\":\"success\"}";
	}
	
	
	@POST
	@Path("/inputTranslated")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String saveInputTranslated(String json) throws JSONException{
		
		TaskITranslated taskITranslated = JSON.parseObject(json, TaskITranslated.class);
		Date date = new Date();
		taskITranslated.setCreateTime(date);
		taskITranslated.setLastUpdateTime(date);
		TaskITranslatedDaoImpl rawTaskDaoImpl = new TaskITranslatedDaoImpl();
		rawTaskDaoImpl.insert(taskITranslated);
		Task task = taskDaoImpl.findById(taskITranslated.getiTranslatedTaskId());
		task.setLastUpdateTime(new Date());
		task.setTaskStatus(Task.I_TRANSLATED);
		taskDaoImpl.update(task);
		System.out.println(json);
		return "{\"operation\":\"success\"}";
	}
	
	
	@POST
	@Path("/output")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String saveCaptured(String json) throws JSONException{
		TaskCaptured taskCaptured = JSON.parseObject(json, TaskCaptured.class);
		String taskId = taskCaptured.getCapturedTaskId();
		Date date = new Date();
		taskCaptured.setCreateTime(date);
		taskCaptured.setLastUpdateTime(date);
		TaskCapturedDaoImpl outputDaoImpl = new TaskCapturedDaoImpl();
		Result result = JSON.parseObject(taskCaptured.getCapturedTaskResult(), Result.class);
		if("CSNEWS".equals(taskCaptured.getProjectOwner())){
			List<Article> articleList = result.getArticles();
			Task task = taskDaoImpl.findById(taskCaptured.getCapturedTaskId());
			task.setLastUpdateTime(new Date());
			task.setTaskStatus(Task.CAPTURED);
			taskDaoImpl.update(task);
			for(Article article:articleList){
				taskCaptured.setCapturedTaskId(article.getSource()+article.getArticleId());
				taskCaptured.setCapturedTaskResult(article.toJSONString());
				try{
					outputDaoImpl.insert(taskCaptured);
				}catch(Exception e){
					
				}
				
			}
		}else{
			outputDaoImpl.insert(taskCaptured);
			Task task = taskDaoImpl.findById(taskCaptured.getCapturedTaskId());
			task.setLastUpdateTime(new Date());
			task.setTaskStatus(Task.CAPTURED);
			taskDaoImpl.update(task);
		}
		
		System.out.println(json);
		return "{\"operation\":\"success\"}";
	}
	
	@POST
	@Path("/outputTranslated")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String saveOutputTranslated(String json) throws JSONException{
		TaskRTranslated taskRTranslated = JSON.parseObject(json, TaskRTranslated.class);
		Date date = new Date();
		taskRTranslated.setCreateTime(date);
		taskRTranslated.setLastUpdateTime(date);
		TaskRTranslatedDaoImpl outputDaoImpl = new TaskRTranslatedDaoImpl();
		outputDaoImpl.insert(taskRTranslated);
		Task task = taskDaoImpl.findById(taskRTranslated.getrTranslatedTaskId());
		task.setLastUpdateTime(new Date());
		task.setTaskStatus(Task.R_TRANSLATED);
		taskDaoImpl.update(task);
		System.out.println(json);
		return "{\"operation\":\"success\"}";
	}
	
	@POST
	@Path("/update")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String updateTask(@FormParam("taskId") String taskId,@FormParam("taskStatus") String taskStatus){
		Task task = taskDaoImpl.findById(taskId);
		task.setLastUpdateTime(new Date());
		task.setTaskStatus(taskStatus);
		taskDaoImpl.update(task);
		return "{\"operation\":\"success\"}";
	}
	
	@POST
	@Path("/updateById")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateById(String temp){
	System.out.println("task***************"+temp);
	ObjectMapper oMapper=new ObjectMapper();
	Task task;
	try {
	task = oMapper.readValue(temp, Task.class);
	taskDaoImpl.update(task);
	return "{\"operation\":\"success\"}";
	} catch (JsonParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (JsonMappingException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	return "{\"operation\":\"fail\"}";
	}

}
