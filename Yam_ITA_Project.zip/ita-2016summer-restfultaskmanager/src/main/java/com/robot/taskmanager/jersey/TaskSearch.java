package com.robot.taskmanager.jersey;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.robot.taskmanager.model.SearchFilter;
import com.robot.taskmanager.model.TaskDetailVo;
import com.robot.taskmanager.model.TaskVo;
import com.robot.taskmanager.mongo.dao.ProfileDao;
import com.robot.taskmanager.mongo.dao.ProfileDaoImpl;
import com.robot.taskmanager.mongo.dao.TaskCapturedDao;
import com.robot.taskmanager.mongo.dao.TaskCapturedDaoImpl;
import com.robot.taskmanager.mongo.dao.TaskDao;
import com.robot.taskmanager.mongo.dao.TaskDaoImpl;
import com.robot.taskmanager.mongo.dao.TaskITranslatedDao;
import com.robot.taskmanager.mongo.dao.TaskITranslatedDaoImpl;
import com.robot.taskmanager.mongo.model.Profile;
import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.mongo.model.TaskCaptured;
import com.robot.taskmanager.mongo.model.TaskContent;
import com.robot.taskmanager.mongo.model.TaskITranslated;
import com.robot.taskmanager.util.DateUtil;
import com.robot.taskmanager.util.JSONUtil;

@Path("/search")
public class TaskSearch {

	private TaskDao taskDao;

	private TaskITranslatedDao taskITranslatedDao;
	private TaskCapturedDao taskCapturedDao;
	private ProfileDao profileDao;

	public TaskSearch() {
		taskDao = new TaskDaoImpl();
		taskITranslatedDao = new TaskITranslatedDaoImpl();
		profileDao = new ProfileDaoImpl();
		taskCapturedDao = new TaskCapturedDaoImpl();
	}

	@POST
	@Path("/task/attribute")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String searchByAttribute(String json)
			throws ParseException, JsonParseException, JsonMappingException, IOException {
		System.out.println(json);
		//多条件查询的 条件数组，json String转为Object
		SearchFilter searchFilter = (SearchFilter) JSONUtil.json2Object(json, SearchFilter.class);
		List<Task> taskList = new ArrayList<Task>();
		BasicDBObject query = new BasicDBObject();
		JSONObject object = JSONObject.parseObject(json);
		
		//判断时间是否为空,不为空则set进BasicDBObject中
		if (searchFilter.getStartTime() != null) {
//			Date startTime = DateUtil.toDate(searchFilter.getStartTime(), "yyyyMMddHHmmss.SSS");
//			Date endTime = DateUtil.toDate(searchFilter.getEndTime(), "yyyyMMddHHmmss.SSS");
//			query.put("taskCreateTime", new BasicDBObject("$gte", startTime).append("$lte", endTime));
			query.put("taskCreateTime", new BasicDBObject("$gte", object.getDate("startTime")).append("$lte", object.getDate("endTime")));

		}
		//判断输入的条件是否为空，不为空则set进basicdbObject中
		if (searchFilter.getKey() != null) {
			query.put(searchFilter.getKey(), searchFilter.getValue());
		}
		//判断条件是否为hostname 
		
		if (!"hostName".equals(searchFilter.getKey())) {
			List<TaskVo> lists = new ArrayList<>();
			taskList = taskDao.findByTimeByAttributes(query, searchFilter.getPage(), searchFilter.getSort(),
					searchFilter.getSortBy(),searchFilter.getLimit());
			int length = taskDao.findByTimeByAttributesCount(query);
			for (int i = 0; i < taskList.size(); i++) {
				String taskId = taskList.get(i).getTaskId();
				TaskITranslated translated = taskITranslatedDao.findById(taskId);
				TaskVo taskVo = new TaskVo();
				if (translated != null) {
					taskVo.setHostName(translated.getHostName());
				}
				taskVo.setLength(length);
				System.out.println(taskVo.getLength());
				taskVo.setLastUpdateTime(taskList.get(i).getLastUpdateTime());
				taskVo.setTaskId(taskId);
				taskVo.setPriority(taskList.get(i).getPriority());
				taskVo.setProjectOwner(taskList.get(i).getProjectOwner());
				taskVo.setReprocesTimes(taskList.get(i).getReprocesTimes());
				taskVo.setSender(taskList.get(i).getSender());
				taskVo.setTaskContent(taskList.get(i).getTaskContent());
				taskVo.setTaskCreateTime(taskList.get(i).getTaskCreateTime());
				taskVo.setTaskStatus(taskList.get(i).getTaskStatus());
				taskVo.setTaskType(taskList.get(i).getTaskType());
				taskVo.setRef(taskList.get(i).getRef());
				lists.add(taskVo);
			}
			if (lists.size() == 0) {
				System.out.println("no data");
				return null;
			}
			String temp = JSONUtil.objetc2Json(lists);
			System.out.println(temp);
			return temp;
		} else {
			query.put("createTime", new BasicDBObject("$gte", object.getDate("startTime")).append("$lte", object.getDate("endTime")));
			query.put(searchFilter.getKey(), searchFilter.getValue());
			List<TaskITranslated> taskITranslateds = taskITranslatedDao.findByAttribute(searchFilter.getKey(),
					searchFilter.getValue(),searchFilter.getPage(),searchFilter.getLimit());
			int length = taskITranslateds.size();
			List<TaskVo> list = new ArrayList<>();
			for (int i = 0; i < taskITranslateds.size(); i++) {
				Task task = taskDao.findById(taskITranslateds.get(i).getiTranslatedTaskId());
				TaskVo taskVo = new TaskVo();
				if (task == null) {
					continue;
				}
				taskVo.setLength(length);
				System.out.println(taskVo.getLength());
				taskVo.setHostName(taskITranslateds.get(i).getHostName());
				taskVo.setLastUpdateTime(task.getLastUpdateTime());
				taskVo.setTaskId(task.getTaskId());
				taskVo.setPriority(task.getPriority());
				taskVo.setProjectOwner(task.getProjectOwner());
				taskVo.setReprocesTimes(task.getReprocesTimes());
				taskVo.setSender(task.getSender());
				taskVo.setTaskContent(task.getTaskContent());
				taskVo.setTaskCreateTime(task.getTaskCreateTime());
				taskVo.setTaskStatus(task.getTaskStatus());
				taskVo.setTaskType(task.getTaskType());
				taskVo.setRef(task.getRef());
				list.add(taskVo);
			}
			if (list.size() == 0) {
				System.out.println("no data");
				return null;
			}
			return JSONUtil.objetc2Json(list);
		}
	}

	
	
	
	
	//用于提供查询TaskDetail 的api
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/TaskDetail/{taskId}")
	public String getTaskDetail(@PathParam(value = "taskId") String taskId)
			throws JsonParseException, JsonMappingException, IOException {
		System.out.println(taskId);
		//传入taskId 查找相应的task
		Task task = taskDao.findById(taskId);
		if (task != null) {
			//将db中task的taskcontent 从JSON String转为Entity
			TaskContent content = (TaskContent) JSONUtil.json2Object(task.getTaskContent(), TaskContent.class);
			//获取content中的Category
			String profileId = content.getCategory();
			TaskDetailVo taskDetailVo = new TaskDetailVo();
			//根据Category到profile中查找相应的数据
			Profile profile = profileDao.findByCategoty(profileId);
			if (profile != null)
				taskDetailVo.setUrl(profile.getUrl());
			TaskCaptured taskCaptured = taskCapturedDao.findById(taskId);
			if (taskCaptured != null) {
				taskDetailVo.setResultList(taskCaptured.getCapturedTaskResult());
				taskDetailVo.setStartTime(taskCaptured.getCreateTime());
			}
			taskDetailVo.setTaskId(taskId);
			return JSONUtil.objetc2Json(taskDetailVo);
		} else {
			return null;
		}
	}
	
	
	
	
	
}
