package com.robot.taskmanager.mongo.dao;

import com.robot.taskmanager.mongo.model.Profile;

public interface ProfileDao {
	Profile findByCategoty(String taskId);
}
