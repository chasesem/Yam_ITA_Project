package com.robot.taskmanager.mongo.dao;

import java.util.List;

import com.robot.taskmanager.mongo.model.Task;
import com.robot.taskmanager.mongo.vo.StatisticsSearch;

public interface StatisticDao {
	public List<Task> findGeneralStatistic(StatisticsSearch search);
	public List<Task> findDetailStatistic(StatisticsSearch search);
}
