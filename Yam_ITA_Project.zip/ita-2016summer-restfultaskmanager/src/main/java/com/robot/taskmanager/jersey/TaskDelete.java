package com.robot.taskmanager.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.robot.taskmanager.mongo.dao.TaskDao;
import com.robot.taskmanager.mongo.dao.TaskDaoImpl;
import com.robot.taskmanager.mongo.model.Task;


@Path("/tasks")
public class TaskDelete {
private TaskDao taskDao;
	
	public TaskDelete(){
		taskDao = new TaskDaoImpl();
	}
	
	@GET
	@Path("/delete/{key}/{value}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getOneTaskById(@PathParam(value = "key") String key, @PathParam(value = "value") String value){
		boolean result = taskDao.deleteMany(key, value);
		if (result) {
			return "{\"operation\":\"success\"}";	
		}else{
			return "{\"operation\":\"fail\"}";	
		}
	}
}
