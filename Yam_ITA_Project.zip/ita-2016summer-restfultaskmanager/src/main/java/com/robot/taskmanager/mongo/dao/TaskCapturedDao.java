package com.robot.taskmanager.mongo.dao;


import java.util.Date;
import java.util.List;

import com.robot.taskmanager.mongo.model.TaskCaptured;


public interface TaskCapturedDao {


	List<TaskCaptured> findAll();
	List<TaskCaptured> findByAttribute(String key,String value);
	List<TaskCaptured> findByTimeByAttributes(Date time,String key,String value,Integer page);
	TaskCaptured findById(String TaskCapturedId);
	void  insert(TaskCaptured TaskCaptured);
	void update(TaskCaptured TaskCaptured);

}
