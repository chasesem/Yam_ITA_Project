package com.robot.taskmanager.mongo.vo;

import java.util.Date;
import com.alibaba.fastjson.annotation.JSONField;
public class StatisticsSearch {
//	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")  
	private Date fromDate;
//	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")  
	private Date toDate;
	private String category;
	private String status;
	
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
