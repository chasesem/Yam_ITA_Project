package com.robot.taskmanager.mongo.dao;


import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.client.MongoCollection;

public class TestDaoImpl extends BasicDao{
	
	private final static String TABLE_NAME = "test";
	MongoCollection<Document> collection;
	public TestDaoImpl(){
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}
	
	public void saveOrUpdate() {
		
	}
	
	public List<String> findAll(){
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<String>  StringList = new ArrayList<String>();
		for(Document document:documents){
			StringList.add(toString(document));
		}
		return StringList;
	}
	
	public String findById(String StringId){
		Document document = collection.find(eq("_id",StringId)).first();
		return toString(document);
	}
	
	public String findFirst(){
		Document document = collection.find().first();
		
		if(document!=null){
			String String = toString(document);
			
			return String;
		}
		return null;
	}
	


	
	public void  insert(String String){
		Document document = toDocument(String);
		collection.insertOne(document);
	}
	
	public void update(String String){
		Document document = toDocument(String);
		collection.replaceOne(eq("_id",String), document);
	}
	
	public void update(String StringId,String status){
		collection.findOneAndUpdate(eq("_id",StringId), set("StringStatus",status));
	}
	
	public void delete(String String_id){
		collection.deleteOne(eq("_id",String_id));
	}
	
	private Document toDocument(String String){
		Document document = new Document();
		document.append("test", String);
		return document;
	}
	
	
	private String  toString(Document document){
		
		String String = document.getString("test");
		return String;
	}
	
}
