package com.robot.taskmanager.mongo.dao;

import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.mongo.model.Profile;

public class ProfileDaoImpl extends BasicDao implements ProfileDao {

	MongoCollection<Document> collection;

	public ProfileDaoImpl() {
		collection = getDataBase().getCollection("profile");
		// TODO Auto-generated constructor stub
	}

	@Override
	public Profile findByCategoty(String taskId) {
		Document document = collection.find().filter(eq("_id", taskId)).first();

		return toProfile(document);
	}

	public Document toDocument(Profile profile) {
		Document document = new Document();
		document.append("_id", profile.getCategory());
		document.append("url", profile.getUrl());
		document.append("javaClass", profile.getJavaClass());
		document.append("status", profile.getStatus());
		document.append("supportEmailAlert", profile.getSupportEmailAlert());
		document.append("businessEmailAlert", profile.getBusinessEmainAlert());
		document.append("createTime", profile.getCreateTime());
		document.append("lastUpdateTime", profile.getLastUpdateTime());
		return document;
	}

	public Profile toProfile(Document document) {
		if (document != null) {
			Profile profile = new Profile();
			profile.setCategory((String) document.get("_id"));
			profile.setUrl(document.getString("url"));
			profile.setJavaClass(document.getString("javaClass"));
			profile.setStatus(document.getString("status"));
//			profile.setSupportEmailAlert(document.getString("supportEmailAlert"));
//			profile.setBusinessEmainAlert(document.getString("businessEmailAlert"));
			profile.setCreateTime(document.getString("createTime"));
			profile.setLastUpdateTime(document.getString("lastUpdateTime"));
			return profile;
		}
		return null;
	}
}
