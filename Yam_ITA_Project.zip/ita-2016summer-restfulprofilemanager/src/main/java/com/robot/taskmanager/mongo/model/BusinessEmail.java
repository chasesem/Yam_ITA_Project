package com.robot.taskmanager.mongo.model;

import java.util.Date;

import com.alibaba.fastjson.JSON;

public class BusinessEmail {
	
	public final static String ENABLE="ENABLE";
	public final static String DISABLE ="DISABLE";
	
	private String emailTo;
	private String emailCopy;
	private String emailSubject;
	private String emailBody;
	private String emailEnable;
	private String category;
	private String tiggerRule;
	private String keywords;
	private Date createTime;
	private Date lastUpdateTime;
	public String getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}
	public String getEmailCopy() {
		return emailCopy;
	}
	public void setEmailCopy(String emailCopy) {
		this.emailCopy = emailCopy;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getEmailBody() {
		return emailBody;
	}
	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}
	public String getEmailEnable() {
		return emailEnable;
	}
	public void setEmailEnable(String emailEnable) {
		this.emailEnable = emailEnable;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTiggerRule() {
		return tiggerRule;
	}
	public void setTiggerRule(String tiggerRule) {
		this.tiggerRule = tiggerRule;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	
	public String toString(){
		return JSON.toJSONString(this);
	}
	

}
