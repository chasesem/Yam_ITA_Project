package com.robot.taskmanager.mongo.model;

import com.alibaba.fastjson.JSON;

public class CrawlerMapper {
	private String category;
	private String className;
	
	public CrawlerMapper(){}
	
	public CrawlerMapper(String category,String className){
		this.category = category;
		this.className = className;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	
	public String toString(){
		return JSON.toJSON(this).toString();
	}

}
