package com.robot.profilemanager.main;

import java.io.IOException;
import java.net.URI;

import javax.ws.rs.core.UriBuilderException;

import org.apache.commons.cli.ParseException;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

public class Main {
	
	@SuppressWarnings("unused")
	public static void main(String[] args) throws IllegalArgumentException, IOException, UriBuilderException, ParseException{
//		String[] args1 = {"-host","localhost"，};
		URI baseUri = CommandUtils.execute(args);
		ResourceConfig config = new ResourceConfig().packages("com.robot.profilemanager.jersey");
	    HttpServer server  = GrizzlyHttpServerFactory.createHttpServer(baseUri,config); 
	    System.out.println("profile...started");  
	}

	
}
