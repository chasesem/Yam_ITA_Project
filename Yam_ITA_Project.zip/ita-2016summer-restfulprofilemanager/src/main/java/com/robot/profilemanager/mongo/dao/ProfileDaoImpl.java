package com.robot.profilemanager.mongo.dao;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.robot.taskmanager.mongo.model.Profile;

public class ProfileDaoImpl extends BasicDao implements ProfileDao{
	private final static String TABLE_NAME = "profile";
	MongoCollection<Document> collection;
	public ProfileDaoImpl(){
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}
	
	public List<Profile> findAll(){
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<Profile>  ProfileList = new ArrayList<Profile>();
		for(Document document:documents){
			ProfileList.add(toProfile(document));
		}
		return ProfileList;
	}
	
	public Profile findByCategoty(String category){
		Document document = collection.find(eq("_id",category)).first();
		return toProfile(document);
	}
	
	public Profile findFirst(){
		Document document = collection.findOneAndUpdate(eq("status",0),set("status",1));
		if(document!=null)
			return toProfile(document);
		return null;
	}
	
	public void  insert(Profile Profile){
		Document document = toDocument(Profile);
		collection.insertOne(document);
	}
	
	public void update(Profile Profile){
		Document document = toDocument(Profile);
		collection.replaceOne(eq("_id",Profile.getCategory()), document);
	}
	
	public void delete(String Profile_id){
		collection.deleteOne(eq("_id",Profile_id));
	}
	
	
	
	public Document toDocument(Profile profile){
		Document document = new Document();
		document.append("_id", profile.getCategory());
		document.append("url", profile.getUrl());
		document.append("javaClass", profile.getJavaClass());
		document.append("status", profile.getStatus());
		document.append("supportEmailAlert", profile.getSupportEmailAlert());
		document.append("businessEmailAlert", profile.getBusinessEmainAlert());
		document.append("createTime", profile.getCreateTime());
		document.append("lastUpdateTime", profile.getLastUpdateTime());
		return document;
	}
	
	
	public Profile toProfile(Document document){
		Profile profile = new Profile();
		profile.setCategory((String) document.get("_id"));
		profile.setUrl(document.getString("url"));
		profile.setJavaClass(document.getString("javaClass"));
		profile.setStatus(document.getString("status"));
		profile.setSupportEmailAlert(document.getString("supportEmailAlert"));
		profile.setBusinessEmainAlert(document.getString("businessEmailAlert"));
		profile.setCreateTime(document.getString("createTime"));
		profile.setLastUpdateTime(document.getString("lastUpdateTime"));
		return profile;
	}

}
