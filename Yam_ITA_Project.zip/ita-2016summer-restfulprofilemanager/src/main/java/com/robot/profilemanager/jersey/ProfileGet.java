package com.robot.profilemanager.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.robot.profilemanager.mongo.dao.ProfileDao;
import com.robot.profilemanager.mongo.dao.ProfileDaoImpl;
import com.robot.taskmanager.mongo.model.Profile;

@Path("profile/get")
public class ProfileGet {
	private ProfileDao profileDao;
	
	public ProfileGet(){
		profileDao = new ProfileDaoImpl();
	}
	
	
	@GET
	@Path("/one")
	@Produces("text/plain")
	public String getone(@QueryParam("category") String category){
		Profile profile = profileDao.findByCategoty(category);
		return profile.getJavaClass();
	}
	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAll(){
		return JSON.toJSONString(profileDao.findAll());
	}
}
