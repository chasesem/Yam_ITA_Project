package com.robot.profilemanager.mongo.dao;

import com.mongodb.client.MongoDatabase;
import com.robot.profilemanager.mongo.core.DataSource;

public class BasicDao {
	private MongoDatabase dataBase;
	
	public BasicDao(){
		dataBase = DataSource.getInstance().getDatabase();
	}
	
	public MongoDatabase getDataBase(){
		return dataBase;
	}

	

}
