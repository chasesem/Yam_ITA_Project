package com.robot.profilemanager.main;

import java.util.ArrayList;
import java.util.List;

import com.robot.profilemanager.mongo.dao.ProfileDaoImpl;
import com.robot.taskmanager.mongo.model.Profile;

public class InitDBMain {
	
	public static void main(String[] args){
		ProfileDaoImpl profileDao = new ProfileDaoImpl();
		List<Profile> ProfileList = new ArrayList<Profile>();
		ProfileList.add(new Profile("AB","com.robot.crawler.task.executor.ABSExecutor"));
		ProfileList.add(new Profile("BV","com.robot.crawler.task.executor.BVExecutor"));
		ProfileList.add(new Profile("CC","com.robot.crawler.task.executor.CCSExecutor"));
		ProfileList.add(new Profile("CR","com.robot.crawler.task.executor.CRSExecutor"));
		ProfileList.add(new Profile("DN","com.robot.crawler.task.executor.DNVGLExecutor"));
		ProfileList.add(new Profile("EQ","com.robot.crawler.task.executor.EquasisExecutor"));
		ProfileList.add(new Profile("IR","com.robot.crawler.task.executor.IRSExecutor"));
		ProfileList.add(new Profile("KR","com.robot.crawler.task.executor.KRSExecutor"));
		ProfileList.add(new Profile("LR","com.robot.crawler.task.executor.LRSExecutor"));
		ProfileList.add(new Profile("NK","com.robot.crawler.task.executor.NKKExecutor"));
		ProfileList.add(new Profile("RM","com.robot.crawler.task.executor.RMRSExecutor"));
		ProfileList.add(new Profile("FE","com.robot.crawler.task.executor.FleetMonExecutor"));
		ProfileList.add(new Profile("VE","com.robot.crawler.task.executor.VesseltrackerExecutor"));
		for(Profile mapper:ProfileList){
			profileDao.insert(mapper);
		}
	}

}
