package com.robot.profilemanager.jersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.robot.profilemanager.mongo.dao.ProfileDao;
import com.robot.profilemanager.mongo.dao.ProfileDaoImpl;
import com.robot.taskmanager.mongo.model.Profile;

@Path("/profile")
public class ProfileSaveOrUpdate {
	
private ProfileDao profileDao;
	
	public ProfileSaveOrUpdate(){
		profileDao = new ProfileDaoImpl();
	}
	
	
	@POST
	@Path("/save")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String save(String json){
		profileDao.insert(JSON.parseObject(json, Profile.class));
		return "{\"operation\":\"success\"}";
	}
	
	@POST
	@Path("/update")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String update(String json){
		profileDao.update(JSON.parseObject(json, Profile.class));
		return "{\"operation\":\"success\"}";
	}
}
