package com.robot.profilemanager.mongo.dao;

import java.util.List;

import com.robot.taskmanager.mongo.model.Profile;

public interface ProfileDao {
	List<Profile> findAll();
	Profile findByCategoty(String taskId);
	void  insert(Profile Profile);
	void update(Profile Profile);
}
