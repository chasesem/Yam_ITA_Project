package com.robot.profilemanager.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.Properties;

import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriBuilderException;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

public class CommandUtils {
	
	public static URI execute(String[] args) throws ParseException, IllegalArgumentException, UriBuilderException, FileNotFoundException, IOException{
		Options options = new Options();
		options.addOption("f",true,"set properties file");
		options.addOption("host",true,"set host");
		options.addOption("port",true,"set port");
		CommandLineParser parser = new PosixParser();
		CommandLine cmd = parser.parse(options, args);
		URI baseUri = UriBuilder.fromUri("http://10.222.47.44/").port(8092).build();
		if(cmd.hasOption("f")){
			File file = new File(cmd.getOptionValue("f")); 
			Properties prop = new Properties();
			prop.load(new FileInputStream(file));
			if(prop.getProperty("host")!=null||!prop.getProperty("port").isEmpty()){
				baseUri = build(prop.getProperty("host"),prop.getProperty("port"));
			}
		}
//		if(cmd.hasOption("host")&&cmd.hasOption("port")){
//			baseUri = UriBuilder.fromUri(cmd.getOptionValue("host")).port(Integer.valueOf(cmd.getOptionValue("port"))).build();
//		}else{
//			if(cmd.hasOption("port"))
//				baseUri = UriBuilder.fromUri("http://"+InetAddress.getLocalHost().getHostAddress()+"/").port(Integer.valueOf(cmd.getOptionValue("port"))).build();
//			if(cmd.hasOption("host"))
//				baseUri = UriBuilder.fromUri(cmd.getOptionValue("host")).port(80).build();
//		}
		if(cmd.hasOption("host")||cmd.hasOption("port")){
			baseUri = build(cmd.getOptionValue("host"),cmd.getOptionValue("port"));
			System.out.println("666"+cmd.getOptionValue("host")+cmd.getOptionValue("port"));
		}
		return baseUri;
	}
	
	private static URI build(String host,String port) throws IllegalArgumentException, UriBuilderException, UnknownHostException{
//		URI baseUri = UriBuilder.fromUri("http://"+InetAddress.getLocalHost().getHostAddress()+"/").port(80).build();
		URI baseUri = UriBuilder.fromUri("http://10.222.47.44/").port(8092).build();
		if(host!=null&&!host.isEmpty()&&port!=null&&!port.isEmpty()){
			baseUri = UriBuilder.fromUri(host).port(Integer.valueOf(port)).build();
		}else{
			if(host!=null&&!host.isEmpty())
				baseUri = UriBuilder.fromUri(host).port(80).build();
			if(port!=null&&!port.isEmpty())
				baseUri = UriBuilder.fromUri("http://"+InetAddress.getLocalHost().getHostAddress()+"/").port(Integer.valueOf(port)).build();
		}
		
		return baseUri;
	}

}
