package com.robot.taskcontroller.amqp;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.MessageProperties;

public class QueueSender {
	
	private String queueName = "com.robot.input";
	private ConnectionFactory factory;
	
	public QueueSender() throws IOException, TimeoutException{
		factory = new AMQPConnectionFactory().getFactory();
	}
	
	public void sendMessage(String message) throws IOException, TimeoutException{
		
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		Connection conn = factory.newConnection();
		Channel channel = conn.createChannel();
		channel.queueDeclare(queueName,false,false,false,null);
		channel.basicPublish("", queueName,  MessageProperties.PERSISTENT_TEXT_PLAIN,
	            message.getBytes());
		channel.close();
		conn.close();
		System.out.println("send:"+message);
	}
	

}
