package com.robot.taskcontroller.util;

import org.apache.logging.log4j.LogManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
* Created by WUJO2 on 9/22/2016.
*/
public class PropertiesUtil {
    private final static org.apache.logging.log4j.Logger logger = LogManager.getLogger(PropertiesUtil.class);

    private static Properties properties;

    private PropertiesUtil() {
    }

    static {
        properties = new Properties();
        try {
            properties.load(PropertiesUtil.class.getClassLoader().getResourceAsStream("taskController.properties"));
        } catch (IOException e) {
            logger.error("Unable to load properties file.", e);
        }
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
}