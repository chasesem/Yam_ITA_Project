package com.robot.taskcontroller.servlet;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.robot.taskcontroller.jersey.client.JClient;
import com.robot.taskcontroller.model.Account;
@Controller
@RequestMapping("/AccountController")
public class AccountController {
	JClient jerseyClient;
	public AccountController() {
		jerseyClient = new JClient();
	}
	
	
	@RequestMapping(value="/query",method=RequestMethod.POST)
	@ResponseBody
	public String query(@RequestBody Account user) throws JsonProcessingException{
		Account us=new Account();
		ObjectMapper objectMapper=new ObjectMapper();
		jerseyClient.setWebTarget(jerseyClient.getClient().target("http://10.222.232.41:8099/"));
		String result = jerseyClient.login(user.getUserName());
		 try {
			us=objectMapper.readValue(result, Account.class);
			System.out.println("userPassword::"+us.getPassWord());
			System.out.println("userPassword::"+user.getPassWord());
		   if (us.getPassWord().equals(user.getPassWord())) {
			   System.out.println("succ");
			   return "{\"result\":\"succ\"}";
		  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(result);
		 return "{\"result\":\"fail\"}";
	}
}
