package com.robot.taskcontroller.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TaskStateUtil {
	
	public static List<String> states = new ArrayList<>();
	
	static{
		states.add("R_TRANSLATED");
		states.add("I_TRANSLATED");
		states.add("NEW");
		states.add("I_TRANSLATED_FAIL");
		states.add("CAPTURED_FAIL");
		states.add("PROCESSING");
		states.add("CAPTURED");
		states.add("R_TRANSLATED_FAIL");
		states.add("REPROCESS");
//		Collections.addAll(states, "R_TRANSLATED","R_TRANSLATED","R_TRANSLATED")
	}
	
	public static List<String> fuzzySearchLocationsByNamePrefix(String prefix) {

		
		List<String> matches = new ArrayList<String>();
		if (prefix != null && !prefix.trim().isEmpty()) {
			String prefixInUpper = prefix.trim().toUpperCase();
			for (String state : states) {
				if (state.toUpperCase().startsWith(prefixInUpper)) {
					matches.add(state);
				}
			}
		}
		return matches;
	}
}
