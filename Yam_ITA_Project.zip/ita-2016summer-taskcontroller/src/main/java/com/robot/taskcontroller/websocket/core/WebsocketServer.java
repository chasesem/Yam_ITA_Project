package com.robot.taskcontroller.websocket.core;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


@ServerEndpoint("/connection/{nodeId}/{nodeCode}")
public class WebsocketServer {
	
	private static Logger logger = LogManager.getLogger(WebsocketServer.class);
	
	@OnOpen
	public void onOpen(@PathParam("nodeId") String nodeId,@PathParam("nodeCode") int nodeCode,Session session){
		 logger.info("Start Connecting:"+ SessionUtils.getKey(nodeId, nodeCode));
		 SessionUtils.put(nodeId, nodeCode, session);
	}
	
	@OnMessage
	public String onMessage(@PathParam("nodeId") String nodeId,@PathParam("nodeCode") int nodeCode,String message) {
		if("hello".equals(message)){
			logger.info("connect success:" + SessionUtils.getKey(nodeId, nodeCode));
			}
		logger.info(message);
		return "Got([nodeId:"+ nodeId + "] [nodeCode:"+ nodeCode+"]"+message+")" ;
	}

	@OnError
	public void onError(@PathParam("nodeId") String nodeId, @PathParam("nodeCode") int nodeCode, Throwable throwable,
			Session session) {
		logger.info("Connection error:" + SessionUtils.getKey(nodeId, nodeCode));
		SessionUtils.remove(nodeId, nodeCode);
	}
	
	@OnClose
	public void onClose(@PathParam("nodeId") String nodeId, @PathParam("nodeCode") int nodeCode, Session session) {
		logger.info("Close Connection:" + SessionUtils.getKey(nodeId, nodeCode));
		SessionUtils.remove(nodeId, nodeCode);
	}


}
