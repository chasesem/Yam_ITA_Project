package com.robot.taskcontroller.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;

public class CrawlerClient {
	private String queryUrl;
	public Client client;
	public WebTarget webTarget;
	
	public CrawlerClient() {
		client = ClientBuilder.newClient(new ClientConfig());
	}

	public CrawlerClient(String queryUrl) {
		this.queryUrl = queryUrl;
	}

	public String getQueryUrl() {
		return queryUrl;
	}

	public void setQueryUrl(String queryUrl) {
		this.queryUrl = queryUrl;
		webTarget = client.target(queryUrl);
	}
	public String doGet(){
		Response response = null;
		try {
			response = webTarget.request().get();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "fail";
		}
	
		if(response.getStatus()==200){
		return "success";
		}
		else{
			return "fail";
		}
	}
}
