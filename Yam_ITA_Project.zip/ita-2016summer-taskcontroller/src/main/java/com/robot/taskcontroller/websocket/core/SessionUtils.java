package com.robot.taskcontroller.websocket.core;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.Session;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SessionUtils {
	
	private final static Logger logger = LogManager.getLogger(SessionUtils.class); 
	
	private static Map<String,Session> clients = new ConcurrentHashMap<String, Session>();
	private static Set<String> clientIds = new HashSet<String>();
	
	public static void put(String nodeId,int nodeCode,Session session){
		clients.put(getKey(nodeId,nodeCode), session);
		clientIds.add(getKey(nodeId,nodeCode));
	}
	
	public static Session get(String key){
		return clients.get(key);
	}
	
	public static Session get(String nodeId,int nodeCode){
		return clients.get(getKey(nodeId,nodeCode));
	}
	
	public static void remove(String nodeId,int nodeCode){
		clients.remove(getKey(nodeId,nodeCode));
	}
	
	public static boolean hasConnected(String key){
		return clients.containsKey(key);
	}
	
	public static boolean hasConnected(String nodeId,int nodeCode){
		return clients.containsKey(getKey(nodeId,nodeCode));
	}
	
	
	public static Map<String,Session> getClients(){
		return clients;
	}
	
	public static Set<String> getClientIds(){
		return clientIds;
	}
	
	public static String getKey(String nodeId, int nodeCode) {
		 return nodeId +"_"+ nodeCode;
	}
	
	public static void sendMessageBasic(String key,String message){
		if(hasConnected(key)){
			try {
				get(key).getBasicRemote().sendText(message);
			} catch (IOException e) {
				logger.error(e);
			}
		}else{
			logger.warn(new NullPointerException(SessionUtils.get(key) +"Connection does not exist"));
			}
		
	}
	
	@SuppressWarnings("rawtypes")
	public static void brocastBasic(String message){
		Iterator iter = clients.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
		    sendMessageBasic(entry.getKey().toString(),message);
		}
		
	}
	
	
}
