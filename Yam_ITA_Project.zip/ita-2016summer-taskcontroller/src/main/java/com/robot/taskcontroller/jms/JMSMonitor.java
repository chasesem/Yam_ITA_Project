package com.robot.taskcontroller.jms;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.apache.activemq.broker.jmx.BrokerViewMBean;
import org.apache.activemq.broker.jmx.ProducerViewMBean;
import org.apache.activemq.broker.jmx.QueueViewMBean;
import org.apache.activemq.broker.jmx.SubscriptionViewMBean;
import org.apache.activemq.broker.region.Queue;

import com.robot.taskcontroller.model.JMSQueue;
import com.robot.taskcontroller.model.Producer;
import com.robot.taskcontroller.model.Subscriber;
import com.robot.taskcontroller.util.PropertiesUtil;

public class JMSMonitor {
	private String url = PropertiesUtil.getProperty("jmx.jndi.path");
	private String brokerPath = PropertiesUtil.getProperty("jmx.broker.path");
	private JMXConnector connector;
	private JMXServiceURL urls;
	public JMSMonitor(){
		try {
			System.out.println(url);
			urls = new JMXServiceURL(url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public List<Subscriber> getSubscribers(){
		List<Subscriber> subscriberList = new ArrayList<Subscriber>();
		try {
			connector = JMXConnectorFactory.connect(urls,null);
			connector.connect();
			MBeanServerConnection conn = connector.getMBeanServerConnection();
			ObjectName name = new ObjectName(brokerPath);
			BrokerViewMBean mBean = (BrokerViewMBean)MBeanServerInvocationHandler.newProxyInstance(conn, name, BrokerViewMBean.class, true);
			for(ObjectName nb:mBean.getQueueSubscribers()){
				SubscriptionViewMBean subBean = (SubscriptionViewMBean) MBeanServerInvocationHandler.newProxyInstance(conn, nb, SubscriptionViewMBean.class, true);
				Subscriber subscriber = new Subscriber();
				subscriber.setClientId(subBean.getClientId());
				subscriber.setConsumerNumber(subBean.getDequeueCounter());
				subscriber.setQueueName(subBean.getDestinationName());
				subscriberList.add(subscriber);
			}
			connector.close();  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return subscriberList;
	}
	
	
	public List<Producer> getProducers() {
		List<Producer> subscriberList = new ArrayList<Producer>();
		try {
			connector = JMXConnectorFactory.connect(urls,null);
			connector.connect();
			MBeanServerConnection conn = connector.getMBeanServerConnection();
			ObjectName name = new ObjectName(brokerPath);
			BrokerViewMBean mBean = (BrokerViewMBean)MBeanServerInvocationHandler.newProxyInstance(conn, name, BrokerViewMBean.class, true);
			for(ObjectName nb:mBean.getQueueProducers()){
				ProducerViewMBean proBean = (ProducerViewMBean) MBeanServerInvocationHandler.newProxyInstance(conn, nb, ProducerViewMBean.class, true);
				Producer producer = new Producer();
				producer.setClientId(proBean.getClientId());
				producer.setQueueName(proBean.getDestinationName());
				producer.setSendCount(proBean.getSentCount());
				subscriberList.add(producer);
			}
			connector.close();  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return subscriberList;
	}
	
	
	public List<JMSQueue> getQueues(){
		List<JMSQueue> queues = new ArrayList<JMSQueue>();
		try {
			connector = JMXConnectorFactory.connect(urls,null);
			connector.connect();
			MBeanServerConnection conn = connector.getMBeanServerConnection();
			ObjectName name = new ObjectName(brokerPath);
			BrokerViewMBean mBean = (BrokerViewMBean)MBeanServerInvocationHandler.newProxyInstance(conn, name, BrokerViewMBean.class, true);
			for(ObjectName nb:mBean.getQueues()){
				QueueViewMBean queueViewMBean = (QueueViewMBean) MBeanServerInvocationHandler.newProxyInstance(conn, nb, QueueViewMBean.class, true);
				JMSQueue queue = new JMSQueue();
				queue.setPendingCount((int)queueViewMBean.getQueueSize());
				queue.setQueueName(queueViewMBean.getName());
				queue.setTotal((int)queueViewMBean.getEnqueueCount());
				queue.setConsumedCount((int)queueViewMBean.getDequeueCount());
				queue.setPendingCount(queue.getTotal()-queue.getConsumedCount());
				queues.add(queue);
			}
			connector.close();  
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
		
		return queues;
	}
}
