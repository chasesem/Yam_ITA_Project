package com.robot.taskcontroller.main;






public class Main {
	
//	public static void main(String[] args) throws Exception{
//		if(args.length<1){
//			String[] arg = {"-f","taskController.properties"};
//			CommandController.execute(arg);
//		}else{
//			CommandController.execute(args);
//		}
//		
//		System.out.println("taskController");
//		Server server = new Server(9909);
//		ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
//		context.setContextPath("/controller");
//		context.addServlet(new ServletHolder(new ReciverServlet()), "/task/*");
//		context.addServlet(new ServletHolder(new ReciverTaskServlet()), "/saveTask");
//		context.addServlet(new ServletHolder(new TestServlet()), "/test");
//		context.addServlet(new ServletHolder(new JMSSubscriberGetServlet()), "/jms/sub");
//		context.addServlet(new ServletHolder(new JMSProducerGetServlet()), "/jms/pro");
//		server.setHandler(context);
////		ServerContainer wscontainer = WebSocketServerContainerInitializer.configureContext(context);
////		wscontainer.addEndpoint(WebsocketServer.class);
//		
//		server.start();  
//		server.join();  
//		
//		
//		
//		System.out.println("heheh");
//	}

}
