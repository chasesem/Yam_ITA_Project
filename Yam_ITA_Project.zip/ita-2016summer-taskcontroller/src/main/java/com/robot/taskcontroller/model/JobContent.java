package com.robot.taskcontroller.model;

import com.alibaba.fastjson.JSON;

public class JobContent {
	private String category;
	private String sender;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	
	public String toString(){
		System.out.println("hhh::"+JSON.toJSONString(this));
		return JSON.toJSONString(this);
	}

}
