package com.robot.taskcontroller.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.robot.taskcontroller.jersey.client.CrawlerClient;
import com.robot.taskcontroller.util.Global;
import com.robot.taskcontroller.vo.CrawlerDescription;

/**
 * Application Lifecycle Listener implementation class CrawlerStateListener
 *
 */
@WebListener
public class CrawlerStateListener implements ServletContextListener {

	/**
	 * Default constructor.
	 */
	public CrawlerStateListener() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see ServletContextListener#contextDestroyed(ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
	}

	/**
	 * @see ServletContextListener#contextInitialized(ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent arg0) {
		CrawlerClient client = new CrawlerClient();
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (true) {
					for (int i = 0; i < Global.list.size(); i++) {

						CrawlerDescription description = Global.list.get(i);
						client.setQueryUrl(description.getQueryUrl());
						String result = client.doGet();
						if ("fail".equals(result)) {
							description.setStatus(CrawlerDescription.STOPPED);
						}
					}
					try {
						Thread.sleep(1000 * 30);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}).start();

	}

}
