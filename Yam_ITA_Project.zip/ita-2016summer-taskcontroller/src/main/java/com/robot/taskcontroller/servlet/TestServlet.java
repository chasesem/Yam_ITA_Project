package com.robot.taskcontroller.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.robot.taskcontroller.jersey.client.JClient;
import com.robot.taskcontroller.jersey.client.TestClient;

public class TestServlet extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TestServlet(){
		super();
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response){
		try {
			 String result = request.getParameter("json");
			 System.out.println(result);
			 BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
			 StringBuilder task = new StringBuilder();
			 String line = null;
			 while((line = reader.readLine())!=null){
				 task.append(line);
			 }
			 TestClient jerseyClient = new TestClient();
			 jerseyClient.saveTask(task.toString());
			 System.out.println(task.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
