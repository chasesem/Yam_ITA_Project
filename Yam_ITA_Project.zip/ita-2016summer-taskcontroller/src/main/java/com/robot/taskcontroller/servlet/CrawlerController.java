package com.robot.taskcontroller.servlet;

import java.util.List;

import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.robot.taskcontroller.util.Global;
import com.robot.taskcontroller.vo.CrawlerDescription;

@Controller
@RequestMapping("/crawler")
public class CrawlerController {
	
	@RequestMapping(value="/description",consumes=MediaType.APPLICATION_JSON,method=RequestMethod.POST)
	@ResponseBody
	public String getDescription(@RequestBody CrawlerDescription description){
		boolean flag = false;
		for(int i = 0 ; i < Global.list.size() ; i++){
			if(Global.list.get(i).getAppId().equals(description.getAppId())){
//				Global.list.set(i, description);
				flag = true;
			}
		}
		if(!flag){
			description.setStatus(CrawlerDescription.RUNNING);
			Global.list.add(description);
		}
		return "{\"result\":true}";
	}
	
	@RequestMapping("/all")
	@ResponseBody
	public String getAllCrawler(){
		String json = JSON.toJSONString(Global.list);
		return json;
	}
	
	
}
