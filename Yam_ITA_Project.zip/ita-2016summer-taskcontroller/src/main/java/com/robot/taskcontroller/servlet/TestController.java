package com.robot.taskcontroller.servlet;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.robot.taskcontroller.jersey.client.TestClient;

@Controller
@RequestMapping("testController")
public class TestController {
	
	@RequestMapping("test")
	@ResponseBody
	public String test(String json){
		 TestClient jerseyClient = new TestClient();
		// jerseyClient.saveTask(json.toString());
		 return json;
	}
}
