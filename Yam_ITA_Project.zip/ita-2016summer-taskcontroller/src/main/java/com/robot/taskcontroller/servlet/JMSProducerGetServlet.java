package com.robot.taskcontroller.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.robot.taskcontroller.jms.JMSUtils;
import com.robot.taskcontroller.model.Producer;

@SuppressWarnings("serial")
public class JMSProducerGetServlet  extends HttpServlet{
	public JMSProducerGetServlet(){
		super();
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
		List<Producer> subscriberList = JMSUtils.getProduces();
		response.getWriter().println(JSON.toJSON(subscriberList));
	}
}
