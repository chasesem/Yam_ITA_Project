package com.robot.taskcontroller.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.robot.taskcontroller.jms.JMSUtils;
import com.robot.taskcontroller.model.Subscriber;

@SuppressWarnings("serial")
public class JMSSubscriberGetServlet extends HttpServlet{
	
	public JMSSubscriberGetServlet(){
		super();
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
		List<Subscriber> subscriberList = JMSUtils.getSubscribers();
		response.getWriter().println(JSON.toJSON(subscriberList));
		
	}
	
}
