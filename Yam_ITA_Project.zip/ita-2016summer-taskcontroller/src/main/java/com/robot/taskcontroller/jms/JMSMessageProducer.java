package com.robot.taskcontroller.jms;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQTextMessage;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.robot.taskcontroller.jersey.client.JClient;
import com.robot.taskcontroller.jersey.client.TestClient;
import com.robot.taskcontroller.model.ChangeStatusVo;
import com.robot.taskcontroller.model.Task;
import com.robot.taskcontroller.util.JSONUtil;

public class JMSMessageProducer extends Thread{
	private JClient jClient;
	private TextMessage msg;
	private String task = "";
	private Sender sender;
	
	public JMSMessageProducer(Sender sender){
		jClient = new JClient();
		msg = new ActiveMQTextMessage();
		this.sender = sender;
	}
	
	public void run(){
		while(true){
				task = jClient.getTask();
				System.out.println(task);
			if(!task.equals("null")){
				try {
//					Task temp = (Task) JSONUtil.json2Object(task, Task.class);
//					Task temp = JSON.parseObject(task,Task.class);
					JSONObject jsonObject = JSONObject.parseObject(task);
					String taskId = (String) jsonObject.get("taskId");
					msg.setText(task);
					ChangeStatusVo changeStatusVo = new ChangeStatusVo();
					changeStatusVo.setTaskId(taskId);
					changeStatusVo.setTaskStatus("PROCESSING");
					String str = JSONUtil.objetc2Json(changeStatusVo);
					String tString =jClient.updateTask(str);
					System.out.println(str);
					Thread.sleep(1000*20);
					sender.sendMessage(msg);
				} catch (JMSException | IOException | InterruptedException e1) {
					e1.printStackTrace();
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}else{
				try {
					System.out.println("empty sleep 10 s");
					Thread.sleep(1000*20);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
