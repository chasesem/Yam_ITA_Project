package com.robot.taskcontroller.command;

public interface Command {
	static final String KILL = "kill";
	static final String RESTART = "restart";
	static final String NOCOMMAND = "not a command";
}
