package com.robot.taskcontroller.jms;

import java.util.Date;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.Topic;


public class TopicSender {
	
	private String topicName;
	private Connection connection;
	
	public TopicSender(Connection connection,String topicName){
		this.connection = connection;
		this.topicName = topicName;
	}
	
	@SuppressWarnings("deprecation")
	public void sendMessage(Message msg) {
		Session session = null;
		try {
			Date date = new Date();
			connection.setClientID("crawler"+date.getHours()+date.getMinutes()+date.getSeconds());
			connection.start();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			Topic topic = session.createTopic(topicName);
			MessageProducer producer = session.createProducer(topic);
			producer.setDeliveryMode(DeliveryMode.PERSISTENT);
			producer.send(msg);
			session.commit();
		} catch (JMSException e) {
			e.printStackTrace();
		} finally{
				try {
					if(session!=null)
					session.close();
					if(connection!=null)
						connection.stop();
				} catch (JMSException e) {
					e.printStackTrace();
				}
			
		}
	}


}
