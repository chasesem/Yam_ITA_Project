package com.robot.taskcontroller.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.robot.taskcontroller.jersey.client.ProfileCategoryClient;
import com.robot.taskcontroller.jersey.client.StatisticsClient;
import com.robot.taskcontroller.model.Profile;
import com.robot.taskcontroller.util.JSONUtil;

@Controller
@RequestMapping("/statistics")
public class StatisticsController {
	private StatisticsClient client=new StatisticsClient();
	private ProfileCategoryClient categoryClient = new ProfileCategoryClient();
	
	@RequestMapping(value="generalStatistics",method=RequestMethod.POST)
	@ResponseBody
	public Object findGeneralStatistics(@RequestBody String searchCondition){
//		String searchCondition = JSON.toJSONString(search);
		System.out.println(searchCondition);
		String response = client.getGeneralStatistic(searchCondition);
//		List<Task> scheduledJobs = JSONArray.parseArray(response, Task.class);
		Object scheduledJobs = null;
		try {
			scheduledJobs = JSONUtil.json2Object(response, Object.class);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return scheduledJobs;
	}
	
	@RequestMapping(value="detailStatistics",method=RequestMethod.POST)
	@ResponseBody
	public Object findDetailStatistics(@RequestBody String searchCondition){
		System.out.println(searchCondition);
//		String searchCondition = JSON.toJSONString(search);
		String response = client.getDetailStatistic(searchCondition);
		Object scheduledJobs = null;
		try {
			scheduledJobs = JSONUtil.json2Object(response, Object.class);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return scheduledJobs;
	}
	
	@RequestMapping(value="allCategories",method=RequestMethod.GET)
	@ResponseBody
	public String getAllCategories(){
		String allprofileStr = categoryClient.getAllProfile();
//		try {
//			List<Profile> profiles = (List<Profile>) JSONUtil.json2Object(allprofileStr, Profile.class);
//			List<String> profileList = new ArrayList<>();
//			for(Profile profile : profiles){
//				profileList.add(profile.getCategory());
//			}
//			return profileList;
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return allprofileStr;
	}
}
