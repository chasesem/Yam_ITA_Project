package com.robot.taskcontroller.util;

import java.util.ArrayList;
import java.util.List;

import com.robot.taskcontroller.vo.CrawlerDescription;

public class Global {
	public static List<CrawlerDescription> list = new ArrayList<>();
}
