package com.robot.taskcontroller.servlet;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.robot.taskcontroller.jersey.client.JClient;
import com.robot.taskcontroller.jersey.client.ProfileCategoryClient;
import com.robot.taskcontroller.model.Profile;
import com.robot.taskcontroller.model.ScheduledJob;
import com.robot.taskcontroller.util.JSONUtil;
import com.robot.taskcontroller.vo.PageVo;


@Controller
@RequestMapping(value="JobController")
public class JobController {
	
	@RequestMapping(value="all")
	@ResponseBody
	public String getAll(){
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		String response = jClient.getAllJob();
		System.out.println(response);
//		List<ScheduledJob> jobs = JSONArray.parseArray(response, ScheduledJob.class);
		return response;
	}
	@RequestMapping(value="job/{jobId}")
	@ResponseBody
	public String deleteJob(@RequestBody String jobId){
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		return jClient.deleteJob(jobId);
	}
	@RequestMapping(value="job")
	@ResponseBody
	public String updateJob(@RequestBody ScheduledJob schedule){
		System.out.println(schedule);
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		jClient.updateTask(schedule.toString());
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="job/new")
	@ResponseBody
	public String newJob(@RequestBody ScheduledJob schedule){
		System.out.println(schedule);
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		jClient.saveTask(schedule.toString());
//		ScheduledJob job = JSON.parseObject(response, ScheduledJob.class);
		return "{\"operation\":\"success\"}";
	}
	@RequestMapping(value="job/old/{jobId}")
	@ResponseBody
	public String delJob(@PathVariable String jobId){
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		jClient.deleteJob(jobId);
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="job/alot")
	@ResponseBody
	public String delJobALot(@RequestBody List<ScheduledJob> list){
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		String joblist = "[";
		for(ScheduledJob job : list){
			joblist += job.toString();
			joblist += ",";
		}
		joblist = joblist.substring(0,joblist.length()-1);
		joblist += "]";
		jClient.delJobALot(joblist);
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="category")
	@ResponseBody
	public List<Profile> getAllJobCategory(){
		ProfileCategoryClient client = new ProfileCategoryClient();
		String response = client.getAllProfile();
		System.out.println(response);
		List<Profile> profiles = JSONArray.parseArray(response, Profile.class);
		return profiles;
	}
	
	@RequestMapping(value="pageJob")
	@ResponseBody
	public String getAllByPage(@RequestBody PageVo pageVo){
		String pageInfo = JSON.toJSONString(pageVo);
		System.out.println(pageInfo);
		JClient jClient = new JClient();
		jClient.setWebTarget(jClient.getClient().target(JClient.JOB_PATH));
		String response = jClient.getPageJob(pageInfo);
		System.out.println(response);
//		List<ScheduledJob> jobs = JSONArray.parseArray(response, ScheduledJob.class);
		return response;
	}
}