package com.robot.taskcontroller.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;

import com.robot.taskcontroller.util.PropertiesUtil;

public class ProxyClient {
	public final static String HOST_PATH = PropertiesUtil.getProperty("proxy.path");
	public final static String SAVE_PATH = "/proxy/save";
	public final static String FIND_ALL_PATH = "/all";
	public final static String FIND_ONE_PATH = "/one/";
	public final static String UPDATE_PATH = "/update";
	public final static String DEL_PATH = "/delete/";
	public Client client;
	public WebTarget webTarget;
	
	
	public ProxyClient(){
		client = ClientBuilder.newClient(new ClientConfig());
		webTarget = client.target(HOST_PATH);
	}
	
	
	private String doPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		
		System.out.println(response.readEntity(String.class));
//		logger.debug("back+"+response.readEntity(String.class));
		return "SUCCESS";
	}
	
	private String doGet(String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.get();
		String re = response.readEntity(String.class);
		return re;
	}
	
	public String save(String json){
		return doPost(SAVE_PATH, json);
	}
	
	public String findAll(){
		return doGet(FIND_ALL_PATH);
	}
	
	public String update(String json){
		return doPost(UPDATE_PATH, json);
	}
	public String del(String json){
		return doGet(DEL_PATH+json);
	}
	
	
	
}
