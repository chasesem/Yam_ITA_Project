package com.robot.taskcontroller.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.commons.cli.ParseException;

import com.robot.taskcontroller.main.CommandController;

/**
 * Application Lifecycle Listener implementation class TaskControllerListener
 *
 */
@WebListener
public class TaskControllerListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public TaskControllerListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg0)  { 
    	String[] arg = {"-f","taskController.properties"};
    	try {
			CommandController.execute(arg);
		} catch (IOException | JMSException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
}
