package com.robot.taskcontroller.servlet;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.robot.taskcontroller.jms.JMSUtils;
import com.robot.taskcontroller.model.Producer;
import com.robot.taskcontroller.util.JSONUtil;

@Controller
@RequestMapping("jmsProducerController")
public class JMSProducerController {
	
	@RequestMapping("/jms/sub")
	@ResponseBody
	public String get(){
		List<Producer> subscriberList = JMSUtils.getProduces();
		String json = "";
		try {
			json = JSONUtil.objetc2Json(subscriberList);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json;
	}
}
