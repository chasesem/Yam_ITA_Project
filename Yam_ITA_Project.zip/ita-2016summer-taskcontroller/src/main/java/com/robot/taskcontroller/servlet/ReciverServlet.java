package com.robot.taskcontroller.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.robot.taskcontroller.command.CommandExcetor;
import com.robot.taskcontroller.websocket.core.Node;
import com.robot.taskcontroller.websocket.core.SessionUtils;


@SuppressWarnings("serial")
public class ReciverServlet extends HttpServlet{
	public ReciverServlet(){
		super();
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/html;charset=utf-8");
	    response.setCharacterEncoding("UTF-8");
	    String nodeKey = request.getParameter("node");
	    String command = request.getParameter("command");
		//Map<String,Session> clients = SessionUtils.getClients();
	    CommandExcetor.execute(nodeKey, command);
		response.getWriter().println("command sended");
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
//		Map<String,Session> clients = SessionUtils.getClients();
//		Iterator iter = clients.entrySet().iterator();
		Set<String> nodeIdList = SessionUtils.getClientIds();
		List<Node> nodeList = new ArrayList<Node>();
//		while (iter.hasNext()) {
//			Node node = new Node();
//			Map.Entry entry = (Map.Entry) iter.next();
//		    node.setId(entry.getKey().toString());
//		    node.setStatus(clients.get(entry.getKey()).isOpen()?"open":"close");
//		    nodeList.add(node);
//		 }
		for(String nodeId:nodeIdList){
			Node node = new Node();
			node.setId(nodeId);
			node.setStatus(SessionUtils.hasConnected(nodeId)?"open":"close");
			nodeList.add(node);
		}
		String result = JSON.toJSONString(nodeList);
		response.getWriter().println(result);
		
		
		
		
		
	}
	
	

}
