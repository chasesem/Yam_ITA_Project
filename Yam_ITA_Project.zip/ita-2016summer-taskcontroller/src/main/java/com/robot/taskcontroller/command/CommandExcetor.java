package com.robot.taskcontroller.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.robot.taskcontroller.websocket.core.SessionUtils;

public class CommandExcetor implements Command{
	
	private final static Logger logger = LogManager.getLogger(CommandExcetor.class);

	//wait for rebuild this method
	public static void  execute(String key,String command) {
		if(command.equals(Command.KILL))
			SessionUtils.sendMessageBasic(key, Command.KILL);
		if(command.equals(Command.RESTART))
			SessionUtils.sendMessageBasic(key, Command.RESTART);
		else
			logger.warn(Command.NOCOMMAND+":"+command);
	
	}
}
