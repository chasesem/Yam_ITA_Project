package com.robot.taskcontroller.command;

public class Reciver {

}
