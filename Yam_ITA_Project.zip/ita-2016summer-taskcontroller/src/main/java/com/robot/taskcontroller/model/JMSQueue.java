package com.robot.taskcontroller.model;

import java.util.List;

public class JMSQueue {
	private String queueName;
	private List<Producer> producers;
	private List<Subscriber> subscribers;
	private int total;
	private int consumedCount;
	private int pendingCount;
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public List<Producer> getProducers() {
		return producers;
	}
	public void setProducers(List<Producer> producers) {
		this.producers = producers;
	}
	
	public List<Subscriber> getSubscribers() {
		return subscribers;
	}
	public void setSubscribers(List<Subscriber> subscribers) {
		this.subscribers = subscribers;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getConsumedCount() {
		return consumedCount;
	}
	public void setConsumedCount(int consumedCount) {
		this.consumedCount = consumedCount;
	}
	public int getPendingCount() {
		return pendingCount;
	}
	public void setPendingCount(int pendingCount) {
		this.pendingCount = pendingCount;
	}
	
	
}
