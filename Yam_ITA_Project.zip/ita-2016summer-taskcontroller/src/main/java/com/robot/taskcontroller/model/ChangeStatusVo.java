package com.robot.taskcontroller.model;

public class ChangeStatusVo {
	private String taskId;
	private String taskStatus;
	public ChangeStatusVo(){
		
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	
}
