package com.robot.taskcontroller.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.robot.taskcontroller.command.CommandExcetor;
import com.robot.taskcontroller.jersey.client.JClient;
import com.robot.taskcontroller.model.SearchFilter;
import com.robot.taskcontroller.model.Task;
import com.robot.taskcontroller.model.TaskContent;
import com.robot.taskcontroller.util.DateUtil;
import com.robot.taskcontroller.util.JSONUtil;
import com.robot.taskcontroller.util.TaskStateUtil;
import com.robot.taskcontroller.websocket.core.Node;
import com.robot.taskcontroller.websocket.core.SessionUtils;

@Controller
@RequestMapping("/ReciverTaskController")
public class ReciverTaskController {
	JClient jerseyClient;
	
	public ReciverTaskController() {
		
		
		jerseyClient = new JClient();
		
	}
	
	
	@RequestMapping(value="/command",method=RequestMethod.POST)
	@ResponseBody
	public String setCommand(String node , String command){
		 CommandExcetor.execute(node, command);
		 return "command sended";
	}
	
	
	@RequestMapping(value="/command",method=RequestMethod.GET)
	@ResponseBody
	public List<Node> getCommand(){
		Set<String> nodeIdList = SessionUtils.getClientIds();
		List<Node> nodeList = new ArrayList<Node>();
		for(String nodeId:nodeIdList){
			Node node = new Node();
			node.setId(nodeId);
			node.setStatus(SessionUtils.hasConnected(nodeId)?"open":"close");
			nodeList.add(node);
		}
		return nodeList;
	}
	
	@RequestMapping(value="/saveTask",method=RequestMethod.POST)
	@ResponseBody
	public String saveTask(@RequestBody Task task){
		System.out.println(task.getSender());
//		Task task  = null;
		TaskContent taskContent = null;
		try {
//			task = (Task) JSONUtil.json2Object(json, Task.class);
			taskContent = (TaskContent) JSONUtil.json2Object(task.getTaskContent(), TaskContent.class);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		task.setTaskId(UUID.randomUUID()+"_"+taskContent.getCategory());
		task.setLastUpdateTime(new Date());
		task.setTaskCreateTime(new Date());
		String temp = "";
		try {
			temp = JSONUtil.objetc2Json(task);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jerseyClient.saveTask1(temp);
		return "{\"result\":\"success\"}";
	}
	
	@RequestMapping(value="/query",method=RequestMethod.POST)
	@ResponseBody
	public String query(@RequestBody String searchFilter) throws JsonProcessingException{
//		String temp = JSONUtil.objetc2Json(searchFilter);
		System.out.println(searchFilter);
		jerseyClient.setWebTarget(jerseyClient.getClient().target(JClient.HOST_PATH));
		String result = jerseyClient.query(searchFilter);
		System.out.println(result);
		return result;
	}
	@RequestMapping(value="/queryDetail")
	@ResponseBody
	public String queryDetail(String id) throws JsonProcessingException{
		System.out.println("id:::::::::::"+id);
		jerseyClient.setWebTarget(jerseyClient.getClient().target(JClient.HOST_PATH));
		String result = jerseyClient.queryDetail(id);
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		System.out.println(result);
		if(result!=null&&result!="")
		  return result;
		else{
			return "{\"result\":\"fail\"}";
		}
	}
	@RequestMapping(value="/reprocessTask")
	@ResponseBody
	public String reprocessTask(@RequestBody List<String> list) throws JsonProcessingException{
		System.out.println("id:::::::::::"+list);
		ObjectMapper oMapper=new ObjectMapper();
		jerseyClient.setWebTarget(jerseyClient.getClient().target(JClient.HOST_PATH));
	    for (int i = 0; i < list.size(); i++) {
	    	String result = jerseyClient.queryDetailOfTask(list.get(i));
			System.out.println("result:::::::::"+result);
			TaskContent taskContent = null;
		    try {
				Task task=oMapper.readValue(result, Task.class);
				Task newTask=new Task();
				taskContent = (TaskContent) JSONUtil.json2Object(task.getTaskContent(), TaskContent.class);
				newTask.setTaskId(UUID.randomUUID()+"_"+taskContent.getCategory());
				newTask.setPriority(task.getPriority());
				newTask.setReprocesTimes(0);
				if (task.getRef()!=null) {
					newTask.setRef(task.getRef());
				}else{
					newTask.setRef(task.getTaskId());
				}
				newTask.setProjectOwner(task.getProjectOwner());
				newTask.setSender(task.getSender());
				newTask.setTaskContent(task.getTaskContent());
				newTask.setTaskType(task.getTaskType());
				String str2=oMapper.writeValueAsString(newTask);
				System.out.println("save task!!!!!!!!!!!!!!!!"+str2);
				jerseyClient.saveTask1(str2);
				
				
				task.setLastUpdateTime(new Date());
				//task.setTaskStatus("REPROCESS");
				task.setReprocesTimes(task.getReprocesTimes()+1);
				String str=oMapper.writeValueAsString(task);
				jerseyClient.UpdateStatus(str);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "{\"result\":\"fail\"}";	
		   }
		}
	    return "{\"result\":\"success\"}";		
	}
	
	@RequestMapping("/taskState")
	@ResponseBody
	public List<String> getTaskState(String state){
		List<String> list = TaskStateUtil.fuzzySearchLocationsByNamePrefix(state);
		return list;
	}
	
	
}
