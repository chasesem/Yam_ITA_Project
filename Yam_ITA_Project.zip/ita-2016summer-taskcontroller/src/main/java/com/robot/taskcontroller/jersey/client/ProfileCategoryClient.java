package com.robot.taskcontroller.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;

import com.robot.taskcontroller.util.PropertiesUtil;

public class ProfileCategoryClient {
	private final static String PROFILE_PATH = PropertiesUtil.getProperty("profile.host.path");
	public final static String CATEGORY_PATH = PropertiesUtil.getProperty("profile.all.path");
	private Client client;
	private WebTarget webTarget;
	
	public ProfileCategoryClient(){
		client = ClientBuilder.newClient(new ClientConfig());
		webTarget = client.target(PROFILE_PATH);
	}
	
	private String doGet(String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.get();
		String re = response.readEntity(String.class);
		return re;
	}
	
	public String getAllProfile(){
		return doGet(CATEGORY_PATH);
	}
}
