package com.robot.taskcontroller.model;

import com.alibaba.fastjson.JSON;

public class Subscriber {
	private String queueName;
	private String clientId;
	private long consumerNumber;
	
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public long getConsumerNumber() {
		return consumerNumber;
	}
	public void setConsumerNumber(long consumerNumber) {
		this.consumerNumber = consumerNumber;
	}
	
	public String toString(){
		return JSON.toJSONString(this);
	}

}
