package com.robot.taskcontroller.amqp;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class QueueReciver {
	
	private String queueName = "com.robot.input";
	private ConnectionFactory factory;
	
	public QueueReciver() throws IOException, TimeoutException{
		factory = new AMQPConnectionFactory().getFactory();
	}
	
	public void reciveMessage() throws IOException, TimeoutException{
		
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		Connection conn = factory.newConnection();
		Channel channel = conn.createChannel();
		channel.queueDeclare(queueName,false,false,false,null);
		channel.basicConsume(queueName, new QueueConsume(channel));
	}
	
	
}
