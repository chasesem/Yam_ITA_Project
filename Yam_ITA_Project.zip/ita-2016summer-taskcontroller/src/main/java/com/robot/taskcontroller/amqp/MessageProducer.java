package com.robot.taskcontroller.amqp;

public class MessageProducer {

}
