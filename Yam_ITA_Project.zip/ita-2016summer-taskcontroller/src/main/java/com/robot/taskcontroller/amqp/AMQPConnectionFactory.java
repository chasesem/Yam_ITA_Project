package com.robot.taskcontroller.amqp;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class AMQPConnectionFactory {
	
	private ConnectionFactory factory;
	
	public AMQPConnectionFactory() throws IOException, TimeoutException{
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		Connection conn = factory.newConnection();
		Channel channel = conn.createChannel();
		channel.queueDeclare("com.robot.input",false,false,false,null);
	}
	
	public ConnectionFactory getFactory(){
		return factory;
	}

}
