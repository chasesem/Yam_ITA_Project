package com.robot.taskcontroller.jersey.client;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.robot.taskcontroller.model.ScheduledJob;
import com.robot.taskcontroller.util.PropertiesUtil;

public class JClient {
	private final static Logger logger =  LogManager.getLogger(JClient.class);
	
//	private final static String HOST_PATH = "http://10.222.232.33:8099/";
	public final static String HOST_PATH = PropertiesUtil.getProperty("jclient.host.path");
	public final static String GET_TASK_PATH = "tasks/first";
	public final static String SAVE_TASK_PATH = "save/job";
	public final static String UPDATE_TASK_PATH = "update/job";
//	public final static String JOB_PATH = "http://10.222.232.33:8071/";
	public final static String JOB_PATH = PropertiesUtil.getProperty("jclient.job.path");
	public final static String GET_JOBPATH = "jobs/all";
	public final static String GET_PAGE_JOBPATH = "jobs/pageJob";
	public final static String DEL_JOBPATH = "delete/job/";
	public final static String DEL_JOBALOT = "delete/job/alot";
	public final static String SAVE_TASK_PATH1 = "save/input";
	public Client client;
	public WebTarget webTarget;
	
	
	public JClient(){
		client = ClientBuilder.newClient(new ClientConfig());
		webTarget = client.target(HOST_PATH);
	}
	
	public String saveTask(String form){
		System.out.println("------------------------"+form);
		return doPost(SAVE_TASK_PATH,form);
	}
	
	
	public String saveTask1(String form){
		System.out.println("------------------------"+form);
		return doPost(SAVE_TASK_PATH1,form);
	}
	
	private String doPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		
		System.out.println(response.readEntity(String.class));
//		logger.debug("back+"+response.readEntity(String.class));
		return "SUCCESS";
	}
	
	public String getTask(){
		return doGet(GET_TASK_PATH);
	}
	private String doGet(String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.get();
		String re = response.readEntity(String.class);
		return re;
	}
	
	public String updateTask(String str){
		return doPost(UPDATE_TASK_PATH,str);
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Client getClient() {
		return this.client;
	}
	public String getAllJob(){
		return doGet(GET_JOBPATH);
	} 
	public String deleteJob(String jobId){
		return doGet(DEL_JOBPATH+jobId);
	}
	public String delJobALot(String joblist){
		return doPost(DEL_JOBALOT, joblist);
	}
	public void setWebTarget(WebTarget webTarget) {
		this.webTarget = webTarget;
	}

	public String query(String temp) {
		// TODO Auto-generated method stub
		return doQueryPost("search/task/attribute", temp);
	}
	
	private String doQueryPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		
		String temp = response.readEntity(String.class);
		return temp;
	}

	public String UpdateStatus(String temp) {
		System.out.println("*************"+temp);
		return doPost("save/updateById", temp);
	}

		public String queryDetailOfTask(String id) {
		// TODO Auto-generated method stub
		String path="tasks/quaryByID/"+id;
		System.out.println(path);
		//System.out.println(doGet(path));
		return doGet(path);
	}

		public String queryDetail(String id) {
			// TODO Auto-generated method stub
			String path="search/TaskDetail/"+id;
			System.out.println(path);
			//System.out.println(doGet(path));
			return doGet(path);
		}
	
	
	public String getPageJob(String str){
		return doJobPost(GET_PAGE_JOBPATH, str);
	}
	
	public String delete(String key,String value){
		String path="tasks/delete/"+key+"/"+value;
		return doGet(path);
	}
	
	private String doJobPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		
		String json = response.readEntity(String.class);
//		logger.debug("back+"+response.readEntity(String.class));
		return json;
	}

	public String login(String userName) {
		// TODO Auto-generated method stub
		String path="accout/login/"+userName;
		return doGet(path);
	}
}
