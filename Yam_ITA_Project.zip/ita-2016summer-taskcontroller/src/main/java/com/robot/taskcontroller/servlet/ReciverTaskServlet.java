package com.robot.taskcontroller.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.robot.taskcontroller.jersey.client.JClient;


//@WebServlet(urlPatterns="/getTask", asyncSupported=false)
@SuppressWarnings("serial")
public class ReciverTaskServlet extends HttpServlet{
	
	public ReciverTaskServlet(){
		super();
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
		 BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
		 StringBuilder task = new StringBuilder();
		 String line = null;
		 while((line = reader.readLine())!=null){
			 task.append(line);
		 }
		 JClient jerseyClient = new JClient();
		 jerseyClient.saveTask(task.toString());
		 System.out.println(task.toString());
		 
		 //SessionUtils.brocastBasic(task.toString());
		 response.getWriter().println(task.toString());
	}
	
	

}
