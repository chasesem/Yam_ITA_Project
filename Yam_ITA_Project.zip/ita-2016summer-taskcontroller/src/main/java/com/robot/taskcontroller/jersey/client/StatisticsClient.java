package com.robot.taskcontroller.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;

import com.robot.taskcontroller.util.PropertiesUtil;

public class StatisticsClient {
	private final static String HOST_PATH = PropertiesUtil.getProperty("jclient.host.path");
	private final static String GET_GENERAL_STATISTICS_PATH = "statisticSearch/generalStatistic";
	private final static String GET_DETAIL_STATISTICS_PATH = "statisticSearch/detailStatistic";
	private Client client;
	private WebTarget webTarget;
	
	public StatisticsClient(){
		client = ClientBuilder.newClient(new ClientConfig());
		webTarget = client.target(HOST_PATH);
	}
	
	public String getGeneralStatistic(String searchCondition){
		return doPost(GET_GENERAL_STATISTICS_PATH,searchCondition);
	}
	
	private String doPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		
		String json = response.readEntity(String.class);
		System.out.println(json);
//		logger.debug("back+"+response.readEntity(String.class));
		return json;
	}
	
	public String getDetailStatistic(String searchCondition){
		return doPost(GET_DETAIL_STATISTICS_PATH,searchCondition);
	}
	private String doGet(String path){
		try {
			Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
//		invocationBuilder.header("some-header", "true");
			Response response = invocationBuilder.get();
			String re = response.readEntity(String.class);
			return re;
			
		} catch (Exception e) {
			throw e;
		}
	}
}
