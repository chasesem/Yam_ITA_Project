package com.robot.taskcontroller.jms;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.apache.activemq.broker.jmx.BrokerViewMBean;
import org.apache.activemq.broker.jmx.ProducerViewMBean;
import org.apache.activemq.broker.jmx.SubscriptionViewMBean;

import com.robot.taskcontroller.model.Producer;
import com.robot.taskcontroller.model.Subscriber;

public class JMSUtils {
	
private static String url = "service:jmx:rmi:///jndi/rmi://localhost:2011/jmxrmi";
	
	public static List<Subscriber> getSubscribers() {
		JMXServiceURL urls;
		List<Subscriber> subscriberList = new ArrayList<Subscriber>();
		try {
			urls = new JMXServiceURL(url);
			JMXConnector connector = JMXConnectorFactory.connect(urls,null);
			connector.connect();
			MBeanServerConnection conn = connector.getMBeanServerConnection();
			ObjectName name = new ObjectName("domain:brokerName=localhost1,type=Broker");
			BrokerViewMBean mBean = (BrokerViewMBean)MBeanServerInvocationHandler.newProxyInstance(conn, name, BrokerViewMBean.class, true);
			for(ObjectName nb:mBean.getQueueSubscribers()){
				SubscriptionViewMBean subBean = (SubscriptionViewMBean) MBeanServerInvocationHandler.newProxyInstance(conn, nb, SubscriptionViewMBean.class, true);
				Subscriber subscriber = new Subscriber();
				subscriber.setClientId(subBean.getClientId());
				subscriber.setConsumerNumber(subBean.getDequeueCounter());
				subscriber.setQueueName(subBean.getDestinationName());
				subscriberList.add(subscriber);
			}
			connector.close();  
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
		
		return subscriberList;
	}
		
	public static List<Producer> getProduces() {
		JMXServiceURL urls;
		List<Producer> subscriberList = new ArrayList<Producer>();
		try {
			urls = new JMXServiceURL(url);
			JMXConnector connector = JMXConnectorFactory.connect(urls,null);
			connector.connect();
			MBeanServerConnection conn = connector.getMBeanServerConnection();
			ObjectName name = new ObjectName("domain:brokerName=localhost1,type=Broker");
			BrokerViewMBean mBean = (BrokerViewMBean)MBeanServerInvocationHandler.newProxyInstance(conn, name, BrokerViewMBean.class, true);
			for(ObjectName nb:mBean.getQueueProducers()){
				ProducerViewMBean proBean = (ProducerViewMBean) MBeanServerInvocationHandler.newProxyInstance(conn, nb, ProducerViewMBean.class, true);
				Producer producer = new Producer();
				producer.setClientId(proBean.getClientId());
				producer.setQueueName(proBean.getDestinationName());
				producer.setSendCount(proBean.getSentCount());
				subscriberList.add(producer);
			}
			connector.close();  
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		}
		
		return subscriberList;
	}
		
		

}
