package com.robot.taskcontroller.vo;

/**
 * Created by WUJO2 on 9/27/2016.
 */
public class CrawlerDescription {
	public static final String RUNNING = "RUNNING";
    public static final String STOPPED = "STOPPED";
	private String hostName;
	private String ipv4Address;
	private String ipv6Address;
	private String appId;
	private String queryUrl;
	private String status;

	public CrawlerDescription() {
	}

	public CrawlerDescription(String hostName, String ipv4Address, String appId, String queryUrl) {
		this.hostName = hostName;
		this.ipv4Address = ipv4Address;
		this.appId = appId;
		this.queryUrl = queryUrl;
	}

	public String getQueryUrl() {
		return queryUrl;
	}

	public void setQueryUrl(String queryUrl) {
		this.queryUrl = queryUrl;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getIpv4Address() {
		return ipv4Address;
	}

	public void setIpv4Address(String ipv4Address) {
		this.ipv4Address = ipv4Address;
	}

	public String getIpv6Address() {
		return ipv6Address;
	}

	public void setIpv6Address(String ipv6Address) {
		this.ipv6Address = ipv6Address;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
