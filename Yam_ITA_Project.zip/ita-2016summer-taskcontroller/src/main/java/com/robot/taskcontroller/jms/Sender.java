package com.robot.taskcontroller.jms;

import javax.jms.Message;

public interface Sender {
	void sendMessage(Message msg);
}
