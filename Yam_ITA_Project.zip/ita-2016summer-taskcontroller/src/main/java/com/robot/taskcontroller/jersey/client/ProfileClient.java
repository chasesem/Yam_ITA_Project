package com.robot.taskcontroller.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

import com.robot.taskcontroller.util.PropertiesUtil;

public class ProfileClient {

	private final static Logger logger =  LogManager.getLogger(ProfileClient.class);
	
	private final static String HOST_PATH = PropertiesUtil.getProperty("jclient.host.path");
	public final static String PROFILE_PATH = PropertiesUtil.getProperty("jclient.profile.path");
	private final static String GET_ALL_PROFILE = "profile/get/all";
	private final static String UPDATE_PROFILE = "profile/update";
	private final static String GET_ONE_PROFILE = "profile/get/profile/";
	private final static String SAVE_PROFILE = "profile/save";
	private final static String DELETE_PROFILE = "profile/delete/";
	private final static String GET_PAGE_PROFILE = "profile/get/pageProfile";
	private final static String DELETE_ALOT = "profile/deleteAlot";
	
	private final static String GET_ALL_CRAWLER = "crawler/get/all";
	private final static String SAVE_CRAWLER = "crawler/save";
	private Client client;
	private WebTarget webTarget;

	public ProfileClient() {
		// TODO Auto-generated constructor stub
		client = ClientBuilder.newClient(new ClientConfig());
		webTarget = client.target(HOST_PATH);
	}
	private String doDelete(String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.delete();
		//System.out.println(response.readEntity(String.class));
		return "SUCCESS";
	}
	
	private String doGet(String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.get();
		String re = response.readEntity(String.class);
		return re;
	}
	
	private String doPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		
		System.out.println(response.readEntity(String.class));
//		logger.debug("back+"+response.readEntity(String.class));
		return "SUCCESS";
	}
	
	private String doPagePost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		String json = response.readEntity(String.class);
		return json;
	}
	
	public void setClient(Client client) {
		this.client = client;
	}
	public Client getClient() {
		return this.client;
	}
	
	public void setWebTarget(WebTarget webTarget) {
		this.webTarget = webTarget;
	}
	
	public String getAllProfile(){
		return doGet(GET_ALL_PROFILE);
	}
	
	public String updateProfile(String str){
		return doPost(UPDATE_PROFILE, str);
	}
	
	public String getOneProfile(String profileId){
		return doGet(GET_ONE_PROFILE+profileId);
	}
	
	public String saveProfile(String str){
		return doPost(SAVE_PROFILE, str);
	}
	
	public String deleteProfile(String profileId){
		return doDelete(DELETE_PROFILE+profileId);
	}
	
	public String getPageProfile(String str){
		return doPagePost(GET_PAGE_PROFILE, str);
	}
	
	public String deleteProfileAlot(String profileList){
		return doPost(DELETE_ALOT, profileList);
	}
	
	public String getAllCrawler(){
		return doGet(GET_ALL_CRAWLER);
	}
	
	public String saveCrawler(String str){
		return doPost(SAVE_CRAWLER, str);
	}
}
