package com.robot.taskcontroller.model;

import com.alibaba.fastjson.JSON;

public class Crawler {

	private String category;
	private String url;
    private String javaClass;
    private String name;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getJavaClass() {
		return javaClass;
	}
	public void setJavaClass(String javaClass) {
		this.javaClass = javaClass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Crawler() {
	// TODO Auto-generated constructor stub
	}
	public Crawler(String name,String javaClass,String url) {
		// TODO Auto-generated constructor stub
		this.javaClass = javaClass;
		this.name = name;
		this.url = url;
	}
	
	public String toString() {
        return JSON.toJSONString(this);
    }
    
}
