package com.robot.taskcontroller.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.jms.JMSException;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import com.robot.taskcontroller.jms.JMSMessageProducer;
import com.robot.taskcontroller.jms.QueueSender;





public class CommandController {
	private final static String JMS_USER = "jms.user";
	private final static String JMS_PASSWOED = "jms.password";
	private final static String JMS_URL = "jms.url";
	private final static String JMS_QUEUE_PRODUCE = "jms.queue.produce";
	
	public static void execute(String[] args) throws FileNotFoundException, IOException, JMSException, ParseException{
		Options options = new Options();
		options.addOption("f",true,"set properties file");
		CommandLineParser parser = new PosixParser();
		CommandLine cmd = parser.parse(options, args);
		
		
		if(cmd.hasOption("f")){
//			File file = new File(cmd.getOptionValue("f")); 
			Properties prop = new Properties();
			prop.load(CommandController.class.getClassLoader().getResourceAsStream(cmd.getOptionValue("f")));
			System.out.println(prop.getProperty(JMS_USER)+"+"+prop.getProperty(JMS_PASSWOED)+"+"+prop.getProperty(JMS_URL));
			QueueSender queueSender = QueueSender.getInstance(prop.getProperty(JMS_USER),prop.getProperty(JMS_PASSWOED),
								prop.getProperty(JMS_URL),prop.getProperty(JMS_QUEUE_PRODUCE));
			new JMSMessageProducer(queueSender).start();
		}else{
			System.out.println("need properties file");
		}
	}


}
