package com.robot.taskcontroller.servlet;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.robot.taskcontroller.jms.JMSMonitor;
import com.robot.taskcontroller.model.JMSQueue;
import com.robot.taskcontroller.model.Producer;
import com.robot.taskcontroller.model.Subscriber;

@Controller
@RequestMapping("jmsQueueController")
public class JMSQueueController {
	
	private JMSMonitor monitor;
	@RequestMapping(value="queueInfos",method=RequestMethod.GET)
	@ResponseBody
	public List<JMSQueue> getQueueInfo(){
		monitor = new JMSMonitor();
		List<JMSQueue> queues = monitor.getQueues();
		List<Producer> producers = monitor.getProducers();
		List<Subscriber> subscribers = monitor.getSubscribers();
		for(int i = 0;i < queues.size();i++){
			List<Producer> tempProducer = new ArrayList<>();
			List<Subscriber> tempSubscriber = new ArrayList<>();
			for(Producer producer:producers){
				if (queues.get(i).getQueueName().equals(producer.getQueueName())) {
					tempProducer.add(producer);
				}
			}
			
			for(Subscriber subscriber:subscribers){
				if (queues.get(i).getQueueName().equals(subscriber.getQueueName())) {
					tempSubscriber.add(subscriber);
				}
			}
			queues.get(i).setProducers(tempProducer);
			queues.get(i).setSubscribers(tempSubscriber);
		}
		
		return queues;
	}
}
