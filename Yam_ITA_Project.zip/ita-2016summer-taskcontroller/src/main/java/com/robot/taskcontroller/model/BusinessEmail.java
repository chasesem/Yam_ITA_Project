package com.robot.taskcontroller.model;

import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

public class BusinessEmail {
	
	public final static String ENABLE="ENABLE";
	public final static String DISABLE ="DISABLE";
	
	private List<String> emailTo;
	private List<String> emailCopy;
	private String emailSubject;
	private String emailBody;
	private String emailEnable;
	private String category;
	private String triggerRule;
	private List<String> keywords;
	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")
	private Date createTime;
	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")
	private Date lastUpdateTime;

	
	public List<String> getEmailTo() {
		return emailTo;
	}
	public void setEmailTo(List<String> emailTo) {
		this.emailTo = emailTo;
	}
	public List<String> getEmailCopy() {
		return emailCopy;
	}
	public void setEmailCopy(List<String> emailCopy) {
		this.emailCopy = emailCopy;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getEmailBody() {
		return emailBody;
	}
	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}
	public String getEmailEnable() {
		return emailEnable;
	}
	public void setEmailEnable(String emailEnable) {
		this.emailEnable = emailEnable;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTriggerRule() {
		return triggerRule;
	}
	public void setTriggerRule(String triggerRule) {
		this.triggerRule = triggerRule;
	}
	
	public List<String> getKeywords() {
		return keywords;
	}
	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	
	public String toString(){
		return JSON.toJSONString(this);
	}
	

}
