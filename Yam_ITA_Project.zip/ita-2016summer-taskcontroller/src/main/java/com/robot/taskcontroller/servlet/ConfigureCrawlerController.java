package com.robot.taskcontroller.servlet;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.robot.taskcontroller.jersey.client.ProfileClient;
import com.robot.taskcontroller.model.Crawler;
import com.robot.taskcontroller.model.Profile;
import com.robot.taskcontroller.vo.PageSortVO;

@Controller
@RequestMapping(value="ConfigureCrawlerController")
public class ConfigureCrawlerController {

	ProfileClient profileClient;
	public ConfigureCrawlerController() {
		profileClient = new ProfileClient();
	}
	
	@RequestMapping(value="getAll")
	@ResponseBody
	public String getAllProfile(){
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		return profileClient.getAllProfile();
	}
	
	@RequestMapping(value="update")
	@ResponseBody
	public String updateProfile(@RequestBody Profile profile){
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		profileClient.updateProfile(profile.toString());
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="save")
	@ResponseBody
	public String saveProfile(@RequestBody Profile profile){
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		profileClient.saveProfile(profile.toString());
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="delete/{profileId}")
	@ResponseBody
	public String deleteProfile(@PathVariable String profileId){
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		profileClient.deleteProfile(profileId);
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="getPageProfile")
	@ResponseBody
	public String getPageProfile(@RequestBody PageSortVO pageSortVo){
		String pageInfo = JSON.toJSONString(pageSortVo);
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		String response = profileClient.getPageProfile(pageInfo);
		return response;
	}
	
	@RequestMapping(value="deleteAlot")
	@ResponseBody
	public String deleteProfileAlot(@RequestBody List<Profile> list){
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		String profileList = "[";
		for(Profile profile : list){
			profileList+=profile.toString();
			profileList+=",";
		}
		profileList = profileList.substring(0, profileList.length()-1);
		profileList+="]";
		System.out.println(profileList);
		profileClient.deleteProfileAlot(profileList);
		return "{\"operation\":\"success\"}";
	}
	
	@RequestMapping(value="getAllCrawler")
	@ResponseBody
	public String getAllCrawler(){
		ProfileClient profileClient = new ProfileClient();
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		return profileClient.getAllCrawler();
	}
	
	@RequestMapping(value="saveCrawler")
	@ResponseBody
	public String saveCrawler(@RequestBody Crawler crawler){
		ProfileClient profileClient = new ProfileClient();
		profileClient.setWebTarget(profileClient.getClient().target(ProfileClient.PROFILE_PATH));
		profileClient.saveCrawler(crawler.toString());
		return "{\"operation\":\"success\"}";
	}
}
