package com.robot.taskcontroller.model;

import com.alibaba.fastjson.JSON;

public class Profile {
    public final static String ENABLE = "ENABLE";
    public final static String DISABLE = "DISABLE";
    private String category;
    private String projectOwner;
    private String name;
    private String code;
    private String url;
    private String javaClass;
    private String status;
    private SupportEmail supportEmailAlert;
    private BusinessEmail businessEmailAlert;
    private String createTime;
    private String lastUpdateTime;
    private String supportEmailAlertStatus;
    private String businessEmailAlertStatus;

    public Profile() {
    }

    public Profile(String category, String javaClass) {
        this.category = category;
        this.javaClass = javaClass;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getProjectOwner() {
        return projectOwner;
    }

    public void setProjectOwner(String projectOwner) {
        this.projectOwner = projectOwner;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getJavaClass() {
        return javaClass;
    }

    public void setJavaClass(String javaClass) {
        this.javaClass = javaClass;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public SupportEmail getSupportEmailAlert() {
		return supportEmailAlert;
	}

	public void setSupportEmailAlert(SupportEmail supportEmailAlert) {
		this.supportEmailAlert = supportEmailAlert;
	}

	public BusinessEmail getBusinessEmailAlert() {
		return businessEmailAlert;
	}

	public void setBusinessEmailAlert(BusinessEmail businessEmailAlert) {
		this.businessEmailAlert = businessEmailAlert;
	}

	public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    
    public String getSupportEmailAlertStatus() {
		return supportEmailAlertStatus;
	}

	public void setSupportEmailAlertStatus(String supportEmailAlertStatus) {
		this.supportEmailAlertStatus = supportEmailAlertStatus;
	}

	public String getBusinessEmailAlertStatus() {
		return businessEmailAlertStatus;
	}

	public void setBusinessEmailAlertStatus(String businessEmailAlertStatus) {
		this.businessEmailAlertStatus = businessEmailAlertStatus;
	}

	public String toString() {
        return JSON.toJSONString(this);
    }

}
