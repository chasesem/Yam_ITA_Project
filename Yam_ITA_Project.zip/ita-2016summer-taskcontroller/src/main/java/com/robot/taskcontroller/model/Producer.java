package com.robot.taskcontroller.model;

import com.alibaba.fastjson.JSON;

public class Producer {
	private String queueName;
	private String clientId;
	private long sendCount;
	
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public long getSendCount() {
		return sendCount;
	}
	public void setSendCount(long sendCount) {
		this.sendCount = sendCount;
	}
	public String toString(){
		return JSON.toJSONString(this);
	}

}
