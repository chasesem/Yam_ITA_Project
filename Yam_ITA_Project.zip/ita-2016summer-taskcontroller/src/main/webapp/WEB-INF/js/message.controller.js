//var realProjectControllers = angular.module("realProjectControllers");

var sendMsgUrl="/TaskController/ReciverTaskController/saveTask"
realProjectControllers.controller("messageCtrl",function($scope,$rootScope,$http){
	$scope.taskMsg="";
	$scope.sendMsg=function(){
		if($scope.taskMsg && $scope.taskMsg!=''){
			$scope.msgTip=""
			try {
				var taskData = JSON.parse($scope.taskMsg)
				taskData.taskContent = JSON.stringify(taskData.taskContent)
				var temp = JSON.stringify($scope.taskMsg)
				$http.post(sendMsgUrl,taskData).success(function(response){
//					alert("succ");
					swal("Success!", "Send task message success!", "success")
				})
			} catch (e) {
				$scope.msgTip="Sorry,Message format should be json.";
			}
		}else{
			$scope.msgTip="Sorry,Message should not be null...";
		}
	}
	
	messageInit();
	function messageInit(){
		$rootScope.active = "message";
	}
});