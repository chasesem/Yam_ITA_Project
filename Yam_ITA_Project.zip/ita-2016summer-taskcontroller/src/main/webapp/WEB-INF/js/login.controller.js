var loginControllers = angular.module("loginControllers",[]);
loginControllers.controller("loginCtrl",function($scope,$http){
	sessionStorage.removeItem("user")
	$scope.login=function(user){
		console.log(user)
		console.log(user.password)
		$http({
			method:'post',
			url:'../AccountController/query',	
			data:{
				userName:user.userName,
				passWord:user.password
			}
		}).success(function(data){
		   console.log(data)
		   if(data.result=='succ'){
			   sessionStorage.setItem("user",JSON.stringify(user.userName))
			   window.location.href='home.html'
		   }else{
			   swal("passwork or userName err", ""); 
		   }
		   
		}).error(function(data,status,headers,config){
			alert("err")
		})
		
	}
	$scope.validationUserId=function(user){
		if(user==''){
			$scope.userErr=true	
			$scope.buttonStatus=true
		}else{
			$scope.userErr=false	
			$scope.buttonStatus=false
		}
	}
	$scope.validationPassword=function(password){
		if(password==''){
			$scope.buttonStatus=true
			$scope.pwdErr=true
			
		}else if(password.length<6||password.length>20){
			$scope.buttonStatus=true
			$scope.pwdLength=true
		}
		else{
			$scope.pwdErr=false
			$scope.buttonStatus=false
			$scope.pwdLength=false
		}
	}
})