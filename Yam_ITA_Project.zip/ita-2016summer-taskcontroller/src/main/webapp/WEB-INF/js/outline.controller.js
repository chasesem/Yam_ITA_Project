var jmsQueueInfosUrl = "../jmsQueueController/queueInfos";

realProjectControllers.controller("outlineCtrl",function($scope,$rootScope,$http,$interval,scheduleService){
	outlineInit();
	function outlineInit(){
		$rootScope.active = "outline";
	}
	
	$scope.jmsQueues = [];
	$scope.getJmsQueues=function(){
		$http.get(jmsQueueInfosUrl).success(function(response){
			$scope.jmsQueues = response;
		})
	}
	$scope.getJmsQueues();
	//设置定时器
	var interval = $interval(function(){
		$scope.getJmsQueues();
	},5000)
	//离开当前页面时移除定时器
	$scope.$on("$destroy", function(){
		$interval.cancel(interval);
    });
	
	$scope.currentModalSender={}
	$scope.initModalSender=function(queue){
		$scope.currentModalSender.queueName=queue.queueName;
		$scope.currentModalSender.producers=queue.producers;
		console.log($scope.currentModalSender.producers)
	}
	
	$scope.currentModalListener={}
	$scope.initModalListener=function(queue){
		$scope.currentModalListener.queueName=queue.queueName;
		$scope.currentModalListener.subscribers=queue.subscribers;
		console.log($scope.currentModalListener.subscribers)
	}
	
	
})