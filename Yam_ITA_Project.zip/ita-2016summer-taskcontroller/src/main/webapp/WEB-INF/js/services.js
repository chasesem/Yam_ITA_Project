var realProjectServices = angular.module("realProjectServices", []);

realProjectServices.service("scheduleService", function ($http, $filter) {
	function splitTime(str){
		var a=str.match(/\d+/gi);
		console.log(a[0]);
		var b=str.match(/\D+/gi);
		console.log(b[0])
		return [a,b];
	}
	
	this.isNotNull=function(str){
		if(str!=null && str!=''){
			return true;
		}
		return false;
	}
	
	this.isAllNotNull=function(list){
		for(var i = 0;i < list.length;i++){
			if(!list[i]){
				return false;
			}
		}
		return true;
	}
	
	this.isDigit=function(value){  
       var reg = new RegExp("^\d+$");
	   if(!/^\d+$/.test(value)){  
		   return false;
	   }  
	   return true;
	 }  
})