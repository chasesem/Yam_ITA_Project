var loginApp = angular.module("loginApp", ["ngRoute","loginControllers"]);
//const urlPrefix = "../views/templates/";
//loginApp.config(function ($routeProvider) {
//	$routeProvider
//	.when("/",{
//		templateUrl:urlPrefix+"Login.html",
//		controller:"loginCtrl"
//	})
//	.otherwise({ redirectTo: '/' })
//})