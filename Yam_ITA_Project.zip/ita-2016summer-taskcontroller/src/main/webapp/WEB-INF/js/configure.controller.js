realProjectControllers.controller("configureCtrl", function($scope, $rootScope, $http) {
	var getProfileUrl = "/TaskController/ConfigureCrawlerController/getAll";
	var updateProfileUrl = "/TaskController/ConfigureCrawlerController/update";
	var saveProfileUrl = "/TaskController/ConfigureCrawlerController/save";
	var deleteProfileUrl = "/TaskController/ConfigureCrawlerController/delete/";
	var getPageProfileUrl = "/TaskController/ConfigureCrawlerController/getPageProfile";
	var deleteProfileAlotUrl = "/TaskController/ConfigureCrawlerController/deleteAlot";
	var getCrawlerUrl = "/TaskController/ConfigureCrawlerController/getAllCrawler";
	configureInit();

	function configureInit() {
		$rootScope.active = "configure";
		$scope.categories = [];
		$scope.crawlerStatus = {};
		$scope.crawlerAdd = {};
		$scope.alertRuleAdd = {};
		$scope.supportEmailAdd = {};
		$scope.pageInfo = {
			page: 1,
			pageSize: 12,
			sort: -1,
			sortBy:'lastUpdateTime'
		}
		$scope.profileCheckBox = {};
		$scope.allCheckBox = false;
		$scope.profileDelist = [];
	}



	function getAllCategories() {
		$http({
			method: "GET",
			url: getProfileUrl
		}).then(function successCallback(res) {
			//			console.log("getProfile succ")
			//			console.log(res.data)
			$scope.categories = res.data;
			for (var i = 0; i < ($scope.categories).length; i++) {
				($scope.categories)[i].profileStatus = (($scope.categories)[i].status == 'ENABLE' ? true : false);
				($scope.categories)[i].businessEmailAlertStatusFlag = ($scope.categories)[i].businessEmailAlertStatus == 'ENABLE' ? true : false;
				($scope.categories)[i].supportEmailAlertStatusFlag = ($scope.categories)[i].supportEmailAlertStatus == 'ENABLE' ? true : false;
			}
		}, function errorCallback(res) {
			//			console.log("getProfile fail")
			//			console.log(res.data)
		})
	}
	//getAllCategories();

	function getCategoriesByPage() {
		var page = {
			page: $scope.pageInfo.page,
			pageSize:12,
			sort: $scope.pageInfo.sort,
			sortBy:$scope.pageInfo.sortBy
		}
		$http({
			method: "POST",
			url: getPageProfileUrl,
			data: page
		}).then(function successCallback(res) {
			//			console.log("getProfile succ")
			//console.log(res.data)
			$scope.categories = res.data.profileList;
			for (var i = 0; i < ($scope.categories).length; i++) {
				($scope.categories)[i].profileStatus = (($scope.categories)[i].status == 'ENABLE' ? true : false);
				($scope.categories)[i].businessEmailAlertStatusFlag = ($scope.categories)[i].businessEmailAlertStatus == 'ENABLE' ? true : false;
				($scope.categories)[i].supportEmailAlertStatusFlag = ($scope.categories)[i].supportEmailAlertStatus == 'ENABLE' ? true : false;
			}
			$scope.pageInfo = res.data;
		//	console.log($scope.pageInfo);
			$scope.pageInfo.totalPage = Math.ceil($scope.pageInfo.total / $scope.pageInfo.pageSize);
			initPages($scope.pageInfo.totalPage);
			calculateRecordNum($scope.pageInfo);
			initProfileCheckBox();
			$scope.allCheckBox = false;
		}, function errorCallback(res) {
			//			console.log("getProfile fail")
			//			console.log(res.data)
		})
	}

	getCategoriesByPage();

	$scope.sort=function(sortBy){
		
		if($scope.pageInfo.sortBy==sortBy){
			$scope.pageInfo.sort=($scope.pageInfo.sort==1?-1:1);
		}else{
			$scope.pageInfo.sortBy=sortBy;
			$scope.pageInfo.sort=-1;
		}
		console.log($scope.pageInfo);
		getCategoriesByPage();
	}
	
	$scope.changeProfileStatus = function() {
		this.category.status = this.category.profileStatus == true ? 'ENABLE' : 'DISABLE';
		$http({
			method: "POST",
			url: updateProfileUrl,
			data: this.category
		}).then(function successCallback(res) {
			console.log("updata profile succ")
			console.log(res.data)

		}, function errorCallback(res) {
			console.log("updata profile fail")
			console.log(res.data)
		})
	}

	$scope.addCrawler = function() {
		var profile = {
			category: $scope.crawlerAdd.category,
			url: $scope.crawlerAdd.url,
			javaClass: $scope.crawlerAdd.javaClass,
			name: $scope.crawlerAdd.name,
			status: "DISABLE",
			supportEmailAlertStatus: "DISABLE",
			businessEmailAlertStatus: "DISABLE",
			createTime: new Date(),
			lastUpdateTime: new Date()
		}
		if (checkCrawlerInfo()) {
			$('#addCrawlerModal').modal('hide');
			$http({
				method: "POST",
				url: saveProfileUrl,
				data: profile
			}).then(function successCallback(res) {
				//				console.log("save profile succ")
				//				console.log(res.data)
				$scope.crawlerAdd = {}
				swal("Success!", "Add the crawler success!", "success");
				//getAllCategories();
				$scope.pageInfo.page=1;
				getCategoriesByPage();
			}, function errorCallback(res) {
				//				console.log("save profile fail")
				//				console.log(res.data)
			})
		}
	}

	function checkCrawlerInfo() {
		$scope.addCrawlerVali = {};
		$scope.addCrawlerValiTip = {};
		var flag = true;
		if (!($scope.crawlerAdd).hasOwnProperty('category') || $scope.crawlerAdd.category == '') {
			$scope.addCrawlerVali.category = true;
			$scope.addCrawlerValiTip.categoryTip = 'Please input category';
			flag = false;
		}
		if (!($scope.crawlerAdd).hasOwnProperty('name') || $scope.crawlerAdd.name == '') {
			$scope.addCrawlerVali.name = true;
			$scope.addCrawlerValiTip.nameTip = 'Please input or select a crawler name';
			flag = false;
		}
		if (!($scope.crawlerAdd).hasOwnProperty('url') || $scope.crawlerAdd.url == '' || $scope.crawlerAdd.url == undefined) {
			$scope.addCrawlerVali.url = true;
			$scope.addCrawlerValiTip.urlTip = 'Please input url with right format';
			flag = false;
		}
		if (!($scope.crawlerAdd).hasOwnProperty('javaClass') || $scope.crawlerAdd.javaClass == '') {
			$scope.addCrawlerVali.javaClass = true;
			$scope.addCrawlerValiTip.javaClassTip = 'Please input javaClass';
			flag = false;
		}
		if ($scope.crawlerAdd.category != '') {
			for (var i = 0; i < ($scope.categories).length; i++) {
				if ($scope.crawlerAdd.category == ($scope.categories)[i].category) {
					$scope.addCrawlerVali.category = true;
					$scope.addCrawlerValiTip.categoryTip = 'Category exsists';
					flag = false;
				}
			}
		}
		if($scope.crawlerAdd.category != ''&&($scope.crawlerAdd).hasOwnProperty('name')){
			var crawlerNameFlag = false
			for(var i=0;i<$scope.crawlerList.length;i++){
				if($scope.crawlerAdd.name==$scope.crawlerList[i].name){
					crawlerNameFlag = true;
					break;
				}
			}
			if(!crawlerNameFlag){
				$scope.addCrawlerVali.name = true;
				$scope.addCrawlerValiTip.nameTip = 'Please choose a crawler form the list';
				flag=false;
			}
		}
		return flag;
	}


	$scope.setDelProfiles = function() {
		for (var i = 0; i < $scope.categories.length; i++) {
			if ($scope.profileCheckBox[$scope.categories[i].category]) {
				$scope.profileDelist.push($scope.categories[i]);
			}
		}
	}

	$scope.deleteCrawler = function() {
		$scope.setDelProfiles();
		//console.log($scope.profileDelist);
		if ($scope.profileDelist && ($scope.profileDelist).length > 0) {
			swal({
				title: "Are you sure?",
				text: "You will delete this crawler from database!",
				type: "warning",
				showCancelButton: true,
				confirmButtonColor: "#DD6B55",
				confirmButtonText: "Delete",
				closeOnConfirm: false
			}, function() {
				$http({
					method: "POST",
					url: deleteProfileAlotUrl,
					data: $scope.profileDelist
				}).then(function successCallback(res) {
					//console.log("delete profile succ")
					//console.log(res.data)
					swal("Deleted!", "This crawler has been deleted.", "success");
					//getAllCategories();
					
					if($scope.pageInfo.currentNum==$scope.profileDelist.length){
						if($scope.pageInfo.page>1){
							$scope.pageInfo.page--;
						}else{
							$scope.pageInfo.page=1;
						}
					}
					getCategoriesByPage();
					
				}, function errorCallback(res) {
					//console.log("delete profile fail")
					//console.log(res.data)
				})

			});
		} else {
			swal("Click CheckBox", "Please select a crawler first!", "warning");
		}
	}

	$scope.configProfile = function() {
		$scope.profileConfig = JSON.parse(JSON.stringify(this.category));
		$scope.crawlerUpdateList = [];
		$http({
			method:"GET",
			url:getCrawlerUrl
		}).then(function successCallback(res){
			console.log("get crawler succ")
			//console.log(res.data)
			$scope.crawlerUpdateList = res.data;
			$scope.configProfileVali = {};
			$scope.configProfileValiTip = {};
		},function errorCallback(res){
			console.log("get crawler fail")
			console.log(res.data)
		})
		//console.log($scope.profileConfig);
	}

	$scope.showProfileConfigInfo = function(){
		var flag = false;
		for(var i=0;i<$scope.crawlerUpdateList.length;i++){
			if($scope.profileConfig.name==$scope.crawlerUpdateList[i].name){
				$scope.profileConfig.javaClass = $scope.crawlerUpdateList[i].javaClass;
				$scope.profileConfig.url = $scope.crawlerUpdateList[i].url;
				flag = true;
				break;
			}
		}
		if(!flag){
			$scope.profileConfig.javaClass = "";
			$scope.profileConfig.url = "";
		}
	}
	
	function checkProfileInfo() {
		$scope.configProfileVali = {};
		$scope.configProfileValiTip = {};
		var flag = true;
		if ($scope.profileConfig.javaClass == '') {
			$scope.configProfileVali.javaClass = true;
			$scope.configProfileValiTip.javaClassTip = 'java_class should not be null';
			flag = false;
		}
		if ($scope.profileConfig.url == '') {
			$scope.configProfileVali.url = true;
			$scope.configProfileValiTip.urlTip = 'url should not be null';
			flag = false;
		}
		if ($scope.profileConfig.url == undefined) {
			$scope.configProfileVali.url = true;
			$scope.configProfileValiTip.urlTip = 'wrong url format';
			flag = false;
		}
		if($scope.profileConfig.name==''){
			$scope.configProfileVali.name = true;
			$scope.configProfileValiTip.nameTip = 'crawler name should not be null';
			flag = false;
		}
		if($scope.profileConfig.name!=''){
			var nameflag = false;
			for(var i=0;i<$scope.crawlerUpdateList.length;i++){
				if($scope.profileConfig.name==$scope.crawlerUpdateList[i].name){
					nameflag = true;
					break;
				}
			}
			if(!nameflag){
				$scope.configProfileVali.name = true;
				$scope.configProfileValiTip.nameTip = 'please select a crawler form the list';
				flag = false;
			}
		}
		return flag;
	}

	$scope.changeProfile = function() {
		if (checkProfileInfo()) {
			$('#profileModal').modal('hide');
			$scope.profileConfig.lastUpdateTime = new Date();
			if (!($scope.profileConfig).hasOwnProperty('createTime')) {
				$scope.profileConfig.createTime = new Date();
			}
			$http({
				method: "POST",
				url: updateProfileUrl,
				data: $scope.profileConfig
			}).then(function successCallback(res) {
				//console.log("updata profile succ")
				//console.log(res.data)
				swal("Success!", "Update profile success!", "success");
				//getAllCategories();
				getCategoriesByPage();
			}, function errorCallback(res) {
				//				console.log("updata profile fail")
				//				console.log(res.data)
			})
		}

	}

	$scope.configAlertRule = function() {
		$scope.profileToUpdate = this.category;
		console.log(this.category);
		if (!(this.category).hasOwnProperty('businessEmailAlert')) {
			//			$scope.alertRule={};
			//			$scope.alertRule.emailTo = [];
			$scope.alertRule = {
				emailTo: [],
				emailCopy: [],
				emailSubject: '',
				emailBody: '',
				keywords: [],
				status: false
			}
		} else {
			$scope.alertRule = {};
			$scope.alertRule = this.category.businessEmailAlert;
			$scope.alertRule.status = this.category.businessEmailAlertStatus=='ENABLE'?true:false;
		}
		$scope.configAlertRuleVali = {};
		$scope.configAlertRuleValiTip = {};
		
		if (!(this.category).hasOwnProperty('supportEmailAlert')) {
			$scope.supportEmail = {
				emailTo: [],
				emailCopy: [],
				emailSubject: '',
				emailBody: '',
				status: false
			}
		} else {
			$scope.supportEmail = {};
			$scope.supportEmail = this.category.supportEmailAlert;
			$scope.supportEmail.status = this.category.supportEmailAlertStatus=='ENABLE'?true:false;
		}
		$scope.configSupportEmailVali = {};
		$scope.configSupportEmailValiTip = {};
	}

	function addEleToArray(array, element) {
		if (element != '') {
			array.push(element);
		}
	}

	function removeEleFromArray(array, element) {
		if (element != '') {
			var index = -1;
			for (var i = 0; i < array.length; i++) {
				if (element == array[i]) {
					index = i;
					array.splice(index, 1);
				}
			}
		}
	}

	function checkEleExsist(array, element) {
		var flag = true;
		for (var i = 0; i < array.length; i++) {
			if (element == array[i]) {
				flag = false;
			}
		}
		return flag;
	}

	$scope.addAlertRuleEmailTo = function() {
		if ($scope.alertRuleAdd.emailTo != undefined && $scope.alertRuleAdd.emailTo != '') {
			$scope.configAlertRuleVali.emailTo = false;
			if (checkEleExsist($scope.alertRule.emailTo, $scope.alertRuleAdd.emailTo)) {
				addEleToArray($scope.alertRule.emailTo, $scope.alertRuleAdd.emailTo);
				$scope.alertRuleAdd.emailTo = '';
			} else {
				$scope.configAlertRuleVali.emailTo = true;
				$scope.configAlertRuleValiTip.emailToTip = 'Email address has exsisted!'
			}
		} else {
			$scope.configAlertRuleVali.emailTo = true;
			$scope.configAlertRuleValiTip.emailToTip = 'Wrong email format!'
		}
	}

	$scope.removeAlertRuleEmailTo = function() {
		removeEleFromArray($scope.alertRule.emailTo, this.email);
	}

	$scope.addAlertRuleEmailCopy = function() {
		if ($scope.alertRuleAdd.emailCopy != undefined && $scope.alertRuleAdd.emailCopy != '') {
			$scope.configAlertRuleVali.emailCopy = false;
			if (checkEleExsist($scope.alertRule.emailCopy, $scope.alertRuleAdd.emailCopy)) {
				addEleToArray($scope.alertRule.emailCopy, $scope.alertRuleAdd.emailCopy);
				$scope.alertRuleAdd.emailCopy = '';
			} else {
				$scope.configAlertRuleVali.emailCopy = true;
				$scope.configAlertRuleValiTip.emailCopyTip = 'Email address has exsisted!'
			}

		} else {
			$scope.configAlertRuleVali.emailCopy = true;
			$scope.configAlertRuleValiTip.emailCopyTip = 'Wrong email format!'
		}
	}

	$scope.removeAlertRuleEmailCopy = function() {
		removeEleFromArray($scope.alertRule.emailCopy, this.emailCopy);
	}

	$scope.addAlertRuleKeyword = function() {
		if ($scope.alertRuleAdd.keyword != '') {
			$scope.configAlertRuleVali.keyword = false;
			if (checkEleExsist($scope.alertRule.keywords, $scope.alertRuleAdd.keyword)) {
				addEleToArray($scope.alertRule.keywords, $scope.alertRuleAdd.keyword);
				$scope.alertRuleAdd.keyword = '';
			} else {
				$scope.configAlertRuleVali.keyword = true;
				$scope.configAlertRuleValiTip.keywordTip = 'Keyword has exsisted!';
			}
		} else {
			$scope.configAlertRuleVali.keyword = true;
			$scope.configAlertRuleValiTip.keywordTip = 'Keyword should not be null!';
		}

	}

	$scope.removeAlertRuleKeyword = function() {
		removeEleFromArray($scope.alertRule.keywords, this.keyword);
	}

	function checkAlertRule(){
		var flag = true;
		if (($scope.alertRule.emailTo).length == 0 && $scope.alertRule.status==true) {
			flag=false;
			$scope.configAlertRuleVali.emailTo = true;
			$scope.configAlertRuleValiTip.emailToTip = 'Lack email address to enable!'
		}
		if (($scope.supportEmail.emailTo).length == 0 && $scope.supportEmail.status == true) {
			flag=false
			$scope.configSupportEmailVali.emailTo = true;
			$scope.configSupportEmailValiTip.emailToTip = 'Lack Email address to enable!'
		}
		return flag;
	}
	
	$scope.updateAlertRule = function() {
		console.log($scope.alertRule);
		 
		if(checkAlertRule()) {
			$scope.profileToUpdate.businessEmailAlert = $scope.alertRule;
			$scope.profileToUpdate.businessEmailAlertStatus = $scope.alertRule.status==true?'ENABLE':'DISABLE';
			$scope.profileToUpdate.supportEmailAlertStatus = $scope.supportEmail.status==true?'ENABLE':'DISABLE';
			if (!($scope.alertRule).hasOwnProperty('createTime')) {
				$scope.profileToUpdate.businessEmailAlert.createTime = new Date();
			}
			$scope.profileToUpdate.businessEmailAlert.lastUpdateTime = new Date();

			$scope.profileToUpdate.supportEmailAlert = $scope.supportEmail;
			if (!($scope.supportEmail).hasOwnProperty('createTime')) {
				$scope.profileToUpdate.supportEmailAlert.createTime = new Date();
			}
			$scope.profileToUpdate.supportEmailAlert.lastUpdateTime = new Date();
			
			$('#alertRuleModal').modal('hide');
			$http({
				method: "POST",
				url: updateProfileUrl,
				data: $scope.profileToUpdate
			}).then(function successCallback(res) {
				//console.log("update alert rule succ")
				//console.log(res.data)
				swal("Success!", "Update Alert Rule success!", "success");
			}, function errorCallback(res) {
				//				console.log("update alert rule fail")
				//				console.log(res.data)
			})
		}

	}

	$scope.addSupportEmailTo = function() {
		if ($scope.supportEmailAdd.emailTo != undefined && $scope.supportEmailAdd.emailTo != '') {
			$scope.configSupportEmailVali.emailTo = false;
			if (checkEleExsist($scope.supportEmail.emailTo, $scope.supportEmailAdd.emailTo)) {
				addEleToArray($scope.supportEmail.emailTo, $scope.supportEmailAdd.emailTo);
				$scope.supportEmailAdd.emailTo = '';
			} else {
				$scope.configSupportEmailVali.emailTo = true;
				$scope.configSupportEmailValiTip.emailToTip = 'Email address has exsisted!'
			}
		} else {
			$scope.configSupportEmailVali.emailTo = true;
			$scope.configSupportEmailValiTip.emailToTip = 'Wrong email format!'
		}
	}

	$scope.removeSupportEmailTo = function() {
		removeEleFromArray($scope.supportEmail.emailTo, this.emailTo);
	}

	$scope.addSupportEmailCopy = function() {
		if ($scope.supportEmailAdd.emailCopy != undefined && $scope.supportEmailAdd.emailCopy != '') {
			$scope.configSupportEmailVali.emailCopy = false;
			if (checkEleExsist($scope.supportEmail.emailCopy, $scope.supportEmailAdd.emailCopy)) {
				addEleToArray($scope.supportEmail.emailCopy, $scope.supportEmailAdd.emailCopy);
				$scope.supportEmailAdd.emailCopy = '';
			} else {
				$scope.configSupportEmailVali.emailCopy = true;
				$scope.configSupportEmailValiTip.emailCopyTip = 'Email address has exsisted!'
			}
		} else {
			$scope.configSupportEmailVali.emailCopy = true;
			$scope.configSupportEmailValiTip.emailCopyTip = 'Wrong email format!'
		}
	}

	$scope.removeSupportEmailCopy = function() {
		removeEleFromArray($scope.supportEmail.emailCopy, this.emailCopy);
	}

	function initPages(total) {
		$scope.pages = {}
		for (var p = 1; p <= total; p++) {
			$scope.pages[p] = p;
		}
	}

	function calculateRecordNum(pageInfo) {
		$scope.fromRecord = parseInt((parseInt(pageInfo.page - 1) * parseInt(pageInfo.pageSize))) + 1
		$scope.toRecord = $scope.fromRecord + pageInfo.currentNum - 1
	}

	$scope.toNextPage = function() {
		if ($scope.pageInfo.page != $scope.pageInfo.totalPage) {
			$scope.pageInfo.page++;
		} else {
			$scope.pageInfo.page = $scope.pageInfo.totalPage
		}
		//		searchBookingList($scope.params)
		//getSchedules();
		getCategoriesByPage();
	}

	$scope.toPage = function(page) {
		$scope.pageInfo.page = page;
		//		searchBookingList($scope.params)
		//getSchedules();
		getCategoriesByPage();
	}

	$scope.toPrevPage = function() {
		if ($scope.pageInfo.page != 1) {
			$scope.pageInfo.page--;
		} else {
			$scope.pageInfo.page = 1;
		}
		//getSchedules();
		getCategoriesByPage();
		//		searchBookingList($scope.params)
	}

	function initProfileCheckBox() {
		if ($scope.categories) {
			for (var i = 0; i < $scope.categories.length; i++) {
				$scope.profileCheckBox[$scope.categories[i].category] = false;
			}
		}
	}
	$scope.selectAllCheckBox = function() {
		for (key in $scope.profileCheckBox) {
			$scope.profileCheckBox[key] = $scope.allCheckBox;
		}
	}

	$scope.setCheckBox = function() {
		if ($scope.profileCheckBox) {
			for (key in $scope.profileCheckBox) {
				if (!$scope.profileCheckBox[key]) {
					$scope.allCheckBox = false;
				}
			}
		}
	}
	
	$scope.openAddCrawlerModal = function(){
		$scope.crawlerList = [];
		$http({
			method:"GET",
			url:getCrawlerUrl
		}).then(function successCallback(res){
			console.log("get crawler succ")
			//console.log(res.data)
			$scope.crawlerList = res.data;
			console.log($scope.crawlerList);
		},function errorCallback(res){
			console.log("get crawler fail")
			console.log(res.data)
		})
	}
	
	$scope.showCrawlerInfo = function(){
		var flag = false;
		for(var i=0;i<$scope.crawlerList.length;i++){
			if($scope.crawlerAdd.name==$scope.crawlerList[i].name){
				$scope.crawlerAdd.javaClass = $scope.crawlerList[i].javaClass;
				$scope.crawlerAdd.url = $scope.crawlerList[i].url;
				flag = true;
				break;
			}
		}
		if(!flag){
			$scope.crawlerAdd.javaClass = "";
			$scope.crawlerAdd.url = "";
		}
	}

})