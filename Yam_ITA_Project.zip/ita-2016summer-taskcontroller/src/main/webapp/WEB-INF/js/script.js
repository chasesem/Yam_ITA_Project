var URL="http://10.222.232.30:9909/controller/task/";

window.onload = function(){
	getData();
}

function getData(){
	console.log("wowo");
	var request = new XMLHttpRequest();
	request.open("GET",URL,true);
	request.send();
	request.onreadystatechange = function(){
		if(request.readyState == 4){
			if(request.status == 200){
				var result = request.responseText;
				document.getElementById("no").innerHTML = result;
				var json = eval("("+result+")");
				toTable(json);
			}else{
				// alert("0readyState:"+request.readyState+"  status:"+request.status);
			}
		}
	}
}

/*
	After getting the data,this function will show these items on the table
*/
function toTable(json){
	cleanTable();
	// alert(json[0].size);
	for(var i=0;i<json.length;i++){
			// alert(json[i].id);
			addItem(json[i].id,"null","null",json[i].status,"null","null");
	}
}

/*
	each time we need to update the table, this function will clean the table into empty
*/
function cleanTable(){
	var parent = document.getElementById("crawlerTable").getElementsByTagName("tbody")[0];
	while(parent.hasChildNodes()){
		parent.removeChild(parent.firstChild);
	}

}

/*
	this function is used to add an item into the table.
*/
function addItem(id,type,host_port,status,completed,average){
	var parent = document.getElementById("crawlerTable").getElementsByTagName("tbody")[0];

	var trEle = document.createElement("tr");
	trEle.className= "";
	parent.appendChild(trEle);

	var tdEleOperation = document.createElement("td");
	tdEleOperation.className= "";
	trEle.appendChild(tdEleOperation);

	var tdEleId = document.createElement("td");
	tdEleId.className = "";
	trEle.appendChild(tdEleId);

	var tdEleType = document.createElement("td");
	tdEleType.innerHTML = type;
	tdEleType.className = "";
	trEle.appendChild(tdEleType);

	var tdEleHostPort = document.createElement("td");
	tdEleHostPort.innerHTML = host_port;
	tdEleHostPort.className = "";
	trEle.appendChild(tdEleHostPort);

	var tdEleStatus = document.createElement("td");
	tdEleStatus.innerHTML = status;
	tdEleStatus.className = "";
	trEle.appendChild(tdEleStatus);

	var tdEleCompleted = document.createElement("td");
	tdEleCompleted.innerHTML = completed;
	tdEleCompleted.className = "";
	trEle.appendChild(tdEleCompleted);

	var tdEleAverage = document.createElement("td");
	tdEleAverage.innerHTML = average;
	tdEleAverage.className = "";
	trEle.appendChild(tdEleAverage);

	var btnRestart = document.createElement("button");
	btnRestart.innerHTML = "Restart";
	btnRestart.className = "";
	btnRestart.setAttribute("onClick","setCrawler('"+id+"','restart')");
	tdEleOperation.appendChild(btnRestart);

	var btnStop = document.createElement("button");
	btnStop.innerHTML = "Kill";
	btnStop.className = "";
	btnStop.setAttribute("onClick","setCrawler('"+id+"','kill')");
	tdEleOperation.appendChild(btnStop);

	var aId = document.createElement("a");
	aId.innerHTML = id;
	aId.className = "";
	tdEleId.appendChild(aId);
}

/*
	this function is used to restart or kill a crawler in this id number.
*/
function setCrawler(id,cmd){
	var request = new XMLHttpRequest();
	request.open("POST",URL,true);
	var data = "node="+id+"&command="+cmd;
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	request.send(data);
	request.onreadystatechange = function(){
		if(request.readyState === 4){
			if(request.status === 200){
				alert(request.responseText);
				getData();
			}else{
				alert("Error code:"+request.status);
			}
		}
	}
	
}