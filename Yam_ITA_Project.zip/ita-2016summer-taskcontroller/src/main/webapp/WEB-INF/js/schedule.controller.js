var realProjectControllers = angular.module("realProjectControllers",[]);
realProjectControllers.controller("scheduleCtrl",function($scope,$rootScope,$http,scheduleService){
	$scope.pageInfo={
		page:1,
		pageSize:2,
		sort:-1
	}
	
	scheduleInit();
	getSchedules();
	$scope.scheduleCheckBox={};//标识每个checkbox
	$scope.currentCategory={};
	$scope.scheduleSwitch={};
	$scope.allCheckBox=false;
	$rootScope.userName=JSON.parse(sessionStorage.getItem("user"));
	function getSchedules(){
//		$http({method:"GET",url:"../JobController/all"}).success((data)=>{
//			console.log(data)
//			$scope.schedules = data;
//			initScheduleCheckBox();
//			$scope.allCheckBox=false;
//		});
		var page = {
			page:$scope.pageInfo.page,
			pageSize:10,
			sort:-1
		}

		$http({
			method:"POST",
			url:"../JobController/pageJob",
			data:page
		}).success((data)=>{
			console.log(data)
			$scope.pageInfo = data;
			$scope.pageInfo.totalPage=Math.ceil($scope.pageInfo.total/$scope.pageInfo.pageSize);
			initPages($scope.pageInfo.totalPage);
			calculateRecordNum($scope.pageInfo)
			$scope.schedules = data.scheduledJob;
			initScheduleCheckBox();
			$scope.allCheckBox=false;
		});
	}
	
	function initScheduleCheckBox(){
		if($scope.schedules){
			for(var i = 0;i < $scope.schedules.length;i++){
				$scope.scheduleCheckBox[$scope.schedules[i].jobId]=false;
				var jobContent = JSON.parse($scope.schedules[i].jobContent);
				$scope.currentCategory[$scope.schedules[i].jobId]=jobContent.category;
				
				if($scope.schedules[i].status=='ENABLE'){
					$scope.scheduleSwitch[$scope.schedules[i].jobId]=true;
				}else{
					$scope.scheduleSwitch[$scope.schedules[i].jobId]=false;
				}
			}
		}
	}
	$scope.selectAllCheckBox=function(){
		for(key in $scope.scheduleCheckBox){
			$scope.scheduleCheckBox[key]=$scope.allCheckBox;
		}
	}
	
	$scope.initProfiles=function(){
		$http.get("../JobController/category").success(function(response){
			$scope.profiles=response;
		})
	}
	$scope.initProfiles();
	
	$scope.addSchedule = function(){
		addOrEditInit2();
		$scope.type = "Add";
		$scope.addOrEdit2.status = "ENABLE";
		$scope.addOrEdit2.jobType = "WebCapture";
		$scope.addOrEdit2.intervalTimeUnit = "seconds";
	}
	$scope.editSchedule = function(schedule){
		console.log(schedule)
		schedule = JSON.parse(JSON.stringify(schedule));
		addOrEditInit();
		$scope.type = "Edit";
		var time = splitTime(schedule.intervalTime)
		schedule.intervalTimeNum = time[0]+'';
		schedule.intervalTimeUnit = time[1]+'';
		$scope.addOrEdit = schedule;
		$scope.addOrEdit.category=$scope.currentCategory[schedule.jobId];
	}
	$scope.addCategory = function(){
		console.log($scope.addOrEdit.category);
		$scope.addOrEdit.categorys.push($scope.addOrEdit.category);
	}
	$scope.addCategory2 = function(){
		console.log($scope.addOrEdit2.category);
		$scope.addOrEdit2.categorys.push($scope.addOrEdit2.category);
	}
	
	$scope.newSchedule = function(){
		$scope.validateAddFields();
		var pass = scheduleService.isAllNotNull($scope.addOrEdit2Flag);
		if(pass){
			$('#editoradd2').modal('hide')
			var data = {
				jobContent:$scope.addOrEdit2.jobContent,
				priority:$scope.addOrEdit2.priority,
				status:$scope.addOrEdit2.status,
				jobType:$scope.addOrEdit2.jobType,
				intervalTime:$scope.addOrEdit2.intervalTimeNum+$scope.addOrEdit2.intervalTimeUnit+""
			};
			$http({
				method:"POST",
				url:"../JobController/job/new",
				data:data
			}).success((data)=>{
				console.log(data)
				if(data.operation=="success"){
					swal("Success!", "Add the job success!", "success")
					getSchedules();
				}
			})
		}
	}
	
	
	$scope.delSchedule = function(schedule){
		$http({
			method:"GET",
			url:"../JobController/job/old/"+schedule.jobId,
		}).success((data)=>{
			console.log(data)
			if(data.operation=="success"){
				
				getSchedules();
			}
		})
	}
	$scope.delSchedules = function(){
		$scope.setDelSchedules();
		console.log($scope.scheduleDelist);
		if($scope.scheduleDelist&&$scope.scheduleDelist.length>0){
			swal({   title: "Are you sure?",   text: "The selected jobs will be deleted.",
				type: "warning",   showCancelButton: true,
				confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, delete it!",
				closeOnConfirm: false }, function(){  
					$http({
						method:"post",
						url:"../JobController/job/alot",
						data:$scope.scheduleDelist
					}).success((data)=>{
						console.log(data);
						if(data.operation=="success"){
							swal("Deleted Success!", "The selected jobs has been deleted.", "success");
							if($scope.schedules.length==$scope.scheduleDelist.length){
								$scope.pageInfo.page=1;
							}
							getSchedules();
							$scope.scheduleDelist=[];
							
						}
					})
			});
		}
	}
	$scope.addOrEdit2Tip={}
	$scope.validateAddFields=function(){
		$scope.addOrEdit2Flag=[];
		$scope.addOrEdit2Flag.push(scheduleService.isNotNull($scope.addOrEdit2.jobContent));
		$scope.addOrEdit2Flag.push(scheduleService.isNotNull($scope.addOrEdit2.intervalTimeNum));
		$scope.addOrEdit2Flag.push(scheduleService.isNotNull($scope.addOrEdit2.priority));
		if(!scheduleService.isNotNull($scope.addOrEdit2.jobContent)){
			$scope.addOrEdit2Tip.jobContentTip="Sorry, Content should not be null...";
		}else{
			try {
				JSON.parse($scope.addOrEdit2.jobContent);
				$scope.addOrEdit2Tip.jobContentTip="";
			}catch (e) {
				$scope.addOrEdit2Tip.jobContentTip="Sorry, Content format should be json...";
				$scope.addOrEdit2Flag.push(false);
			}
		}
		if(!scheduleService.isNotNull($scope.addOrEdit2.intervalTimeNum)){
			$scope.addOrEdit2Tip.intervalTimeNumTip="Sorry, interval Time should not be null...";
		}else{
			if(scheduleService.isDigit($scope.addOrEdit2.intervalTimeNum)){
				$scope.addOrEdit2Tip.intervalTimeNumTip="";
			}else{
				$scope.addOrEdit2Flag.push(false);
				$scope.addOrEdit2Tip.intervalTimeNumTip="Sorry, interval Time should be digit...";
			}
		}
		
		if(!scheduleService.isNotNull($scope.addOrEdit2.priority)){
			$scope.addOrEdit2Tip.priorityTip="Sorry, priority should not be null...";
		}else{
			if(scheduleService.isDigit($scope.addOrEdit2.priority)){
				$scope.addOrEdit2Tip.priorityTip="";
			}else{
				$scope.addOrEdit2Flag.push(false);
				$scope.addOrEdit2Tip.priorityTip="Sorry, priority should be digit...";
			}
		}
	}
	
	$scope.addOrEditTip={}
	$scope.validateFields=function(){
		$scope.addOrEditFlag=[];
		$scope.addOrEditFlag.push(scheduleService.isNotNull($scope.addOrEdit.jobContent));
		$scope.addOrEditFlag.push(scheduleService.isNotNull($scope.addOrEdit.intervalTimeNum));
		$scope.addOrEditFlag.push(scheduleService.isNotNull($scope.addOrEdit.priority));
		if(!scheduleService.isNotNull($scope.addOrEdit.jobContent)){
			$scope.addOrEditTip.jobContentTip="Sorry, Content should not be null...";
		}else{
			try {
				JSON.parse($scope.addOrEdit.jobContent);
				$scope.addOrEditTip.jobContentTip="";
			}catch (e) {
				$scope.addOrEditTip.jobContentTip="Sorry, Content format should be json...";
				$scope.addOrEditFlag.push(false);
			}
		}
		if(!scheduleService.isNotNull($scope.addOrEdit.intervalTimeNum)){
			$scope.addOrEditTip.intervalTimeNumTip="Sorry, interval Time should not be null...";
		}else{
			if(scheduleService.isDigit($scope.addOrEdit.intervalTimeNum)){
				$scope.addOrEditTip.intervalTimeNumTip="";
			}else{
				$scope.addOrEditFlag.push(false);
				$scope.addOrEditTip.intervalTimeNumTip="Sorry, interval Time should be digit...";
			}
		}
		if(!scheduleService.isNotNull($scope.addOrEdit.priority)){
			$scope.addOrEditTip.priorityTip="Sorry, priority should not be null...";
		}else{
			if(scheduleService.isDigit($scope.addOrEdit.priority)){
				$scope.addOrEditTip.priorityTip="";
			}else{
				$scope.addOrEditFlag.push(false);
				$scope.addOrEditTip.priorityTip="Sorry, priority should be digit...";
			}
		}
	}
	
//	$scope.setSchedules = function(schedule){
//		for(var i=0;i<$scope.scheduleDelist.length;i++){
//			if($scope.scheduleDelist[i]==schedule){
//				flag = false;
//				$scope.scheduleDelist.splice(i,1);
//				return;
//			}
//		}
//		$scope.scheduleDelist.push(schedule);
//	}
	$scope.setCheckBox=function(){
		if($scope.scheduleCheckBox){
			for(key in $scope.scheduleCheckBox){
				if(!$scope.scheduleCheckBox[key]){
					$scope.allCheckBox=false;
				}
			}
		}
	}
	
	$scope.setDelSchedules = function(){
		for(var i=0;i<$scope.schedules.length;i++){
			if($scope.scheduleCheckBox[$scope.schedules[i].jobId]){
				$scope.scheduleDelist.push($scope.schedules[i]);
			}
		}
	}
	
	$scope.updateSchedule = function(){
		$scope.validateFields();
		var pass = scheduleService.isAllNotNull($scope.addOrEditFlag);
		if(pass){
			$('#editoradd').modal('hide')
			var data = {
				jobId:$scope.addOrEdit.jobId,
				jobContent:$scope.addOrEdit.jobContent,
				priority:$scope.addOrEdit.priority,
				status:$scope.addOrEdit.status,
				jobType:$scope.addOrEdit.jobType,
				intervalTime:$scope.addOrEdit.intervalTimeNum+$scope.addOrEdit.intervalTimeUnit+""
			};
			console.log(data);
			$http({
				method:"POST",
				url:"../JobController/job",
				data:data
			}).success((data)=>{
				console.log(data)
				if(data.operation=="success"){
					swal("Update Success!", "Update the job info success!", "success")
					getSchedules();
				}
			})
		}
		
	}
	function scheduleInit(){
		$rootScope.active = "schedule";
		addOrEditInit();
		$scope.scheduleDelist = [];
	}
	function addOrEditInit(){
		$scope.addOrEdit = {};
		$scope.addOrEdit.categorys = [];
	}
	function addOrEditInit2(){
		$scope.addOrEdit2 = {};
		$scope.addOrEdit2.categorys = [];
	}
	
	
	function initPages(total){
		$scope.pages={}
		for (var p = 1; p <= total; p++) {
			$scope.pages[p] = p;
		}
	}
	function calculateRecordNum(pageInfo){
		$scope.fromRecord = parseInt((parseInt(pageInfo.page-1) * parseInt(pageInfo.pageSize)))+1
		$scope.toRecord = $scope.fromRecord+pageInfo.currentNum-1
	}
	
	function splitTime(str){
		var a=str.match(/\d+/gi);
		console.log(a[0]);
		var b=str.match(/\D+/gi);
		console.log(b[0])
		return [a,b];
	}
	
	$scope.setAdd2Content=function(){
		console.log("****************")
		var content = {
			"category":$scope.addOrEdit2.category,
			"sender":"Scheduler"
		}
		$scope.addOrEdit2.jobContent = JSON.stringify(content);
	}
	
	
	$scope.setEditContent=function(){
		console.log("****************")
		var content = {
			"category":$scope.addOrEdit.category,
			"sender":"Scheduler"
		}
		$scope.addOrEdit.jobContent = JSON.stringify(content);
	}
	
	$scope.changeStatus=function(schedule){
		var status = schedule.status;
		if(!$scope.scheduleSwitch[schedule.jobId]){
			schedule.status='DISABLE';
			$scope.scheduleSwitch[schedule.jobId]=false;
		}else{
			schedule.status='ENABLE';
			$scope.scheduleSwitch[schedule.jobId]=true;
		}
		$http({
			method:"POST",
			url:"../JobController/job",
			data:schedule
		}).success((response)=>{
			if(response.operation=="success"){}
		}).error((response)=>{
			schedule.status=status;
			if(schedule.status=="ENABLE"){
				$scope.scheduleSwitch[schedule.jobId]=true;
			}else{
				$scope.scheduleSwitch[schedule.jobId]=false;
			}
		})
	}
	
	
	$scope.toNextPage = function() {
		if($scope.pageInfo.page!=$scope.pageInfo.totalPage){
			$scope.pageInfo.page++;
		}else{
			$scope.pageInfo.page=$scope.pageInfo.totalPage
		}
//		searchBookingList($scope.params)
		getSchedules();
	}
	
	$scope.toPage = function(page) {
		$scope.pageInfo.page = page;
//		searchBookingList($scope.params)
		getSchedules();
	}
	
	$scope.toPrevPage = function() {
		if($scope.pageInfo.page!=1){
			$scope.pageInfo.page--;
		}else{
			$scope.pageInfo.page = 1;
		}
		getSchedules();
//		searchBookingList($scope.params)
	}
});