var realProject = angular.module("realProject", ["ngRoute","realProjectServices","realProjectControllers","uiSwitch","realProjectFilters"]);
const urlPrefix = "../views/templates/";
realProject.config(function ($routeProvider) {
	$routeProvider
	.when("/schedule",{
		templateUrl:urlPrefix+"Schedule.html",
		controller:"scheduleCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.when("/message",{
		templateUrl:urlPrefix+"Message.html",
		controller:"messageCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.when("/configure",{
		templateUrl:urlPrefix+"Configure.html",
		controller:"configureCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.when("/search",{
		templateUrl:urlPrefix+"Search.html",
		controller:"searchCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.when("/statistics",{
		templateUrl:urlPrefix+"Statistics.html",
		controller:"statisticsCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.when("/outline",{
		templateUrl:urlPrefix+"Outline.html",
		controller:"outlineCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.when("/crawler",{
		templateUrl:urlPrefix+"Crawler.html",
		controller:"crawlerCtrl",
		resolve:[
                 "$http",
                 "$q",
                 getPermissions
                 ]
	})
	.otherwise({ redirectTo: '/schedule' })
})
function getPermissions($http, $q) {
		var defer = $q.defer();
		if (!sessionStorage.getItem("user")) {
			window.location.href = "Login.html"
		}
		defer.resolve();
		return defer.promise;
		
	}
