realProjectControllers.controller("searchCtrl",function($scope,$rootScope,$http,$filter,$interval){
	$scope.pageNumber=1
	$scope.isAction=true
	$scope.markItem='taskCreateTime'
    $scope.searchCondition={}
	$scope.inputDisable=true
	$scope.searchCondition.select='ALL'
	$scope.sCondition={}
	$scope.newCondition={}
	$scope.markAction=''
	$scope.buttonDisable=true
	$scope.markLastPage=false
	
	function setInitDateRange(today,seventDaysAgo,fromToDate,alldaterange,fromInput,toInput){
		fromToDate.fromDate = seventDaysAgo;
		fromToDate.toDate = today;
		alldaterange.fromDate = {
		"singleDatePicker": true,
		"showDropdowns": true,
		"timePicker": true,
		"timePicker24Hour":true,
		"maxDate": today,
		"startDate":seventDaysAgo,
		"minDate": "1/1/2000",
		"opens":"center",
		"timePickerSeconds": true,
		"linkedCalendars":false,
		locale: {
		format: 'MM/DD/YYYY HH:mm：ss',
		"applyLabel": "OK"
		}
		}; 
		alldaterange.toDate = JSON.parse(JSON.stringify(alldaterange.fromDate));
		alldaterange.toDate.startDate = today;
		alldaterange.toDate.maxDate = today;
		$(fromInput).daterangepicker(alldaterange.fromDate,function(start,end){
			fromToDate.fromDate = start._d;
		});
		$(toInput).daterangepicker(alldaterange.toDate,function(start){
			fromToDate.toDate = start._d;
			var newstartDate = start._d.getTime();
			var oldstartDate = fromToDate.fromDate.getTime();
			alldaterange.fromDate.maxDate = start._d;
		if(oldstartDate>newstartDate){
			newstartDate = new Date(newstartDate);
			newstartDate.setHours(0);
			newstartDate.setMinutes(0);
			newstartDate.setSeconds(0);
			alldaterange.fromDate.startDate = newstartDate;
			fromToDate.fromDate = newstartDate;
			console.log(alldaterange.fromDate);
			swal("From Date should not be late than To Date.", "System automatically set it to the right time.","warning");
		}else{
			alldaterange.fromDate.startDate = fromToDate.fromDate;
		}
		$(fromInput).daterangepicker(alldaterange.fromDate,function(start,end){
			fromToDate.fromDate = start._d;
		});
		});
	}

	// startDate控件
	$(function(){
		var today = new Date();
		var seventDaysAgo = new Date(today.getTime()-1000*60*60*24*7);
		seventDaysAgo.setHours(0);
		seventDaysAgo.setMinutes(0);
		seventDaysAgo.setSeconds(0);
		today.setHours(23);
		today.setMinutes(59);
		today.setSeconds(59);
		
		$scope.daterange = {};
		var fromInput = "input[name=\"daterange\"]";
		var toInput = "input[name=\"daterange2\"]";
		setInitDateRange(today,seventDaysAgo,$scope.searchCondition,$scope.daterange,fromInput,toInput)
	})
	   var firstObjec={
			startTime:$scope.searchCondition.fromDate,
			endTime:$scope.searchCondition.toDate,
			sortBy:'taskCreateTime',
			sort:-1,
			key:null,
			value:null,
			page:1
	}	
	
	searchByCondition(firstObjec)
	
	searchInit();
//	var interval = $interval(function(){searchByCondition($scope.newCondition)},3000)
	function searchInit(){
		$rootScope.active="search";
		$scope.taskCheckBox = {};
		$scope.allCheckBox = false;
		$scope.delList = [];
	}
	function getDelList(){
		$scope.delList = [];
		for(key in $scope.taskCheckBox){
			if($scope.taskCheckBox[key]){
				$scope.delList.push(key);
			}
		}
		console.log($scope.delList);
		
	}
	$scope.markCheckBox=0
	//判断是否存在没勾选的checkbox,如果存在把allCheckBox设为false
	$scope.setCheckBok=function(){
		setCheckBok ()
	}
	function setCheckBok (){

		if($scope.taskCheckBox){
			var count = 0;
			var length = 0;
			for(key in $scope.taskCheckBox){
				if(!$scope.taskCheckBox[key]){
					$scope.allCheckBox = false;
					//break;
				}else{
					count++;
					$scope.markCheckBox++;
				}
			}
			//如果存在勾选的把button可点�
			if(count>0){
				$scope.buttonDisable=false
			}else{
				$scope.buttonDisable=true
			}
			for(key in $scope.taskCheckBox){
				length++;
			}
			if(count==length){
				$scope.allCheckBox = true;
			}
		}
	}
	$scope.seletAllCheckBox = function(){
		if($scope.taskCheckBox){
			if(!$scope.allCheckBox){
				for(key in $scope.taskCheckBox){
					$scope.taskCheckBox[key]=false;
				}
			}else{
				for(key in $scope.taskCheckBox){
					$scope.taskCheckBox[key]=true;
				}
			}
		}
		setCheckBok ()
	}
	//search by condition
	$scope.search=function(searchCondition){
		$scope.pageNumber=1
		$scope.markAction='search'
		console.log("today:::"+searchCondition)
		console.log(searchCondition)
		searchByCondition(validationObject(searchCondition))
	}
	
	//reprocess
	$scope.reprocss=function(){
		getDelList()
		$scope.repMsg=$scope.delList
		console.log($scope.repMsg)
		
	}
	//AddNewTask
	$scope.AddNewTask=function(repMsg){
		console.log(JSON.stringify($scope.delList))
		swal({   
			title: "Are you sure reprocess they?",  
			text: "",   
			type: "warning", 
			showCancelButton: true, 
			confirmButtonColor: "#DD6B55",  
			confirmButtonText: "Yes, reprocess it!",   
			closeOnConfirm: false },
			function(){  
				
				$http({
					method:'post',
					url:'../ReciverTaskController/reprocessTask',	
					data:$scope.delList
				}).success(function(data){
				   console.log(data)
				   swal("Success!", "", "success");
				   searchByCondition($scope.newCondition)
				   // $scope.detail=data
				}).error(function(data,status,headers,config){
					swal("The booking has been rejected fail","","warning")
				})
				
				});
	}
   //sort
	$scope.sortMap={}
	$scope.descSortPic={}
	$scope.ascSortPic={}
	$scope.changeSort=function(field){
		
		$scope.descSortPic={}
		$scope.ascSortPic={}
		if(field=='taskId'){
			 $scope.sCondition.sortBy='_id'
			}else{
			 $scope.sCondition.sortBy=field
			}
		if($scope.sortMap[field]=='DESC'){
			$scope.sCondition.sort=-1
		}else{
			$scope.sCondition.sort=1
		}
		if($scope.sortMap[field]){
		if($scope.sortMap[field]=='DESC'){
			$scope.sortMap[field]='ASC'
			$scope.ascSortPic[field]=false;
			$scope.descSortPic[field]=true;
		}else if($scope.sortMap[field]=='ASC'){
			$scope.sortMap[field]='DESC'
			$scope.ascSortPic[field]=true;
			$scope.descSortPic[field]=false;
		}
		}else{
			$scope.sortMap[field] = "DESC"
			$scope.descSortPic[field]=false;
			$scope.ascSortPic[field]=true;
		}
		searchByCondition($scope.sCondition)
	}
	//changeNum
	$scope.changeNum=function(num){
		if(num==-1){
			$scope.pageNumber=$scope.pageNumber-1
		}else{
			$scope.pageNumber=$scope.pageNumber+1
		}
		changePages()
	}
	//change page
	$scope.changePage=function(){
		changePages()
	}
	function changePages(){
		var arr=[]
	  $scope.markAction=''
		  if($scope.pageNumber==undefined||$scope.pageNumber==null){
			  $scope.pageNumber=1  
		  }
		  if($scope.pageNumber<1){
			  $scope.pageNumber=1
		  }else{
			  if(!/^\d+$/.test($scope.pageNumber)){ 
				  $scope.pageNumber=parseInt($scope.pageNumber)
			  }
			  if($scope.pageNumber>$scope.totalPage){
				  $scope.pageNumber=$scope.totalPage
			  }
			 
		  }
		if($scope.totalPage>1){
			
			if($scope.pageNumber==$scope.totalPage){
				
				calculateRecordNum($scope.totalElement%10)
			}else{
				calculateRecordNum(10)
			}
		}else{
			$scope.startEle=1
			$scope.endEle=$scope.totalElement
		}  
		  
	      
	 $scope.sCondition.page=$scope.pageNumber
	 console.log($scope.sCondition)
	 searchByCondition($scope.sCondition)	
	}
	
	function calculateRecordNum(pageSize){
		if($scope.pageNumber==$scope.totalPage){
			$scope.endEle=$scope.totalElement
			$scope.startEle=$scope.totalElement-pageSize+1
		}else{
		$scope.startEle = parseInt((parseInt($scope.pageNumber-1) * parseInt(pageSize)))+1
		$scope.endEle = $scope.startEle+parseInt(pageSize)-1
		}
	}
	//remove the inputcontent
	$scope.removeContent=function(){
		$scope.searchCondition.input=''
	}
	function searchByCondition(objec){
		$scope.sCondition=objec
		$scope.newCondition=objec
//		console.log($filter('date')(objec.startTime, 'yyyy-MM-dd HH:mm:ss'))
//		console.log($filter('date')(objec.endTime, 'yyyy-MM-dd HH:mm:ss'))
		$http({
			method:'post',
			url:'../ReciverTaskController/query',	
			data:{
				startTime:$filter('date')(objec.startTime, 'yyyy-MM-dd HH:mm:ss'),
				endTime:$filter('date')(objec.endTime, 'yyyy-MM-dd HH:mm:ss'),
				sortBy:objec.sortBy,
				sort:objec.sort,
				key:objec.key,
				value:objec.value,
				page:objec.page
			}
		}).success(function(data){
			//sessionStorage.setItem('result',JSON.tringify(data))
			$scope.taskList=data
			for(key in data){
				$scope.taskCheckBox[data[key].taskId] = false;
			}
			if(data=='' && $scope.markAction=='search'){
				swal("change condition and Try again!", "");
			}
			if(data.length>0){
				$scope.totalElement=data[0].length;
				$scope.totalPage=Math.ceil(data[0].length/10) 	
			}else{
				$scope.totalElement = 0;
			}
			if($scope.pageNumber==1){
				$scope.startEle=1
				if($scope.totalPage==1){
					$scope.endEle=$scope.totalElement
				}else{
					$scope.endEle=10
				}
				
			}
			
		}).error(function(data,status,headers,config){
			swal("The booking has been rejected fail","","warning");
		})
	}
	//view Detail
	$scope.showDetail=function(id){
		$scope.show=false;
		console.log(id)
			$http({
			method:'get',
			url:'../ReciverTaskController/queryDetail',	
			params:{
				id:id
			}
		}).success(function(data){
		    $scope.detail=data
		    console.log($scope.detail)
		}).error(function(data,status,headers,config){
			swal("The booking has been rejected fail","","warning");
		})
	}
	//more detail
	$scope.showMore=function(){
	
		if($scope.show){
			$scope.show=false;
		}else{
			$scope.show=true;
		}
		if($scope.detail.resultList!=undefined){
			console.log($scope.detail.resultList)
			$scope.resultDetail=JSON.parse($scope.detail.resultList)
		}else{
			$scope.resultDetail=null
		}
	}
	
	function validationObject(searchObject){
		var newObject={}
		if(isEmptyObject(searchObject)){
			newObject.startTime=null
			newObject.endTime=null
			newObject.key=null
			newObject.value=null
		}else {
			for(item in searchObject){
				if(item=='fromDate'){
					newObject.startTime=searchObject[item]
				}else if(item=='toDate'){
					newObject.endTime=searchObject[item]
				}else if(item=='select'){
				   newObject.key=searchObject[item]
				}else{
					if(searchObject[item]==''){
						newObject.value=null
					}else{
						newObject.value=searchObject[item]
					}
					
				}
			}
			newObject.page=$scope.pageNumber
			newObject.sortBy='taskCreateTime'
			newObject.sort=-1	
		}
       console.log(newObject)
       if(!objectExist(newObject,'startTime')){
    	   newObject.startTime=null
       }
	   if(!objectExist(newObject,'endTime')){
		   newObject.endTime=null
	   }
		if(objectExist(newObject,'value')){
			
		}else{
			newObject.value=null
		}
       if(newObject.key=='ALL'){
    	   newObject.key=null
    	   newObject.value=null
       }
		return newObject
	}
	//判断对象里是否存在某个对�
	function objectExist(obj,item){
		for (var key in obj) {
			if(key==item){
				  return true;
			}
		  }
		  return false;
	}
	//判断对象是否为空
	function isEmptyObject(obj) {
		  for (var key in obj) {
		    return false;
		  }
		  return true;
		}
	//today加一
	function getDefaultDate(startDate) {
		if(startDate!=null){
			var year = startDate.getFullYear();
			var month = (startDate.getMonth() + 1) < 10 ? ("0" + (startDate.getMonth() + 1)) : (startDate.getMonth() + 1);
			var day = startDate.getDate() < 10 ? ("0" + startDate.getDate()) : startDate.getDate();
			var hours = startDate.getHours() < 10 ? ("0" + startDate.getHours()) : startDate.getHours();
			var minutes = startDate.getMinutes() < 10 ? ("0" + startDate.getMinutes()) : startDate.getMinutes();
			var seconds = startDate.getSeconds() < 10 ? ("0" + startDate.getSeconds()) : startDate.getSeconds();
			var milliseconds = startDate.getMilliseconds();
			if (milliseconds < 10) {
			milliseconds = ".00" + milliseconds;
			} else if (milliseconds < 100) {
			milliseconds = ".0" + milliseconds;
			} else {
			milliseconds = "." + milliseconds;
			}
		   // day=day+1;
			var startDateString = year + month + day + hours + minutes + seconds + milliseconds;
			return startDateString;	
		}else{
			return null
		}

		}
	//判断select 框是否选择All
	$scope.selectStatus=function(msg){
		
		if(msg=='ALL'){
			$scope.inputDisable=true
			$scope.searchCondition.input=''
		}else{
			$scope.inputDisable=false
		}
	
	}
	//validion
	function validateFromDataAndToDate(searchCondition){	  
		   var mark=''
		   $scope.mark=''
		   $scope.markfs=''
		   $scope.markvstd=''
		   $scope.markvsfd=''
		   $scope.markALL=''
		   $scope.markgt=''//fromdate大于today，today也大于today
		   $scope.markgfdtd=''//fromdate不能大于today
	//	   $scope.inputDisable=false	   
		   today=$filter('date')(new Date(), 'yyyyMMddHHmmss.sss')
		   //判断searchCondition对象是否为空
		   if(isEmptyObject(searchCondition)){
			   return mark
		   }else{
			   //select 有信息，input框没输入
			   if(searchCondition.select!=null&&searchCondition.select!=undefined&&searchCondition.select!='ALL'){
				   if(searchCondition.input==''||searchCondition.input==undefined){
					   mark="ALL"
					   $scope.markALL='ALL'
					   searchCondition.input=''
					 //  $scope.inputDisable=true	  
					   return mark
				   }else{
					   //$scope.inputDisable=false	  
				   }
			   }
			   //toDate和fromDate都存�
			   if(searchCondition.toDate!=null&&searchCondition.fromDate!=null&&searchCondition.toDate!=undefined&&searchCondition.fromDate!=undefined){
				   var toDate=$filter('date')(searchCondition.toDate, 'yyyyMMddHHmmss.sss');
				   var fromDate=$filter('date')(searchCondition.fromDate, 'yyyyMMddHHmmss.sss')	
				   if(fromDate>today||toDate>today){
					        mark="gt"
						    $scope.markgt='gt'
						    return mark
				   }else if(fromDate>toDate){
					        mark="gfdtd"
						    $scope.markgfdtd='gfdtd'
						    return mark
				   }
			   }
			   if(searchCondition.toDate==undefined&&searchCondition.fromDate!=undefined){
				          mark="vstd"
					      $scope.markvstd='vstd'
					      return mark
			   }
			   if(searchCondition.toDate!=undefined&&searchCondition.fromDate==undefined){
			          mark="vsfd"
				      $scope.markvsfd='vsfd'
				      return mark
		      }
		   }
		   return mark
		}
	
	$scope.getState = function(state){
		if($scope.searchCondition.select =='taskStatus'){
			if(state==""){
				$scope.states =undefined
			}
			var flag = false;
			if($scope.states !=undefined){
				for(var i = 0 ; i < $scope.states.length ; i++){
					if($scope.states[i]==state){
						flag = true;
					}
				}
			}
			var callback=function(errorFlag,showDiv,response){
				if(response){
					$scope.states=response
				}
			}
			if(!flag){
				getLocationReply("../ReciverTaskController/taskState",state,callback)
			}
		}
	}
	
	$scope.setState = function(state){
		if($scope.searchCondition.select =='taskStatus'){
			console.log($scope.searchCondition.input)
		}
	}
	
	function getLocationReply(url,name,callback){
		if(name!=null&&name!=''){
			$http.get(url+"?state="+name).success(function(response){
				callback(true,true,response)// errorflag,showDiv,response
			})
		}else{
			callback(false,false)// errorflag,showDiv
		}
	} 
})