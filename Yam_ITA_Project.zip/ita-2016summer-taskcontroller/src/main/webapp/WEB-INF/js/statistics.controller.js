realProjectControllers.controller("statisticsCtrl",function($scope,$rootScope,$http,$filter){
	statisticsInit();
	$scope.alldaterangeCheck = false;
	function statisticsInit(){
		$rootScope.active="statistics";
		$scope.allWebFromToDate = {};
		$scope.allWebstatus = "All";
		$scope.oneWebFromToDate = {};
		$scope.categoryList = getCategories();
		$scope.oneInterval = 20;
		$scope.oneIntervalUnit = "Hour";
	}
	$scope.oneIntervalVal = function(){
		$scope.oneInterval = $scope.oneInterval.replace(/\D/g,'');
		oneIntervalValFn();
	}
	function oneIntervalValFn(){
		var resulet = false;
		$scope.oneIntervalValMsg = undefined;
		if($scope.oneInterval!==''&&$scope.oneInterval!=undefined){
			var fromDate = $scope.oneWebFromToDate.start.getTime();
			var toDate = $scope.oneWebFromToDate.end.getTime();
			var rate = 0;
			switch($scope.oneIntervalUnit){
				case "Hour":
					rate = 1;break;
				case "Day":
					rate = 24;break;
			}
			var check =  Math.round((toDate-fromDate)/(60*60*1000*rate*$scope.oneInterval));
			if(check>=25){
				$scope.oneIntervalValMsg = "The interval is too short.";
			}else{
				$scope.oneIntervalValMsg = undefined;
				resulet = true;
			}
		}else{
			$scope.oneIntervalValMsg = "Interval cannot be empty.";
		}
		return resulet;
	}
	function getCategories(){
		var list = [];
		$http({
			method:"GET",
			url:"../statistics/allCategories"
		}).success((data)=>{
			for(index in data){
				list.push(data[index].category);
			}
			$scope.oneWebsite = list[0];
			initSearch();
		})
		console.log(list);
		return list;
	}
	function setInitDateRange(today,seventDaysAgo,fromToDate,alldaterange,fromInput,toInput){
		fromToDate.start = seventDaysAgo;
		fromToDate.end = today;
		alldaterange.fromDate = {
				"singleDatePicker": true,
				"showDropdowns": true,
				"timePicker": true,
				"timePicker24Hour":true,
				"maxDate": today,
				"startDate":seventDaysAgo,
				"minDate": "1/1/2000",
				"opens":"center",
				"timePickerSeconds": true,
				"linkedCalendars":false,
				locale: {
					format: 'MM/DD/YYYY HH:mm：ss',
					"applyLabel": "OK"
				}
		}; 
		alldaterange.toDate = JSON.parse(JSON.stringify(alldaterange.fromDate));
		alldaterange.toDate.startDate = today;
		alldaterange.toDate.maxDate = today;
		$(fromInput).daterangepicker(alldaterange.fromDate,(start,end)=>{
			fromToDate.start = start._d;
		});
		$(toInput).daterangepicker(alldaterange.toDate,(start,end)=>{
			fromToDate.end = start._d;
			var newstartDate = start._d.getTime();
			var oldstartDate = fromToDate.start.getTime();
			alldaterange.fromDate.maxDate = start._d;
			if(oldstartDate>newstartDate){
				newstartDate = new Date(newstartDate);
				newstartDate.setHours(0);
				newstartDate.setMinutes(0);
				newstartDate.setSeconds(0);
				alldaterange.fromDate.startDate = newstartDate;
				fromToDate.start = newstartDate;
				console.log(alldaterange.fromDate);
				swal("From Date should not be late than To Date.", "System automatically set it to the right time.");
			}else{
				alldaterange.fromDate.startDate = fromToDate.start;
			}
			$(fromInput).daterangepicker(alldaterange.fromDate,(start,end)=>{
					fromToDate.start = start._d;
				});
			});
	}
		function initDateRange(today,seventDaysAgo){
//			ALL WEB
			$scope.alldaterange = {};
			var fromInput = "input[name=\"alldaterangeFrom\"]";
			var toInput = "input[name=\"alldaterangeTo\"]";
			setInitDateRange(today,seventDaysAgo,$scope.allWebFromToDate,$scope.alldaterange,fromInput,toInput)
//			ONE WEB
			fromInput = "input[name=\"onedaterangeFrom\"]";
			toInput = "input[name=\"onedaterangeTo\"]";
			$scope.onedaterange = {};
			setInitDateRange(today,seventDaysAgo,$scope.oneWebFromToDate,$scope.onedaterange,fromInput,toInput)
		}
		
	function initSearch(){
		var today = new Date();
		today.setHours(23);
		today.setMinutes(59);
		today.setSeconds(59);
		var seventDaysAgo = new Date(today.getTime()-1000*60*60*24*7);
		seventDaysAgo.setHours(0);
		seventDaysAgo.setMinutes(0);
		seventDaysAgo.setSeconds(0);
		var fromDate=$filter('date')(seventDaysAgo, 'yyyy-MM-dd HH:mm:ss');
		var toDate=$filter('date')(today, 'yyyy-MM-dd HH:mm:ss');
		allWebSearchFn(fromDate,toDate);
		oneWebSearchFn(fromDate,toDate);
		initDateRange(today,seventDaysAgo);
	}
	//All Web Capturing Volume Search
	$scope.allWebSearch = function(){
		var fromDate=$filter('date')($scope.allWebFromToDate.start, 'yyyy-MM-dd HH:mm:ss');
		var toDate=$filter('date')($scope.allWebFromToDate.end, 'yyyy-MM-dd HH:mm:ss');
		allWebSearchFn(fromDate,toDate);
	}
	function allWebSearchFn(fromDate,toDate){
		var data = {
			fromDate:fromDate,
			toDate:toDate,
			status:$scope.allWebstatus.toLowerCase()
		};
		console.log(data);
		$http({
			method:"POST",
			data:data,
			url:"../statistics/generalStatistics"
		}).success((data)=>{
			getAllWebSearch(data);
		})
	}
	function getAllWebSearch(data){
		// $scope.allcategories = [];
		$scope.allseries = [];
		// for(index in data){
		// 	getCategory(data[index]);
		// }
		if($scope.allWebstatus=="All"){
			getallSeriesALL(data);
		}else{
			getallSeriesElse(data);
		}
		$scope.total.xAxis.categories = $scope.categoryList;
		$scope.total.series = $scope.allseries; 
		$scope.total.subtitle.text = 'Status : '+$scope.allWebstatus;
		$('#total').highcharts($scope.total);
	}
	function getCategory(data){
		var datacate = JSON.parse(data.taskContent).category;
		for(index in $scope.categoryList){
			if($scope.categoryList[index]==datacate){
				return;
			}
		}
		$scope.categoryList.push(datacate);
	}
	function getallSeriesElse(data){
		$scope.allseries = [
			{
				name:$scope.allWebstatus,
				data:[],
	            dataLabels: {
	                enabled: true,
	                color: '#FFFFFF',
	                align: 'center',
	                format: '{point.y}',
	                y: 10,
	                style: {
	                    fontSize: '13px',
	                    fontFamily: 'Verdana, sans-serif'
	                }
	            }
			}
		]
		switch($scope.allWebstatus){
			case "Success":
				$scope.allseries[0].color = "#5cb85c";
				break;
			case "Waiting":
				$scope.allseries[0].color = "#f0ad4e";
				break;
			case "Fail":
				$scope.allseries[0].color = "#c12e2a";
				break;
		}
		for(var i=0;i<$scope.categoryList.length;i++){
			var count = 0;
			for(index in data){
				var datacate = JSON.parse(data[index].taskContent).category;
				if(datacate==$scope.categoryList[i]){
					count++;
				}
			}
			$scope.allseries[0].data.push(count);
		}
	}
	function getallSeriesALL(data){
		$scope.allseries = [
			{
				name: 'Success',
				data: [],
				color: "#5cb85c"
			},
			{
				name: 'Waiting',
				data: [],
				color: "#f0ad4e"
			},
			{
				name: 'Fail',
				data: [],
				color: "#c12e2a"
			},
		];
		for(index in $scope.allseries){
			$scope.allseries[index].dataLabels = {
	                enabled: true,
	                color: '#FFFFFF',
	                align: 'center',
	                format: '{point.y}',
	                y: 10,
	                style: {
	                    fontSize: '13px',
	                    fontFamily: 'Verdana, sans-serif'
	                }
	            };
		}
		for(var i=0;i<$scope.categoryList.length;i++){
			var success = 0;
			var waiting = 0;
			var fail = 0;
			for(index in data){
				var datacate = JSON.parse(data[index].taskContent).category;
				if(datacate==$scope.categoryList[i]){
					if(data[index].taskStatus == "R_TRANSLATED"){
						success++;
					}
					else if(data[index].taskStatus=="I_TRANSLATED_FAIL"||data[index].taskStatus=="CAPTURED_FAIL"||data[index].taskStatus=="R_TRANSLATED_FAIL"){
						fail++;
					}
					else{
						waiting++;
					}
				}
			}
			$scope.allseries[0].data.push(success);
			$scope.allseries[1].data.push(waiting);
			$scope.allseries[2].data.push(fail);
		}
	}
	//One Web Capturing Volume Search
	$scope.oneWebSearch = function(){
		var flag = oneIntervalValFn();
		if(flag){
			var fromDate=$filter('date')($scope.oneWebFromToDate.start, 'yyyy-MM-dd HH:mm:ss');
			var toDate=$filter('date')($scope.oneWebFromToDate.end, 'yyyy-MM-dd HH:mm:ss');
			oneWebSearchFn(fromDate,toDate);
		}
	}
	function oneWebSearchFn(fromDate,toDate){
		var data = {
			fromDate:fromDate,
			toDate:toDate,
			category:$scope.oneWebsite
		};
		console.log(data);
		$http({
			method:"POST",
			data:data,
			url:"../statistics/detailStatistics"
		}).success((data)=>{
			// getOneWebSearch(data);
			getOneWebSearchCol(data);
		})
	}
	function getOneWebSearchCol(data){
		var space = getSpace();
		var datelist = getOneWebDateList(data);
		var categories = getOneCategoriesCol(space);
		$scope.oneWeb.series[0].data = dateCheckCol(categories,datelist.success,space);
		$scope.oneWeb.series[1].data = dateCheckCol(categories,datelist.fail,space);
		$scope.oneWeb.series[2].data = dateCheckCol(categories,datelist.waiting,space);
		$scope.oneWeb.xAxis.categories = getOneXAxisCol(categories,space);
		$scope.oneWeb.subtitle.text = "Website : " + $scope.oneWebsite;
		$('#timeline').highcharts($scope.oneWeb);
	}
	function getOneXAxisCol(categories,space){
		var list = [];
		for(index in categories){
			var temptime = categories[index];
			var temptimeFrom = $filter('date')(temptime,"MM-dd HH:mm");
			var temptimeTo = $filter('date')((temptime+space),"MM-dd HH:mm");
			var temptimeOut = temptimeFrom + " ~ " + temptimeTo;
			list.push(temptimeOut);
		}
		return list;
	}
	function dateCheckCol(categories,list,space){
		var data = [];
		for(index in categories){
			data.push(0);
		}
		for(index in categories){
			var tempfrom = categories[index];
			var tempto = tempfrom + space;
			for(var i=0;i<list.length;i++){
				if(list[i]>=tempfrom&&list[i]<tempto){
					data[index]++;
				}
			}
		}
		return data;
	}
	function getOneCategoriesCol(space){
		var categories = [];
		var fromDate = $scope.oneWebFromToDate.start.getTime();
		var toDate = $scope.oneWebFromToDate.end.getTime();
		var temptime = 0;
		for(var i=0;temptime<toDate;i++){
			temptime = fromDate + i*space;
			
			categories.push(temptime);
		}
		return categories;
	}
	function getSpace(){
		var fromDate = $scope.oneWebFromToDate.start.getTime();
		var toDate = $scope.oneWebFromToDate.end.getTime();
		var rate = 0;
		switch($scope.oneIntervalUnit){
			case "Hour":
				rate = 1;break;
			case "Day":
				rate = 24;break;
		}
		// return Math.round((toDate-fromDate)/(60*60*1000)*rate);
		return Math.round((60*60*1000)*rate*$scope.oneInterval);
	}
	function getOneWebSearchPie(datelist){
		var success = datelist.success.length;
		var fail = datelist.fail.length;
		var waiting = datelist.waiting.length;
		$scope.piechart.series[0].data[0].y = success;
		$scope.piechart.series[0].data[1].y = fail;
		$scope.piechart.series[0].data[2].y = waiting;
		$("#piechart").highcharts($scope.piechart);
	}
	function getOneWebSearch(data){
		var datelist = getOneWebDateList(data);
//		getOneWebSearchPie(datelist);
		var start = setOneTime($scope.oneWebFromToDate.start,"from");
		var end = setOneTime($scope.oneWebFromToDate.end,"to");
		$scope.oneWeb.series[0].data = dateCheck(start,end,datelist.success);
		$scope.oneWeb.series[1].data = dateCheck(start,end,datelist.fail);
		$scope.oneWeb.series[2].data = dateCheck(start,end,datelist.waiting);
		$scope.oneWeb.subtitle.text = "Website : " + $scope.oneWebsite;
		$('#timeline').highcharts($scope.oneWeb);		
	}
	function dateCheck(from,to,list){
		var data = [];
		var totalhours = (to - from)/3600000;
		for(var i=0;i<totalhours;i++){
			var temptime = from + i * 3600000;
				var timeline = [
					temptime,0
				];
				data.push(timeline);
		}
		for(listindex in list){
			var listtime = list[listindex];
			for(index in data){
				var temptime = data[index][0];
				var oneHourLater = temptime + 1 * 3600000;
				if(listtime>=temptime&&listtime<oneHourLater){
					data[index][1]++;
				}
			}
		}
		for(var i=0;i<data.length;i++){
			if(data[i][1]==0){
				delete data[i];
			}
		}
		var data = data.filter(function(v){return v != undefined;});//过滤掉undefined的值。
		return data;
	}
	function setOneTime(timeval,type){
		timeval.setMinutes(0);
		timeval.setMilliseconds(0);
		timeval.setSeconds(0);
		timeval = timeval.getTime();
		if(type=="to"){
			timeval = timeval + 1 * 3600000;
		}
		return timeval;
	}
	
	function getOneWebDateList(data){
	    var list = {
	        "success":[],
	        "waiting":[],
	        "fail":[]
	    };
	    for(index in data){
	        var tasktime = new  Date(data[index].taskCreateTime).getTime();
	        var taskStatus = data[index].taskStatus;
	        if(taskStatus=="R_TRANSLATED"){
	            list.success.push(tasktime);
	        }
	        else if(taskStatus=="I_TRANSLATED_FAIL"||taskStatus=="CAPTURED_FAIL"||taskStatus=="R_TRANSLATED_FAIL"){
	            list.fail.push(tasktime);
	        }
	        else{
	            list.waiting.push(tasktime);
	        }
	    }
	    return list;
	}
	
	
	
//	Temp
////总体 success||false
	$(function () {
		$scope.total = {
			chart: {
				type: 'column'
			},
			title: {
				text: 'All Website Capturing Volume'
			},
			subtitle: {
	             text: 'test'
	        },
			xAxis: {
				categories: [],
				title: {
	                text: 'Website'
	            }
			},
			yAxis: {
				min: 0,
				title: {
					text: 'Frequency'
				}
			},
			tooltip: {
				pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b><br/>'
				,shared: true
			},
			plotOptions: {
				column: {
					stacking: 'normal'
				}
			},
			series: [{
				name: '',
				data: [],
				color: ""
			}],
			credits: {
				enabled: false
			}
		}
	});
// //时间段 success&&false
 $(function () {
//	 $('#timeline').highcharts($scope.oneWeb);
	 // $scope.oneWeb ={
	 //        chart: {
	 //            type: 'spline'
	 //        },
	 //        title: {
	 //            text: 'Capturing Volume'
	 //        },
	 //        subtitle: {
	 //             text: 'test'
	 //        },
	 //        xAxis: {
	 //            type: 'datetime',
	 //             minRange: 1 * 24 * 3600000,
	 //            dateTimeLabelFormats: { // don't display the dummy year
	 //            	hour: '%H:%M',
	 //            	day: '%e. %b',
	 //            	week: '%e. %b',
	 //            	month: '%b \'%y',
	 //            	year: '%Y'
	 //            },
	 //            title: {
	 //                text: 'Time Line'
	 //            }
	 //        },
	 //        yAxis: {
	 //            title: {
	 //                text: 'Frequency'
	 //            },
	 //            min: 0
	 //        },
	 //        tooltip: {
	 //        	headerFormat: '<b>{point.key}</b><br>',
	 //            pointFormat: '{point.y} times'
	 //        },
	 //        plotOptions: {
	 //            spline: {
	 //                marker: {
	 //                    enabled: true
	 //                }
	 //            }
	 //        },
	 //        series: [{
  //               name: 'success',
  //               color:"#5cb85c",
  //               data: []
  //           },
  //            {
  //                name: 'fail',
  //                color:"#c12e2a",
  //                data: []
  //            },
  //            {
  //                name: 'waiting',
  //                color:"#f0ad4e",
  //                data: []
  //            }
  //       ],
  //       credits: {
		// 	enabled: false
		// }
	 //    };
$scope.oneWeb ={
	chart: {
		type: 'column'
	},
	title: {
		text: 'Capturing Volume'
	},
	subtitle: {
        text: 'test'
    },
	xAxis: {
		categories: [],
		title: {
            text: 'Timeline'
        }
	},
	yAxis: {
		min: 0,
		title: {
			text: 'Frequency'
		}
	},
	tooltip: {
		pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b><br/>'
		,shared: true
	},
	plotOptions: {
		column: {
			stacking: 'normal'
		}
	},
	series: [
		{
        	name: 'success',
            color:"#5cb85c",
            data: []
            ,dataLabels:{
	                enabled: true,
	                color: '#FFFFFF',
	                align: 'center',
	                format: '{point.y}',
	                y: 10,
	                style: {
	                    fontSize: '13px',
	                    fontFamily: 'Verdana, sans-serif'
	                }
	            }
        },
         {
             name: 'fail',
             color:"#c12e2a",
             data: []
             ,dataLabels:{
	                enabled: true,
	                color: '#FFFFFF',
	                align: 'center',
	                format: '{point.y}',
	                y: 10,
	                style: {
	                    fontSize: '13px',
	                    fontFamily: 'Verdana, sans-serif'
	                }
	            }
         },
         {
             name: 'waiting',
             color:"#f0ad4e",
             data: []
             ,dataLabels:{
	                enabled: true,
	                color: '#FFFFFF',
	                align: 'center',
	                format: '{point.y}',
	                y: 10,
	                style: {
	                    fontSize: '13px',
	                    fontFamily: 'Verdana, sans-serif'
	                }
	            }
         }
    ],
	credits: {
		enabled: false
	}
};

 });
})