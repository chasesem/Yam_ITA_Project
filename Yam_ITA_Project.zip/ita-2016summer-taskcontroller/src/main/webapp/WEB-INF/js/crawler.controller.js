realProjectControllers.controller("crawlerCtrl", function($scope, $rootScope, $http) {

	var getCrawlerUrl = "/TaskController/ConfigureCrawlerController/getAllCrawler";
	var saveCrawlerUrl = "/TaskController/ConfigureCrawlerController/saveCrawler";

	crawlerInit();

	function crawlerInit() {
		$rootScope.active = "crawler";
		$scope.crawlers = [];
		$scope.crawlerAdd = {};
	}

	function getAllCrawlers() {
		$http({
			method: "GET",
			url: getCrawlerUrl
		}).then(function successCallback(res) {
			console.log("get crawler succ")
				//console.log(res.data)
			$scope.crawlers = res.data;
		}, function errorCallback(res) {
			console.log("get crawler fail")
			console.log(res.data)
		})
	}

	getAllCrawlers();

	$scope.addCrawler = function() {
		var crawler = {
			url: $scope.crawlerAdd.url,
			javaClass: $scope.crawlerAdd.javaClass,
			name: $scope.crawlerAdd.name
		}
		if (checkCrawlerInfo()) {
			$('#addCrawlerModal').modal('hide');
			$http({
				method: "POST",
				url: saveCrawlerUrl,
				data: crawler
			}).then(function successCallback(res) {
				$scope.crawlerAdd = {}
				swal("Success!", "Add the crawler success!", "success");
				//getAllCategories();
				getAllCrawlers()
			}, function errorCallback(res) {
			
			})
		}
	}

	function checkCrawlerInfo() {
		$scope.addCrawlerVali = {};
		$scope.addCrawlerValiTip = {};
		var flag = true;		
		if (!($scope.crawlerAdd).hasOwnProperty('name') || $scope.crawlerAdd.name == '') {
			$scope.addCrawlerVali.name = true;
			$scope.addCrawlerValiTip.nameTip = 'Please input or select a crawler name';
			flag = false;
		}
		if (!($scope.crawlerAdd).hasOwnProperty('url') || $scope.crawlerAdd.url == '' || $scope.crawlerAdd.url == undefined) {
			$scope.addCrawlerVali.url = true;
			$scope.addCrawlerValiTip.urlTip = 'Please input url with right format';
			flag = false;
		}
		if (!($scope.crawlerAdd).hasOwnProperty('javaClass') || $scope.crawlerAdd.javaClass == '') {
			$scope.addCrawlerVali.javaClass = true;
			$scope.addCrawlerValiTip.javaClassTip = 'Please input javaClass';
			flag = false;
		}
		if ($scope.crawlerAdd.name != '') {
			for (var i = 0; i < ($scope.crawlers).length; i++) {
				if ($scope.crawlerAdd.name == ($scope.crawlers)[i].name) {
					$scope.addCrawlerVali.name = true;
					$scope.addCrawlerValiTip.nameTip = 'Crawler name exsists';
					flag = false;
				}
			}
		}
		
		return flag;
	}

})