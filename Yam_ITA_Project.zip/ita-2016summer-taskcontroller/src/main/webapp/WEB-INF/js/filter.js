var realProjectFilters = angular.module("realProjectFilters",[])

realProjectFilters.filter("string2Date",function(){
	return function toLocalDate(date){
		if(date){
			return new Date(date);
		}
	}
})