package com.robot.taskcontroller.queue.test;

import javax.jms.JMSException;

import org.junit.Test;

import com.robot.taskcontroller.jms.JMSConnectionFactory;

public class JMSConnectionFactoryTest {
	

}
