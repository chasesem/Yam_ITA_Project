package com.robot.taskcontroller.jms;


import org.junit.Test;

public class JMSUtilsTest {
	
	@Test
	public void TestJmx(){
		JMSUtils jmsUtils = new JMSUtils();
		
			jmsUtils.getSubscribers();
		
	}

}
