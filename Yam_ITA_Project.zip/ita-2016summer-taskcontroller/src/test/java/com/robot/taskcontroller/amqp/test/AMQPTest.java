package com.robot.taskcontroller.amqp.test;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import org.junit.Test;

import com.robot.taskcontroller.amqp.QueueReciver;
import com.robot.taskcontroller.amqp.QueueSender;

public class AMQPTest {
	
	//@Test
	public void TestSender() throws IOException, TimeoutException{
		QueueSender sender = new QueueSender();
		sender.sendMessage("hello hello ");
	}
	
	@Test
	public void TestReciver() throws IOException, TimeoutException{
		QueueReciver sender = new QueueReciver();
		sender.reciveMessage();
	}

}
