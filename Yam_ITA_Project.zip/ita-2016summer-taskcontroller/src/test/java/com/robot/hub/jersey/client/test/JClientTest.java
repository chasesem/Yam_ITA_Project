package com.robot.hub.jersey.client.test;

import org.junit.Test;

import com.robot.taskcontroller.jersey.client.JClient;

public class JClientTest {
	String str = "{\"content\":\"66666GF66666\",\"priority\":2,\"taskId\":\"123465\"}";
	
	@Test
	public void testClient(){
		JClient client = new JClient();
		System.out.println(str);
		client.saveTask(str);
	}

}
