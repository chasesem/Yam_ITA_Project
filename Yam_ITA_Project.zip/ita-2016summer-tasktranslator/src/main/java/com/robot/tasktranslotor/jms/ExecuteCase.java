package com.robot.tasktranslotor.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQTextMessage;

import com.alibaba.fastjson.JSON;
import com.robot.tasktranslator.jersey.client.JClient;
import com.robot.tasktranslator.model.App;
import com.robot.tasktranslator.model.Task;
import com.robot.tasktranslator.model.TaskITranslated;
public class ExecuteCase implements OnMessageCase{
	
	
	private Sender sender;
	private JClient client;
	
	public ExecuteCase(Sender sender,JClient client){
		this.sender = sender;
		this.client = client;
	}

	public void action(Message message) throws JMSException {
		TextMessage msg = (TextMessage) message;
		Task task = JSON.parseObject(msg.getText(), Task.class);
		if(msg!=null){
			client.updateTask(JClient.UPDATE_PATH,task.getTaskId(), Task.I_TRANSLATING);
			task.setTaskStatus( Task.I_TRANSLATING);
			TaskITranslated taskITranslated = new TaskITranslated();
			taskITranslated.setiTranslatedTaskId(task.getTaskId());
			taskITranslated.setProjectOwner(task.getProjectOwner());
			taskITranslated.setTaskType(task.getTaskType());
			taskITranslated.setAppId(App.getInstance().getAppId());
			taskITranslated.setHostName(App.getInstance().getHostName());
			taskITranslated.setiTranslatedTaskResult(task.getTaskContent());
			TextMessage textMsg = new ActiveMQTextMessage();
			textMsg.setText(taskITranslated.toString());
			sender.sendMessage(textMsg);
			client.saveTask(JClient.ITRANSLATED_PATH,taskITranslated.toString());
			
			
		}
		
	}

}
