package com.robot.tasktranslotor.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;


public class OnJMSMessageHandler implements MessageListener{
	private OnMessageCase onMessageCase;
	
	public OnJMSMessageHandler(){}
	
	public OnJMSMessageHandler(OnMessageCase onMessageCase){
		this.onMessageCase = onMessageCase;
	}
	
	public void setOnMessageCase(OnMessageCase onMessageCase) {
		this.onMessageCase = onMessageCase;
	}

	public void onMessage(Message message) {
		if (message != null) {
            TextMessage map = (TextMessage) message;
            try {
            	System.out.println("crawler"+map.getText());
                Thread.sleep(3000);
                if(map.getText()!=null)
                	 onMessageCase.action(message);
            } catch (JMSException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
				e.printStackTrace();
			} 
        }
		
		
	}

}
