package com.robot.tasktranslotor.jms;

import javax.jms.JMSException;
import javax.jms.Message;

public interface OnMessageCase {
	
	void action(Message message) throws JMSException;

}
