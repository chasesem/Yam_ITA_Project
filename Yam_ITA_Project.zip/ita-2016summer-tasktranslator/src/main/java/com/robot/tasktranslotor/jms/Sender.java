package com.robot.tasktranslotor.jms;

import javax.jms.Message;

public interface Sender {
	void sendMessage(Message msg);
}
