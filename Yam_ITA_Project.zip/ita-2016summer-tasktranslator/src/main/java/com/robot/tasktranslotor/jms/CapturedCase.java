package com.robot.tasktranslotor.jms;


import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;


import com.alibaba.fastjson.JSON;
import com.robot.tasktranslator.jersey.client.JClient;
import com.robot.tasktranslator.model.App;
import com.robot.tasktranslator.model.Task;
import com.robot.tasktranslator.model.TaskCaptured;
import com.robot.tasktranslator.model.TaskRTranslated;

public class CapturedCase implements OnMessageCase{
	
	private JClient client;
	
	public CapturedCase(JClient client){
		this.client = client;
	}

	public void action(Message message) throws JMSException {
		TextMessage msg = (TextMessage) message;
		TaskCaptured taskCaptured = JSON.parseObject(msg.getText(), TaskCaptured.class);
		if(msg!=null){
			client.updateTask(JClient.UPDATE_PATH, taskCaptured.getCapturedTaskId(), Task.R_TRANSLATING);
			TaskRTranslated taskRTranslated = new TaskRTranslated();
			taskRTranslated.setrTranslatedTaskId(taskCaptured.getCapturedTaskId());
			taskRTranslated.setProjectOwner(taskCaptured.getProjectOwner());
			taskRTranslated.setTaskType(taskCaptured.getTaskType());
			taskRTranslated.setAppId(App.getInstance().getAppId());
			taskRTranslated.setHostName(App.getInstance().getHostName());
			taskRTranslated.setrTranslatedTaskResult(taskCaptured.getCapturedTaskResult());
			client.saveTask(JClient.RTRANSLATED_PATH,taskRTranslated.toString());
		}
		
	}

}
