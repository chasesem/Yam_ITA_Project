package com.robot.tasktranslotor.jms;

import javax.jms.Connection;
import javax.jms.JMSException;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.ActiveMQPrefetchPolicy;

public class JMSConnectionFactory {
	private String user;
	private String password;
	private String url;
	
	
	public JMSConnectionFactory(String user,String password,String url){
		this.user = user;
		this.password = password;
		this.url = url;
	}
	

	
	public Connection getTopicConnction() throws JMSException{
		ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(user, 
				password,url);
			return factory.createTopicConnection();
	}
	
	public Connection getQueueConnection() throws JMSException{
		ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(user, 
				password,url);
			factory.setExclusiveConsumer(false);
			ActiveMQPrefetchPolicy l = new ActiveMQPrefetchPolicy();
			l.setQueuePrefetch(1);
			factory.setPrefetchPolicy(l);
			return factory.createQueueConnection();
	}
	
}
