package com.robot.tasktranslotor.jms;


import java.util.UUID;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.Session;



public class QueueRecevier {
	
	private String queueName;
	private Connection connection;
	
	public QueueRecevier(Connection connection,String queueName){
		this.connection = connection;
		this.queueName = queueName;
		try {
			this.connection.setClientID("tasktranslator consumer"+UUID.randomUUID().toString());
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void recevieMessage(MessageListener messageListener) throws JMSException{
		Session session = null;
		try {
			connection.start();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Queue queue = session.createQueue(queueName);
			MessageConsumer subscriber =  session.createConsumer(queue);
			subscriber.setMessageListener(messageListener);
		} catch (JMSException e) {
			e.printStackTrace();
		} 
	}
	
	public void stop(){
		try {
			connection.stop();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
	
	public void start(){
		try {
			connection.start();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
	
}
