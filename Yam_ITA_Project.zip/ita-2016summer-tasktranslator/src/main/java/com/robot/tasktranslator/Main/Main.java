package com.robot.tasktranslator.Main;

import java.io.IOException;

import javax.jms.JMSException;

import org.apache.commons.cli.ParseException;

public class Main {


	public static void main(String[] args) throws IllegalArgumentException, IOException, JMSException, ParseException{
		if(args.length<1){
			String[] cmd = {"-f","tasktranslator.properties"};
			CommandController.execute(cmd);
		}else{
			CommandController.execute(args);
		}
		
//		 URI baseUri = UriBuilder.fromUri("http://localhost/").port(8093).build();
//		 ResourceConfig config = new ResourceConfig().packages("com.robot.tasktranslator.jersey");
//	     HttpServer server  = GrizzlyHttpServerFactory.createHttpServer(baseUri,config); 
//	     System.out.println("...started");  
	}
}
