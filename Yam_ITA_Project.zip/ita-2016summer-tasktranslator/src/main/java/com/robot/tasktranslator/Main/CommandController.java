package com.robot.tasktranslator.Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.MessageListener;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;

import com.robot.tasktranslator.jersey.client.JClient;
import com.robot.tasktranslotor.jms.CapturedCase;
import com.robot.tasktranslotor.jms.ExecuteCase;
import com.robot.tasktranslotor.jms.JMSConnectionFactory;
import com.robot.tasktranslotor.jms.OnJMSMessageHandler;
import com.robot.tasktranslotor.jms.QueueRecevier;
import com.robot.tasktranslotor.jms.QueueSender;



public class CommandController {
	private final static String JMS_USER = "jms.user";
	private final static String JMS_PASSWOED = "jms.password";
	private final static String JMS_URL = "jms.url";
	private final static String JMS_INPUT_PRODUCE = "jms.input.produce";
	private final static String JMS_INPUT_CONSUME = "jms.input.consume";
//	private final static String INPUT_BASIC_URL="persistent.input.host";
//	private final static String INPUT_PATH = "persistent.input.path";
	
//	private final static String JMS_OUTPUT_PRODUCE = "jms.output.produce";
	private final static String JMS_OUTPUT_CONSUME = "jms.output.consume";
//	private final static String OUTPUT_BASIC_URL="persistent.output.host";
//	private final static String OUTPUT_PATH = "persistent.output.path";
	
	public static void execute(String[] args) throws ParseException, FileNotFoundException, IOException, JMSException{
		Options options = new Options();
		options.addOption("f",true,"set properties file");
		CommandLineParser parser = new PosixParser();
		CommandLine cmd = parser.parse(options, args);
		
		
		if(cmd.hasOption("f")){
			File file = new File(cmd.getOptionValue("f")); 
			Properties prop = new Properties();
			prop.load(new FileInputStream(file));
			System.out.println(prop.getProperty(JMS_USER)+"+"+prop.getProperty(JMS_PASSWOED)+"+"+prop.getProperty(JMS_URL));
			JMSConnectionFactory factory = new JMSConnectionFactory(prop.getProperty(JMS_USER),prop.getProperty(JMS_PASSWOED),prop.getProperty(JMS_URL));
			
			QueueSender queueSender = QueueSender.getInstance(prop.getProperty(JMS_USER),prop.getProperty(JMS_PASSWOED),
					prop.getProperty(JMS_URL),prop.getProperty(JMS_INPUT_PRODUCE));
			JClient client = new JClient(JClient.TASK_MANAGER_HOST);
			ExecuteCase onCase = new ExecuteCase(queueSender,client);
			MessageListener messageListener = new OnJMSMessageHandler(onCase);
			
			JClient outputClient = new JClient(JClient.TASK_MANAGER_HOST);
			CapturedCase onOutputCase = new CapturedCase(outputClient);
			MessageListener outputMessageListener = new OnJMSMessageHandler(onOutputCase);
			try {
				QueueRecevier queueRecevier = new QueueRecevier(factory.getQueueConnection(),prop.getProperty(JMS_INPUT_CONSUME));
				queueRecevier.recevieMessage(messageListener);
				QueueRecevier outputRecevier = new QueueRecevier(factory.getQueueConnection(),prop.getProperty(JMS_OUTPUT_CONSUME));
				outputRecevier.recevieMessage(outputMessageListener);
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}; 
		}else{
			System.out.println("need properties file");
		}
	}


}
