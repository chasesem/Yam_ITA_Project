package com.robot.scheduler.model;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

public class ReceiveTask {
	
	private String taskId;
	private String content;
	private int priority; 
	private String createtime;
	private String category;
	private int status;
	
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	@JSONField(serialize=false)  
	public Task getTask(){
		Task task = JSON.parseObject(content,Task.class);
		return task;
	}
	public String toString(){
		return JSON.toJSONString(this).toString();
	}
	

}
