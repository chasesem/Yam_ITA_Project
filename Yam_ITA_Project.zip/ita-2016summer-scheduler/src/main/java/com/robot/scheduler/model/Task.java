package com.robot.scheduler.model;

import com.alibaba.fastjson.JSON;

public class Task {
	private String imo;
	private String callSign;
	private String NameOfShip;
	private String onCurrentName;
	private String mmsi;

	public Task(String imo, String callSign, String NameOfShip,String onCurrentName, String mmsi) {
		this.callSign = callSign;
		this.imo = imo;
		this.NameOfShip = NameOfShip;
		this.onCurrentName = onCurrentName;
		this.mmsi = mmsi;
	}

	public Task() {
		
	}

	public String getImo() {
		return imo;
	}

	public void setImo(String imo) {
		this.imo = imo;
	}

	public String getCallSign() {
		return callSign;
	}

	public void setCallSign(String callSign) {
		this.callSign = callSign;
	}

	public String getNameOfShip() {
		return NameOfShip;
	}

	public void setNameOfShip(String nameOfShip) {
		NameOfShip = nameOfShip;
	}

	public String getOnCurrentName() {
		return onCurrentName;
	}

	public void setOnCurrentName(String onCurrentName) {
		this.onCurrentName = onCurrentName;
	}

	public String getMmsi() {
		return mmsi;
	}

	public void setMmsi(String mmsi) {
		this.mmsi = mmsi;
	}

	public String toString() {
		return JSON.toJSONString(this).toString();
	}
}
