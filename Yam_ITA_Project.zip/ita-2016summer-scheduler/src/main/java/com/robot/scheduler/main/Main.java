package com.robot.scheduler.main;

import org.quartz.SchedulerException;

import com.robot.schduler.core.TaskSchedule;

/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args ) throws SchedulerException
    {
        System.out.println( "Hello World!" );
        TaskSchedule.execute();
    }
}
