package com.robot.scheduler.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;

public class JClient {
	
	private final static Logger logger =  LogManager.getLogger(JClient.class);
	
	private final static String HOST_PATH = "http://10.222.47.44:8080/";
	private final static String GET_TASK_PATH = "tasks/first";
	private final static String SAVE_TASK_PATH = "JAHub/saveTask";
	
	
	private Client client;
	private WebTarget webTarget;
	
	
	public JClient(){
		client = ClientBuilder.newClient(new ClientConfig());
		webTarget = client.target(HOST_PATH);
	}
	
	public String saveTask(String form){
		return doPost(SAVE_TASK_PATH,form);
	}
	
	private String doPost(String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		logger.debug(response.getStatus());
		logger.debug("back+"+response.readEntity(String.class));
		return "SUCCESS";
	}
	
	public String getTask(){
		return doGet(GET_TASK_PATH);
	}

	
	private String doGet(String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.APPLICATION_JSON);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.get();
		logger.debug(response.getStatus());
		String re = response.readEntity(String.class);
		System.out.println("666"+re);
		return re;
	}
	
}
