package com.robot.schduler.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.robot.scheduler.jersey.client.JClient;
import com.robot.scheduler.model.CrawlerMapper;
import com.robot.scheduler.model.ReceiveTask;
import com.robot.scheduler.model.Task;


public class SimpleJob implements Job{
	
	 public void execute(JobExecutionContext jec) throws JobExecutionException {
		 
		 List<CrawlerMapper> crawlerMapperList = new ArrayList<CrawlerMapper>();
			crawlerMapperList.add(new CrawlerMapper("AB","ABSExecutor"));
			crawlerMapperList.add(new CrawlerMapper("BV","BVExecutor"));
			crawlerMapperList.add(new CrawlerMapper("CC","CCSExecutor"));
			crawlerMapperList.add(new CrawlerMapper("CR","CRSExecutor"));
			crawlerMapperList.add(new CrawlerMapper("DN","DNVGLExecutor"));
			crawlerMapperList.add(new CrawlerMapper("EQ","EquasisExecutor"));
			crawlerMapperList.add(new CrawlerMapper("IR","IRSExecutor"));
			crawlerMapperList.add(new CrawlerMapper("KR","KRSExecutor"));
			crawlerMapperList.add(new CrawlerMapper("LR","LRSExecutor"));
			crawlerMapperList.add(new CrawlerMapper("NK","NKKExecutor"));
			crawlerMapperList.add(new CrawlerMapper("RM","RMRSExecutor"));
			
			Map<String,String> map = new HashMap<String,String>();
			map.put("AB", "9356098");
			map.put("BV", "8907876");
			map.put("CC", "9192686");
			map.put("CR", "8209626");
			map.put("DN", "9406647");
			map.put("EQ", "9340051");
			map.put("IR", "9157674");
			map.put("KR", "9086899");
			map.put("LR", "9466362");
			map.put("NK", "9457622");
			map.put("RM", "9130133");
			
			
			int x=(int)(Math.random()*crawlerMapperList.size())+1;
	        Task task = new Task();
	        
	        ReceiveTask rTask = new ReceiveTask();
	        rTask.setCategory(crawlerMapperList.get(x).getCategory());
	        task.setImo(map.get(rTask.getCategory()));
	        rTask.setCreatetime(new Date().toGMTString());
	        rTask.setContent(task.toString());
	        rTask.setTaskId(UUID.randomUUID().toString());
	        JClient jerseyClient = new JClient();
	        System.out.println(rTask.toString());
	        jerseyClient.saveTask(rTask.toString());
	    }

}
