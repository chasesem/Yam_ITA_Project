package com.robot.schduler.core;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class TaskSchedule {
	
	public TaskSchedule(){
		
	}
	public static void execute() throws SchedulerException{
		JobDetail job = JobBuilder
	              .newJob(SimpleJob.class)
	              .withIdentity("SimpleJob")
	              .build();
	      
	      Trigger trigger = TriggerBuilder
	              .newTrigger()
	              .withIdentity("SimpleJob")
	              .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(20).repeatForever())
	              .build();
	      
	      Trigger trigger2 = TriggerBuilder
	                .newTrigger()
	                .withIdentity("SimpleJob")
	                .withSchedule(CronScheduleBuilder.cronSchedule("0/5 * * * * ?"))
	                .build();
	      
	      Scheduler scheduler = new StdSchedulerFactory().getScheduler();
	      scheduler.start();
	      scheduler.scheduleJob(job,trigger2);
	}
	
	  

}
