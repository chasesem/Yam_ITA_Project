package com.robot.proxymanager.h2.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class H2InMemoryConnection implements H2Connection{
	
	private final static Logger logger = LogManager.getLogger(H2InMemoryConnection.class);
	
	private final static String URL = "jdbc:h2:mem:proxy;DB_CLOSE_DELAY=-1";
	private final static String DRIVER = "org.h2.Driver";
	
	private Connection connection;
	
	public H2InMemoryConnection(){
		try {
			Class.forName(DRIVER);
			connection = DriverManager.getConnection(URL,"sa","sa");
			createTable();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConn(){
		return connection;
	}
	
	private void createTable(){
		Statement stmt;
		try {
			stmt = connection.createStatement();
			stmt.execute("create table if not exists proxylist (host varchar(30) not null,port int not null,primary key(host,port));");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

}
