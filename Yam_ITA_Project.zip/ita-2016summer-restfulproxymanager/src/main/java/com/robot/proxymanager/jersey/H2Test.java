package com.robot.proxymanager.jersey;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.robot.proxymanager.h2.core.H2Connection;
import com.robot.proxymanager.h2.core.H2InMemoryConnection;
import com.robot.proxymanager.h2.core.H2LocalConnection;
import com.robot.proxymanager.h2.core.H2TcpConnection;

@Path("/h2")
public class H2Test {
//	private H2Connection h2Conn;
//	
//	
//	public H2Test() throws SQLException{
//		h2Conn = new H2Connection();
//	}
	
	@GET
	@Produces("text/plain")
	public String get() throws SQLException{
		System.out.println("666666");
//		H2Connection h2Conn = new H2InMemoryConnection();
		H2Connection h2Conn =new H2LocalConnection();
//		H2Connection h2Conn =new H2TcpConnection();
		Connection conn = h2Conn.getConn();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from proxylist;");
		StringBuilder str = new StringBuilder();
		while(rs.next()){
			str.append(rs.getString("host") + ":" + rs.getInt("port")+"\n");
			System.out.println(rs.getString("host") + ":" + rs.getInt("port"));
		}
		stmt.close();
		conn.close();
		return str.toString();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces("text/plain")
	public String save(@FormParam("host") String host,@FormParam("port") int port){
		
//		H2Connection h2Conn = new H2InMemoryConnection();
		
		H2Connection h2Conn =new H2LocalConnection();
//		H2Connection h2Conn =new H2TcpConnection();
		
		Connection conn = h2Conn.getConn();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			stmt.execute("insert into proxylist(host,port) values('"+host+"','"+port+"')");
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return "save success";
	}
}
