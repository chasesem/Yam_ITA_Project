package com.robot.proxymanager.h2.core;

import java.sql.SQLException;

import org.h2.tools.Server;

public class H2DbListener {
	
	private Server server;
	
	public H2DbListener(){
		try {
			System.out.println("start up h2.....");
			server = Server.createTcpServer().start();
			System.out.println("start up h2 success");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
