package com.robot.proxymanager.redis.dao.impl;

import java.io.IOException;
import java.rmi.server.UID;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.robot.proxymanager.model.Proxy;
import com.robot.proxymanager.redis.dao.ProxyDao;
import com.robot.proxymanager.util.JSONUtil;

import redis.clients.jedis.Jedis;

public class ProxyDaoImpl implements ProxyDao{

	private Jedis redis ;
	
	public ProxyDaoImpl(){
		redis =  new Jedis("10.222.232.40",6379);
	}
	
	public Proxy save(Proxy proxy) {
		String host = proxy.getProxyHost();
		String port = proxy.getProxyPort();
		String temp = "";
		try {
			temp = JSONUtil.objetc2Json(proxy);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		redis.set(host+":"+port, temp);
		
		return proxy;
	}

	public boolean del(String id) {
		Long result = redis.del(id);
		if(result==1){
			return true;
		}else{
			return false;
		}
	}

	public Proxy update(String id, Proxy proxy) {
		try {
			redis.del(id);
			redis.set(proxy.getProxyHost()+":"+proxy.getProxyPort(), JSONUtil.objetc2Json(proxy));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return proxy;
	}

	public Proxy find(String id) {
		String temp = redis.get(id);
		Proxy proxy = null;
		try {
			proxy = (Proxy) JSONUtil.json2Object(temp, Proxy.class);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return proxy;
	}

	public List<Proxy> findAll() {
		Set<String> keySet = redis.keys("*");
		List<Proxy> list = new ArrayList<Proxy>();
		for(String key :keySet){
			String temp = redis.get(key);
			Proxy proxy = null;
			try {
				proxy = (Proxy) JSONUtil.json2Object(temp, Proxy.class);
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(proxy != null){
				list.add(proxy);
			}
		}
		return list;
	}
	
	
	public List<String> getDataLength(){
		Set<String> keySet = redis.keys("*");
		List<String>list = new ArrayList<String>();
		list.addAll(keySet);
		return list;
	}
}
