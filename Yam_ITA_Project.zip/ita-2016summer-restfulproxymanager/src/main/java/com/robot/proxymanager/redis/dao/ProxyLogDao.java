package com.robot.proxymanager.redis.dao;

import java.util.List;

import com.robot.proxymanager.model.ProxyLog;

public interface ProxyLogDao {
	public void insert(ProxyLog proxyLog);
	public boolean update(ProxyLog proxyLog);
	public List<ProxyLog> findByHostPort(String host,String port);
	public ProxyLog findByTaskId(String id);
}
