package com.robot.proxymanager.jersey;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.robot.proxymanager.h2.core.H2InMemoryConnection;

@Path("/")
public class JerseyTest {
	
	@GET
	@Produces("text/plain")
	public String hello(){
		System.out.println("666666");
		return "hello world";
	}
	
	@GET
	@Path("testH2")
	@Produces("text/plain")
	public String test() throws SQLException{
		 H2InMemoryConnection h2conn = 	new H2InMemoryConnection();
		 Connection conn = h2conn.getConn();
         Statement stmt = conn.createStatement();
         //如果存在USER_INFO表就先删除USER_INFO表
         stmt.execute("DROP TABLE IF EXISTS USER_INFO");
         //创建USER_INFO表
         stmt.execute("CREATE TABLE USER_INFO(id VARCHAR(36) PRIMARY KEY,name VARCHAR(100),sex VARCHAR(4))");
         //新增
         stmt.executeUpdate("INSERT INTO USER_INFO VALUES('" + UUID.randomUUID()+ "','大日如来','男')");
         stmt.executeUpdate("INSERT INTO USER_INFO VALUES('" + UUID.randomUUID()+ "','青龙','男')");
         stmt.executeUpdate("INSERT INTO USER_INFO VALUES('" + UUID.randomUUID()+ "','白虎','男')");
         stmt.executeUpdate("INSERT INTO USER_INFO VALUES('" + UUID.randomUUID()+ "','朱雀','女')");
         stmt.executeUpdate("INSERT INTO USER_INFO VALUES('" + UUID.randomUUID()+ "','玄武','男')");
         stmt.executeUpdate("INSERT INTO USER_INFO VALUES('" + UUID.randomUUID()+ "','苍狼','男')");
         //删除
         stmt.executeUpdate("DELETE FROM USER_INFO WHERE name='大日如来'");
         //修改
         stmt.executeUpdate("UPDATE USER_INFO SET name='孤傲苍狼' WHERE name='苍狼'");
         //查询
         ResultSet rs = stmt.executeQuery("SELECT * FROM USER_INFO");
         //遍历结果集
         while (rs.next()) {
             System.out.println(rs.getString("id") + "," + rs.getString("name")+ "," + rs.getString("sex"));
         }
         //释放资源
         stmt.close();
         //关闭连接
         conn.close();
     
		
		return "success";
	}
}
