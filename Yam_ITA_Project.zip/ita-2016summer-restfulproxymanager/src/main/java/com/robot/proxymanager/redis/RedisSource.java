package com.robot.proxymanager.redis;

import java.util.List;

import redis.clients.jedis.Jedis;

public class RedisSource {
	private Jedis redis ;
	public Jedis getRedis() {
		return redis;
	}
	public RedisSource(){
		redis = new Jedis("10.222.232.40",6379);
	}
	
	public void set(String key,String value){
		redis.set(key, value);
	}
	
	public void set(String key,String value,int seconds){
			redis.setex(key, seconds, value);
	}
	
	public String get(String key){
		return redis.get(key);
	}
	
	public void lpush(String key,String string){
		redis.lpush(key, string);
	}
	
	public List<String> lrange(String key){
		return redis.lrange(key, 0, redis.llen(key));
	}
}
