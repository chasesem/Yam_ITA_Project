package com.robot.proxymanager.main;

import java.io.IOException;
import java.net.URI;

import javax.ws.rs.core.UriBuilder;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import com.robot.proxymanager.h2.core.H2DbListener;

public class Main {
	@SuppressWarnings("unused")
	public static void main(String args[]) throws IllegalArgumentException, IOException{
		
		URI baseUri = UriBuilder.fromUri("http://10.222.232.30").port(8091).build();
		ResourceConfig config = new ResourceConfig().packages("com.robot.proxymanager.jersey");
		
//		 config.register(new H2DbListener());
//		 config.register(new org.h2.server.web.DbStarter());
		 HttpServer server  = GrizzlyHttpServerFactory.createHttpServer(baseUri,config); 
		// server.addListener(new org.h2.server.web.DbStarter());
		 
//		 WebappContext context = new WebappContext("WebappContext", "");
//	        ServletRegistration registration = context.addServlet("ServletContainer", ServletContainer.class);
//	        registration.setInitParameter(ServletContainer.RESOURCE_CONFIG_CLASS, 
//	                ClassNamesResourceConfig.class.getName());
//	        registration.setInitParameter(ClassNamesResourceConfig.PROPERTY_CLASSNAMES, WebServlet.class.getName());
//	        registration.
//	        registration.addMapping("/*");
//	        context.deploy(server);
		 
	     System.out.println("...started");  
	}

}
