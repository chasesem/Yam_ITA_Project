package com.robot.proxymanager.h2.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class H2LocalConnection implements H2Connection{
	
	private final static String URL = "jdbc:h2:D:\\h2\\proxy";
	private final static String DRIVER = "org.h2.Driver";
	
	private Connection connection;
	
	public H2LocalConnection(){
		try {
			Class.forName(DRIVER);
			connection = DriverManager.getConnection(URL,"sa","sa");
			createTable();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConn(){
		return connection;
	}
	
	private void createTable(){
		Statement stmt;
		try {
			stmt = connection.createStatement();
			stmt.execute("create table if not exists proxylist (host varchar(30) not null,port int not null,primary key(host,port));");
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

	
}
