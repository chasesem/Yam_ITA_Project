package com.robot.proxymanager.h2.core;

import java.sql.Connection;

public interface H2Connection {
	
	Connection getConn();

}
