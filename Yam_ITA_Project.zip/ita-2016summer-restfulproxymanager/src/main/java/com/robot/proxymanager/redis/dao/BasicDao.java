package com.robot.proxymanager.redis.dao;

import com.mongodb.client.MongoDatabase;
import com.robot.proxymanager.mongo.DataSource;

public class BasicDao {
	private MongoDatabase dataBase;
	
	public BasicDao(){
		dataBase = DataSource.getInstance().getDatabase();
	}
	
	public MongoDatabase getDataBase(){
		return dataBase;
	}

	

}
