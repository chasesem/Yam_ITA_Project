package com.robot.proxymanager.jersey;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.robot.proxymanager.model.Proxy;
import com.robot.proxymanager.model.ProxyLog;
import com.robot.proxymanager.redis.dao.ProxyDao;
import com.robot.proxymanager.redis.dao.ProxyLogDao;
import com.robot.proxymanager.redis.dao.impl.ProxyDaoImpl;
import com.robot.proxymanager.redis.dao.impl.ProxyLogDaoImpl;
import com.robot.proxymanager.util.JSONUtil;

@Path("/proxy")
public class ProxyController {

	ProxyDao dao;
	ProxyLogDao daoLog;

	public ProxyController() {
		// TODO Auto-generated constructor stub
		daoLog=new ProxyLogDaoImpl();
		dao = new ProxyDaoImpl();
	}

	@GET
	@Path("/one/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String getProxyById(@PathParam(value = "id") String id) {
		Proxy proxy = dao.find(id);
		try {
			return JSONUtil.objetc2Json(proxy);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String getAllProxy() {
		List<Proxy> list = dao.findAll();
		String json = "";
		try {
			json = JSONUtil.objetc2Json(list);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json;
	}

	@GET
	@Path("/one/{taskId}/{category}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String getProxyByRandom(@PathParam(value="taskId")String taskId,@PathParam(value="category") String category) {
		List<String> list = dao.getDataLength();
		Random random = new Random();
		boolean flag = true;
		Proxy proxy = null;
		ProxyLog proxyLog=new ProxyLog();
		while (flag) {
			proxy = dao.find(list.get(random.nextInt(list.size())));
			if (proxy.getProxyStatus() == proxy.EXPIRED) {

			} else {
				int total = proxy.getSucceedCount() + proxy.getFailureCount();
				if (total > 20) {
					double rate = (double) proxy.getSucceedCount() / (double) total;
					if (rate >= 0.9) {
						flag = false;
					}
				}else{
					flag = false;
				}
			}
		}
		proxyLog.setProxyHost(proxy.getProxyHost());
		proxyLog.setProxyPort(proxy.getProxyPort());
		proxyLog.setStartTime((new Date()).toString());
		proxyLog.setCategory(category);
		proxyLog.setEndTime(null);
		proxyLog.setStatus("running");
		proxyLog.setTaskId(taskId);
		daoLog.insert(proxyLog);
		String temp = JSON.toJSONString(proxy);
		return temp;
	}

	@POST
	@Path("/save")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String saveProxy(String json) {
		Proxy proxy = null;
		Proxy temp = null;
		
		String result = "";
		try {
			proxy = (Proxy) JSONUtil.json2Object(json, Proxy.class);
			proxy.setCreateTime(new Date());
			proxy.setFailureCount(0);
			proxy.setSucceedCount(0);
			proxy.setLastUpdateTime(new Date());
			proxy.setPriority(5);
			proxy.setProxyStatus("running");
			temp = dao.save(proxy);
			result = JSONUtil.objetc2Json(temp);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@POST
	@Path("/update")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateProxy(String json) {
		JSONObject object = JSONObject.parseObject(json);
		String id = object.getString("id");
		String proxyStr = object.getString("proxy");
		Proxy proxy = null;
		try {
			proxy = (Proxy) JSONUtil.json2Object(proxyStr, Proxy.class);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Proxy proxy2 = dao.update(id, proxy);
		return JSON.toJSONString(proxy2);
	}

	@GET
	@Path("/delete/{host}/{port}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String deleteProxy(@PathParam(value ="host")String host,@PathParam(value ="port")String port) {
	    String str=host+":"+port;
		boolean result = dao.del(str);
		if (result) {
			return "{\"result\":true}";
		} else {
			return "{\"result\":false}";
		}
	}
	//proxyLogUpdate
	@GET
	@Path("/updateProxyLogStatus/{id}/{status}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateProxyLogStatus(@PathParam(value ="id")String id,@PathParam(value ="status")String status) {
		System.out.println("id::"+id);
		System.out.println("id::"+status);
		boolean result=false;
		ProxyLog proxyLog=new ProxyLog();
		proxyLog=daoLog.findByTaskId(id);
		System.out.println("proxyLog::"+proxyLog);
		//根据proxyLog 拿到 host 和port 
		String key=proxyLog.getProxyHost()+":"+proxyLog.getProxyPort();
		//根据host 和port 拿到proxy
		 Proxy proxy=dao.find(key);
		 System.out.println("proxy::"+proxy);
		if (status.equals("success")) {
			proxy.setSucceedCount(proxy.getSucceedCount()+1);
			//根据status 修改proxy 中的成功次数
		}else if(status.equals("fail")){
			proxy.setFailureCount(proxy.getFailureCount()+1);
		}
		proxyLog.setEndTime((new Date()).toString());
		proxyLog.setStatus(status);
		dao.update(key,proxy);
		result=daoLog.update(proxyLog);
		if (result) {
		return "{\"result\":true}";	
		}
		return "{\"result\":false}";
	}
	//findMsgproxyLog
	@GET
	@Path("/findOneproxyLog/{host}/{port}")
	@Produces(MediaType.APPLICATION_JSON)
//	@Consumes(MediaType.APPLICATION_JSON)
	public String findOneproxyLog(@PathParam(value ="host")String host,@PathParam(value ="port")String port) {
		System.out.println("host::"+host);
		boolean result=false;
		ProxyLog proxyLog=new ProxyLog();
		List<ProxyLog> lists=daoLog.findByHostPort(host,port);
		String json = null;
		try {
			json = JSONUtil.objetc2Json(lists);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return json;	
		
	}
}
