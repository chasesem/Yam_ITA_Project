package com.robot.proxymanager.model;

import java.util.Date;

import com.alibaba.fastjson.JSON;

public class Proxy {
	public final static String RUNNING = "Running";
	public final static String EXPIRED = "EXPIRED"; 
	private String proxyHost;
	private String proxyPort;
	private Date createTime;
	private Date lastUpdateTime;
	private String proxyStatus;
	private Integer priority;
	private Integer failureCount;
	private Integer succeedCount;
	public String getProxyHost() {
		return proxyHost;
	}
	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}
	public String getProxyPort() {
		return proxyPort;
	}
	public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	public String getProxyStatus() {
		return proxyStatus;
	}
	public void setProxyStatus(String proxyStatus) {
		this.proxyStatus = proxyStatus;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
	public String toString(){
		return JSON.toJSONString(this);
	}
	public Integer getFailureCount() {
		return failureCount;
	}
	public void setFailureCount(Integer failureCount) {
		this.failureCount = failureCount;
	}
	public Integer getSucceedCount() {
		return succeedCount;
	}
	public void setSucceedCount(Integer succeedCount) {
		this.succeedCount = succeedCount;
	}
	
}
