package com.robot.proxymanager.redis.dao;

import java.util.List;

import com.robot.proxymanager.model.Proxy;

public interface ProxyDao {
	public Proxy save(Proxy proxy);
	public boolean del(String id);
	public Proxy update(String id , Proxy proxy);
	public Proxy find(String id);
	public List<Proxy> findAll();
	public List<String> getDataLength();
}
