package com.robot.proxymanager.redis.dao.impl;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.robot.proxymanager.model.Proxy;
import com.robot.proxymanager.model.ProxyLog;
import com.robot.proxymanager.redis.dao.BasicDao;
import com.robot.proxymanager.redis.dao.ProxyLogDao;

public class ProxyLogDaoImpl  extends BasicDao implements ProxyLogDao{
	MongoCollection<Document> collection;
	public final static String TABLE_NAME ="proxy";
	
	public ProxyLogDaoImpl(){
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}
	
	public void insert(ProxyLog proxyLog){
		Document document = toDocument(proxyLog);
		collection.insertOne(document);
	}
	
	public boolean update(ProxyLog proxyLog){
		Document document = toDocument(proxyLog);
		try {
			collection.replaceOne(eq("_id", proxyLog.getTaskId()),document);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
		
	}
	public List<ProxyLog> findByHostPort(String host,String port){
		BasicDBObject query = new BasicDBObject();
		query.append("proxyHost", host);
		query.append("proxyPort", port);
		List<Document> list = collection.find(query).into(new ArrayList<Document>());
		List<ProxyLog> lists = new ArrayList<ProxyLog>();
		for(Document document :list){
			lists.add(toProxyLog(document));
		}
		return lists;
	}
	
	
	private Document toDocument(ProxyLog proxyLog) {
		Document document = new Document();
		document.append("category", proxyLog.getCategory());
		document.append("startTime", proxyLog.getStartTime());
		document.append("endTime", proxyLog.getEndTime());
		document.append("proxyHost", proxyLog.getProxyHost());
		document.append("proxyPort", proxyLog.getProxyPort());
		document.append("status", proxyLog.getStatus());
		document.append("_id", proxyLog.getTaskId());
		return document;
	}
	
	private ProxyLog toProxyLog(Document docuement){
		ProxyLog proxyLog = new ProxyLog();
		proxyLog.setTaskId(docuement.getString("_id"));
		proxyLog.setStartTime(docuement.getString("startTime"));
		proxyLog.setEndTime(docuement.getString("endTime"));
		proxyLog.setProxyHost(docuement.getString("proxyHost"));
		proxyLog.setProxyPort(docuement.getString("proxyPort"));
		proxyLog.setStatus(docuement.getString("status"));
		proxyLog.setCategory(docuement.getString("category"));
		return proxyLog;
	}

	public ProxyLog findByTaskId(String id) {
		// TODO Auto-generated method stub
	   Document document=collection.find(eq("_id", id)).first();
		return toProxyLog(document);
	}
	
	
	
}
