package com.robot.proxymanager.redis.test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.robot.proxymanager.h2.core.H2Connection;
import com.robot.proxymanager.h2.core.H2LocalConnection;
import com.robot.proxymanager.h2.core.H2TcpConnection;

public class H2ThreadTest {
	
	@DataProvider(name = "location", parallel = true)
	public Object[][] location() {
		return new Object[][] { 
					{"10.222.47.41",1111},
					{"10.222.47.42",1111},
					{"10.222.47.43",1111},
					{"10.222.47.44",1111},
					{"10.222.47.45",1111},
					{"10.222.47.46",1111},
					{"10.222.47.47",1111},
					{"10.222.47.48",1111},
					{"10.222.47.49",1111},
					{"10.222.47.50",1111},
					{"10.222.47.51",1111},
					{"10.222.47.52",1111},
					{"10.222.47.53",1111},
					{"10.222.47.41",1112},
					{"10.222.47.42",1113},
					{"10.222.47.43",1114},
					{"10.222.47.44",1115},
					{"10.222.47.45",1116},
					{"10.222.47.46",1117},
					{"10.222.47.47",1118},
					{"10.222.47.48",1119},
					{"10.222.47.49",1120},
					{"10.222.47.50",1121},
					{"10.222.47.51",1122},
					{"10.222.47.52",1123},
					{"10.222.47.53",1124}
				};
	}
	
	
	@Test(dataProvider = "location", threadPoolSize = 2, invocationCount = 10, invocationTimeOut = 10000)
	public void concurrentTestResult(String host, int port)
			throws Throwable {
		H2Connection h2conn = new H2LocalConnection();
		Connection conn = h2conn.getConn();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			stmt.execute("insert into proxylist(host,port) values('"+host+"','"+port+"')");
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Test(threadPoolSize = 5,invocationCount = 20, invocationTimeOut = 10000)
	public void concurrentTestH2(){
		H2Connection h2Conn =new H2LocalConnection();
		Connection conn = h2Conn.getConn();
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from proxylist;");
			StringBuilder str = new StringBuilder();
			
			while(rs.next()){
				str.append(rs.getString("host") + ":" + rs.getInt("port")+"\n");
				System.out.println(rs.getString("host") + ":" + rs.getInt("port"));
			}
			
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
		
		
	}
	
}
