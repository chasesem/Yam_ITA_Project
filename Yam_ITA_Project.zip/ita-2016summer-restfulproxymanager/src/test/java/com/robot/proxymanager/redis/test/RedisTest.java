package com.robot.proxymanager.redis.test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.robot.proxymanager.model.Proxy;
import com.robot.proxymanager.redis.RedisSource;
import com.robot.proxymanager.redis.dao.ProxyDao;
import com.robot.proxymanager.redis.dao.impl.ProxyDaoImpl;

import redis.clients.jedis.Jedis;

public class RedisTest {
	private RedisSource redis;
	
	private ProxyDao dao;
	@Before
	public void setUp(){
		redis = new RedisSource();
		dao = new ProxyDaoImpl();
	}
	
//	@Test
	public void test(){
		redis.set("1", "66666");
	}
	
//	@Test
	public void testSetx(){
		redis.set("jimmy", "6666", 10);
	}
	
//	@Test
	public void testGet(){
		System.out.println(redis.get("allen"));
	}
//	@Test
	public void testListSet(){
		redis.lpush("jay","1");
		redis.lpush("jay", "2");
		
	}
//	@Test
	public void testListGet(){
		List<String> list = redis.lrange("jay");
		for(String str:list)
			System.out.println(str);
	}

	@Test
	public void tesst(){
//		redis.set("10.222.232.30:8080", "123");
		Jedis jedis = redis.getRedis();
		System.out.println(jedis.keys("*"));
//		Proxy proxy = new Proxy();
//		proxy.setProxyHost("10.222.232.30");
//		proxy.setProxyPort("8080");
//		proxy.setCreateTime(new Date());
//		proxy.setFailureCount(2);
//		proxy.setLastUpdateTime(new Date());
//		proxy.setPriority(10);
//		proxy.setProxyStatus(Proxy.RUNNING);
//		proxy.setSucceedCount(91);
//		dao.update("10.222.232.30:8080", proxy);
//		System.out.println(dao.find("10.222.232.30:8080"));
//		redis.de(key)
//		dao.save(proxy);
//		dao.del(proxy);
//		dao.update("10.222.232.30:8081", proxy);
	}
	
}
