package com.robot.jmscontroller.JMSController;

import java.io.IOException;
import org.apache.commons.cli.ParseException;

public class OptionMain {
	
	public static void main(String[] args) throws ParseException, IOException{
	}

}
