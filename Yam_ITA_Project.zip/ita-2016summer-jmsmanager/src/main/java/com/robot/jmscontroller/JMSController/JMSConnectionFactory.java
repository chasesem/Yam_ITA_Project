package com.robot.jmscontroller.JMSController;

import javax.jms.Connection;
import javax.jms.JMSException;

import org.apache.activemq.ActiveMQConnectionFactory;

public class JMSConnectionFactory {
	private static Connection topicConnection;
	private static Connection queueConnection;
	
	public JMSConnectionFactory(String JMS_URL){
		ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(JMS_URL);
		init(factory);
		
	}
	
	public void init(ActiveMQConnectionFactory factory){
		try {
			topicConnection = factory.createTopicConnection();
			factory.setExclusiveConsumer(false);
			queueConnection = factory.createQueueConnection();
			} catch (JMSException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getTopicConnction(){
		return topicConnection;
	}
	
	public Connection getQueueConnection(){
		return queueConnection; 
	}
	
}
