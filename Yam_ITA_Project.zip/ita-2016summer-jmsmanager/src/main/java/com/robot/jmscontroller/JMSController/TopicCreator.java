package com.robot.jmscontroller.JMSController;


import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.Topic;


public class TopicCreator {
	
	public static void create(Connection connection,String des) throws JMSException {
		Session session = null;
		try {
			connection.start();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			Topic topic = session.createTopic(des);
			MessageProducer producer = session.createProducer(topic);
			producer.setDeliveryMode(DeliveryMode.PERSISTENT);
			session.commit();
		} catch (JMSException e) {
			e.printStackTrace();
		} finally{
			if(session!=null)
				session.close();
			if(connection!=null)
				connection.stop();
		}
	}
	

}
