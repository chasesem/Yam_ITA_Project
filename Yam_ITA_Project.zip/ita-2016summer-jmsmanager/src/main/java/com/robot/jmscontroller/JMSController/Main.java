package com.robot.jmscontroller.JMSController;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.jms.JMSException;

public class Main {
	
	/**
	 * We set up the username password as empty, you can change if need
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException{
		Properties prop = new Properties();
		File file;
		String filename ;
		file = new File(System.getProperty("user.dir") + "\\conf.properties");
		filename = System.getProperty("user.dir") + "\\conf.properties";
		if(file.exists()){
			InputStream in = new FileInputStream(file);
			prop.load(in);
			String admin = prop.getProperty("activeMQ.admin");
			String password = prop.getProperty("activeMQ.password");
			String url = prop.getProperty("activeMQ.url");
			JMSConnectionFactory connectionFactory=null;
			connectionFactory =  new JMSConnectionFactory(url);
			if(prop.getProperty("activeMQ.queue")!=null){
				String[] queues = prop.getProperty("activeMQ.queue").split(",");
				for(int i=0;i<queues.length;i++){
					System.out.println("Creating queue"+queues[i]);
					try {
						QueueCreator.create(connectionFactory.getQueueConnection(),queues[i]);
						} catch (JMSException e) {
						e.printStackTrace();
						return;
					}
				}
			}
		}
	}
	
}
