package com.robot.jmscontroller.JMSController;


import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

public class QueueCreator {
	
	public static void create(Connection connection,String des) throws JMSException {
		Session session = null;
		try {
			connection.start();
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			Queue queue = session.createQueue(des);
			MessageProducer producer = session.createProducer(queue);
			producer.setDeliveryMode(DeliveryMode.PERSISTENT);
			session.commit();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			if(session!=null)
				session.close();
			if(connection!=null)
				connection.stop();
		}
	}
	
	
}
