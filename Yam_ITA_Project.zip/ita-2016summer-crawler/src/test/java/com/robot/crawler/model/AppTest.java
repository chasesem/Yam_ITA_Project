package com.robot.crawler.model;

import org.junit.Test;

public class AppTest {
	
	@Test
	public void test(){
		App.setvAppId("666");
		System.out.println(App.getInstance().getAppId());
		App.setvAppId("5555");
		System.out.println(App.getInstance().getAppId());
	}

}
