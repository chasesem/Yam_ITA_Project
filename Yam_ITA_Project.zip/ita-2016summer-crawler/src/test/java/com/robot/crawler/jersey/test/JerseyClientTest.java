package com.robot.crawler.jersey.test;

import org.junit.Test;

import com.robot.crawler.jersey.client.JClient;


public class JerseyClientTest {
	
	@Test
	public void testClient(){
		JClient client = new JClient();
		System.out.println(client.getProfile("AB"));
	}

}
