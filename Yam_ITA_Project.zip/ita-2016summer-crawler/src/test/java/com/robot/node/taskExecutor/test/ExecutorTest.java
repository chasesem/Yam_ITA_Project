package com.robot.node.taskExecutor.test;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.ExecutorUtils;


public class ExecutorTest extends BasicTest {
	
	TaskContent task=new TaskContent();

	@Before
	public void setUp() throws Exception
	{
		task.setImo("imo");
	}

	@Parameters(name = "{0}")
	public static Iterable<Object[]> portPairs() {
		return Arrays.asList(new Object[][] { 
				{ "1" } ,
		});
	}
	
	@Parameter(value=0)
	public String imo;

	//@Test
	public void testExecute() throws Throwable
	{
		TaskContent task=new TaskContent();
		Result []v=new Result[5];
		task.setImo("8907876");
		v[0]=ExecutorUtils.excute("BVExecutor",task);
		task.setImo("8209626");
		v[1]=ExecutorUtils.excute("CRSExecutor",task);
		task.setImo("9157674");
		v[2]=ExecutorUtils.excute("IRSExecutor",task);
		task.setImo("9466362");
		v[3]=ExecutorUtils.excute("LRSExecutor",task);
		task.setImo("9130133");
		v[4]=ExecutorUtils.excute("RMRSExecutor",task);
		assertTrue(task.toJSONString()!=null);
		System.out.println(task.toJSONString());

		for(Result vessel:v){
			System.out.println(vessel.toJSONString());
			assertTrue(vessel.toJSONString()!=null);
			System.out.println();
		}
	}
	
	@Test
	public void testBVExecute() throws Throwable
	{
		TaskContent task=new TaskContent();
		Result v;
		task.setImo("8907876");
		v=ExecutorUtils.excute("BVExecutor",task);
		assertTrue(task.toJSONString()!=null);
		System.out.println(task.toJSONString());
		System.out.println(v.toJSONString());
		assertTrue(v.toJSONString()!=null);

	}
	
	@Test
	public void testCRSExecute() throws Throwable
	{
		TaskContent task=new TaskContent();
		Result v;
		task.setImo("8209626");
		v=ExecutorUtils.excute("CRSExecutor",task);
		assertTrue(task.toJSONString()!=null);
		System.out.println(task.toJSONString());
		System.out.println(v.toJSONString());
		assertTrue(v.toJSONString()!=null);

	}
	
	@Test
	public void testIRSExecute() throws Throwable
	{
		TaskContent task=new TaskContent();
		Result v;
		task.setImo("9157674");
		v=ExecutorUtils.excute("IRSExecutor",task);
		assertTrue(task.toJSONString()!=null);
		System.out.println(task.toJSONString());
		System.out.println(v.toJSONString());
		assertTrue(v.toJSONString()!=null);

	}
	
	@Test
	public void testLRSExecute() throws Throwable
	{
		TaskContent task=new TaskContent();
		Result v;
		task.setImo("9466362");
		v=ExecutorUtils.excute("LRSExecutor",task);
		assertTrue(task.toJSONString()!=null);
		System.out.println(task.toJSONString());
		System.out.println(v.toJSONString());
		assertTrue(v.toJSONString()!=null);

	}
	
	@Test
	public void testRMRSExecute() throws Throwable
	{
		TaskContent task=new TaskContent();
		Result v;
		task.setImo("9130133");
		v=ExecutorUtils.excute("RMRSExecutor",task);
		assertTrue(task.toJSONString()!=null);
		System.out.println(task.toJSONString());
		System.out.println(v.toJSONString());
		assertTrue(v.toJSONString()!=null);

	}
	

}
