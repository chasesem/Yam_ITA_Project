package com.robot.node.taskExecutor.test;

import static org.junit.Assert.assertNotNull;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.ExecutorUtils;

public class DNVGLExecutorTest extends BasicTest {

	TaskContent task = new TaskContent();

	@Before
	public void setUp() throws Exception {
		task.setImo(imo);
	}

	@Parameters(name = "{0}")
	public static Iterable<Object[]> portPairs() {
		return Arrays.asList(new Object[][] { 
				{ "9406647" }, 
				});
	}

	@Parameter(value = 0)
	public String imo;

	@Test
	public void testExecute() throws Throwable {
		Result result = ExecutorUtils.excute("DNVGLExecutor", task);
		assertNotNull(result);
		assertNotNull(result.getName());
		System.out.println(result.toJSONString());
	}
}