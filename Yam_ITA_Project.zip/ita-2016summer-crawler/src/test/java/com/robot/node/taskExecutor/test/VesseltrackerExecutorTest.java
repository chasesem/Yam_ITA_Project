package com.robot.node.taskExecutor.test;

import static org.junit.Assert.assertNotNull;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.ExecutorUtils;

public class VesseltrackerExecutorTest extends BasicTest {

	TaskContent task = new TaskContent();

	@Before
	public void setUp() throws Exception {
		task.setWithinHour(withinHour);
	}

	@Parameters(name = "{0}")
	public static Iterable<Object[]> portPairs() {
		return Arrays.asList(new Object[][] { // http://www.vesseltracker.com/en/NewsHome.html?hours=11&hide=false
				// 数据为hours后的值，只能是这3个
						{ 24 }, 
						{ 48 }, 
						{ 96 },

				});
	}

	@Parameter(value = 0)
	public int withinHour;

	@Test
	public void testExecute() throws Throwable {
		Result result = ExecutorUtils.excute("com.robot.crawler.task.executor.VesseltrackerExecutor", task);
		String articlesJson = result.toJSONString();
		assertNotNull(articlesJson);
		for (int i = 0; i < result.getArticles().size(); i++) {
			assertNotNull(result.getArticles().get(i).getArticleId());
			System.out.println(result.getArticles().get(i).toJSONString());
		}
	}
}