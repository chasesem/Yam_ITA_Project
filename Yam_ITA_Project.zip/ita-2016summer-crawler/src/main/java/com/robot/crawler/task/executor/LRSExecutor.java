package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class LRSExecutor extends BaseExecutor {

	static String cookies;
	static String SEARCH_URL = "http://www.lrshipsinclass.lrfairplay.com/authenticated/result.aspx?Page=0&LR/IMO=";
	static String LOGIN_URL = "http://www.lrshipsinclass.lrfairplay.com/default.aspx";
	static String INDEX = "http://www.lrshipsinclass.lrfairplay.com/default.aspx";
	@Override
	public Result execute(TaskContent task)  throws Exception{
		String result=HttpClientUtils.getBackHtml(INDEX);
		String __VIEWSTATE=result.substring(result.indexOf("__VIEWSTATE\" value=\"")+"__VIEWSTATE\" value=\"".length());
		__VIEWSTATE=__VIEWSTATE.substring(0,__VIEWSTATE.indexOf("\" />"));
		logger.info(__VIEWSTATE);
		NameValuePair[] param =new NameValuePair[5];
		param[0] = new BasicNameValuePair("__VIEWSTATE", __VIEWSTATE);
		param[1] = new BasicNameValuePair("Login:txtUserName", "howardztark@gmail.com");
		param[2] = new BasicNameValuePair("Login:txtPassword", "jmatis");
		param[3] = new BasicNameValuePair("Login:btnLogin.x", "13");
		param[4] = new BasicNameValuePair("Login:btnLogin.y", "123");
		result=HttpClientUtils.postBackHtml(LOGIN_URL, param);
		String result2=HttpClientUtils.getBackHtml(SEARCH_URL+task.getImo());
		HttpClientUtils.closeClient();
		return convertHtmlToBean(result2);
	}
	
	public Result convertHtmlToBean(String res){
		Document doc=Jsoup.parse(res);
		Element body=doc.body();
		Result v=new Result();
		v.setName(body.getElementById("VesselName").text());
		v.setImo(body.getElementById("lrno").text());
		v.setOwner(body.getElementById("owner").text());
		v.setStatus(body.getElementById("status").text());
		v.setFlag(body.getElementById("FlagName").text());
		v.setLength_in_m(body.getElementById("LOA").text());
		v.setDwt_on_draft_in_ton(body.getElementById("dwt").text());
		v.setWidth_in_m(body.getElementById("Breadth").text());
		v.setGt_in_ton(body.getElementById("gt").text());
		v.setDraft_in_m(body.getElementById("draught").text());
		String iws=body.getElementsContainingOwnText("*IWS:").get(0).parent().text();
		v.setIce_class(iws.substring(iws.indexOf("*IWS:LI :"),iws.indexOf("at draught of")).trim());
		v.setVsl_type(body.getElementById("VesselType").text());
		v.setBuilder(body.getElementById("shipbuilder").text());
		v.setBulid_year(body.getElementById("DateOfBuild").text());
		return v;
	}
}
