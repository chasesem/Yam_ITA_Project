package com.robot.crawler.jms;

import javax.jms.Message;

public interface Sender {
	void sendMessage(Message msg);
}
