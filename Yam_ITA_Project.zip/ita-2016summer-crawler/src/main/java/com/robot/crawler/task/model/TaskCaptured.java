package com.robot.crawler.task.model;

import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

public class TaskCaptured {
	private String capturedTaskId;
	private String projectOwner;
	private String taskType;
	private String capturedTaskResult;
	private String hostName;
	private String appId;
	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")  
	private Date createTime;
	@JSONField (format="yyyy-MM-dd'T'HH:mm:ss'Z'")  
	private Date lastUpdateTime;
	
	
	public String getCapturedTaskId() {
		return capturedTaskId;
	}

	public void setCapturedTaskId(String capturedTaskId) {
		this.capturedTaskId = capturedTaskId;
	}
	
	public String getProjectOwner() {
		return projectOwner;
	}

	public void setProjectOwner(String projectOwner) {
		this.projectOwner = projectOwner;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getCapturedTaskResult() {
		return capturedTaskResult;
	}

	public void setCapturedTaskResult(String capturedTaskResult) {
		this.capturedTaskResult = capturedTaskResult;
	}


	public String getHostName() {
		return hostName;
	}


	public void setHostName(String hostName) {
		this.hostName = hostName;
	}


	public String getAppId() {
		return appId;
	}


	public void setAppId(String appId) {
		this.appId = appId;
	}
	

	public Date getCreateTime() {
		return createTime;
	}


	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}


	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}


	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}


	public String toString(){
		return JSON.toJSONString(this).toString();
	}
}
