package com.robot.crawler.model;

public class Event {

	private String eventDateTime;
	private String isExcavated;

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public String getIsExcavated() {
		return isExcavated;
	}

	public void setIsExcavated(String isExcavated) {
		this.isExcavated = isExcavated;
	}

}
