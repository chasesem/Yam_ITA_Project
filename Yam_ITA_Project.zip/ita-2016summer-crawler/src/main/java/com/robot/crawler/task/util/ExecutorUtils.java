package com.robot.crawler.task.util;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.TaskExecutor;
import com.robot.crawler.task.model.TaskContent;

public class ExecutorUtils {
	public synchronized static Result excute(String className,TaskContent task) throws Exception {
        	Class<?> iclass=null;
			iclass=Class.forName(className);
	        TaskExecutor taskExecutor=null;
	        taskExecutor=(TaskExecutor)iclass.newInstance();
	        return taskExecutor.execute(task);
		

	}
}
