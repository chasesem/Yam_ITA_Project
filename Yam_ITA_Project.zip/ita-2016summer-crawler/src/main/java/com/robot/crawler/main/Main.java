package com.robot.crawler.main;


import java.io.FileNotFoundException;
import java.io.IOException;

import javax.jms.JMSException;

import org.apache.commons.cli.ParseException;

public class Main {
	
	public static void main(String[] args) throws FileNotFoundException, ParseException, IOException, JMSException {
//		WebsocketClientApp clientApp = WebsocketClientApp.getInstance();
//		clientApp.start();
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
//		String input =""; 
//		
//		 try { 
//				do{
//				 input = br.readLine(); 
//				if(!input.equals("exit"))
//				clientApp.getSession().getBasicRemote().sendText(input);
//		
//				}while(!input.equals("exit"));
//
//		 } catch (IOException e) { 
//			 e.printStackTrace();
//		}
		
//		new TaskProducer().start();
//		new TaskConsumer().consum();
		System.out.println("hello world");
//		TopicRecevier.recevieMessage();
		if(args.length<1){
			String[] debugs = {"-f","crawler.properties","-id","hehe5"};
			CommandController.execute(debugs);
		}else{
			CommandController.execute(args);
		}
		
		
		
		
	}
}
