package com.robot.crawler.model;

public class Place {

	private String name;
	private String code;
	private String latitude;
	private String longitude;
	private String isExcavated;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getIsExcavated() {
		return isExcavated;
	}

	public void setIsExcavated(String isExcavated) {
		this.isExcavated = isExcavated;
	}

}
