package com.robot.crawler.excutor;

public interface Excutor {
	void execute(String str);
}
