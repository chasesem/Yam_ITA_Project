package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class ABSExecutor extends BaseExecutor {
	private final static String SEARCH_URL = "http://www.eagle.org/safenet/record/record_vesselsearch";
	private final static String Target_URL = "http://www.eagle.org/safenet/record/record_vesseldetailsprinparticular?Classno=111111&Accesstype=PUBLIC&ReferrerApplication=PUBLIC";
	private final static String Machinery_URL = "http://www.eagle.org/safenet/record/record_vesseldetailsmach?ReferrerApplication=PUBLIC";
	private final static String Owner_URL = "http://www.eagle.org/safenet/record/record_ownerManager?ReferrerApplication=PUBLIC";
	Result vessel = new Result();

	@Override
	public Result execute(TaskContent task) {

		try {
			String clzNum = searchClzNum(task);
			String result = HttpClientUtils.getBackHtml(Target_URL.replace(
					"111111", clzNum));

			Document doc = Jsoup.parse(result);

			Elements tds = doc.select(".innertable").get(2).select("tbody")
					.select("tr").get(1).select("td");
			String name = tds.get(0).text();
			vessel.setName(name);
			String imo = task.getImo();
			vessel.setImo(imo);
			String status = tds.get(3).text();
			vessel.setStatus(status);

			Elements trs = doc.select(".tableforms").get(1).select("tbody")
					.select("tr");
			String callSign = trs.get(2).select("td").get(2).text();
			vessel.setCall_sign(callSign);
			String flagName = trs.get(3).select("td").get(2).text();
			vessel.setFlag(flagName);
			String portOfRegistration = trs.get(4).select("td").get(2).text();
			vessel.setPort(portOfRegistration);
			String deliveryDate = doc
					.getElementsContainingOwnText("Delivery Date").get(0)
					.nextElementSibling().text();//
			vessel.setBulid_year(deliveryDate);
			Element ele = doc.select(".tableforms").get(2).select("tbody")
					.select("tr").get(2).select("td").get(2);
			String vesselType = ele.text();
			vessel.setVsl_type(vesselType);
			trs = doc.select(".tableforms").get(13).select("tbody")
					.select("tr");
			String designDeadweight = doc
					.getElementsContainingOwnText("Design Deadweight").get(0)
					.nextElementSibling().text();//
			vessel.setDwt_on_draft_in_ton(designDeadweight);
			String moldedBreadthM = doc
					.getElementsContainingOwnText("Molded Breadth(M)").get(0)
					.nextElementSibling().text();//
			vessel.setWidth_in_m(moldedBreadthM);
			if (doc.getElementsContainingOwnText("Design TEU").size() > 0) {
				String designTEU = doc
						.getElementsContainingOwnText("Design TEU").get(0)
						.nextElementSibling().text();
				vessel.setTeu(designTEU);
			}
			String lengthOverallLOA = doc
					.getElementsContainingOwnText("Length Overall LOA").get(0)
					.nextElementSibling().text();
			vessel.setLength_in_m(lengthOverallLOA);

			String grossTonnage = doc.getElementsContainingOwnText("ITC")
					.get(0).nextElementSibling().text();
			String netTonnage = doc.getElementsContainingOwnText("ITC").get(0)
					.lastElementSibling().text();
			if (!grossTonnage.contains("Registered")) {
				grossTonnage = doc.getElementsContainingOwnText("NATIONAL")
						.get(1).nextElementSibling().text();
				netTonnage = doc.getElementsContainingOwnText("NATIONAL")
						.get(1).lastElementSibling().text();
			}
			vessel.setGt_in_ton(grossTonnage);
			vessel.setNt_in_ton(netTonnage);

			String builder = doc
					.getElementsContainingOwnText("Builder Building ID").get(0)
					.parent().nextElementSibling().children().get(0).text();
			vessel.setShipyard(builder);
			parseMachineryPage();
			parseOwnerPage();
			HttpClientUtils.closeClient();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vessel;
	}

	protected String searchClzNum(TaskContent task) {// 返回和imo对应的Classno
		try {
			NameValuePair params[] = new BasicNameValuePair[1];
			params[0] = new BasicNameValuePair("IMO_NUM",
					task.getImo() != null ? task.getImo() : "");
			Document doc = Jsoup.parse(HttpClientUtils.postBackHtml(SEARCH_URL,
					params));
			Element clzNumEle = doc.select(".tableforms").get(2)
					.select("tbody").select("tr").select("td a").get(0);
			String clzNum = clzNumEle.text();
			return clzNum;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	protected void parseMachineryPage() {// 解析MachineryPage
		try {
			Document doc = Jsoup.parse(HttpClientUtils
					.getBackHtml(Machinery_URL));
			Element ele = doc.getElementsContainingOwnText(
					"Manufacturer Name :").get(0);
			String manufacturerName = ele.nextElementSibling().text();
			vessel.setShipyard(manufacturerName);
			ele = doc.getElementsContainingOwnText("Model Number :").get(0);
			String modelNumber = ele.nextElementSibling().text();
			vessel.setMain_engine(modelNumber);
			logger.info(HttpClientUtils.getBackHtml(Machinery_URL));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void parseOwnerPage() {// 解析OwnerPage
		try {
			Document doc = Jsoup.parse(HttpClientUtils.getBackHtml(Owner_URL));
			Element ele = doc.select(".tableforms").get(1).select("tbody")
					.select("tr").get(1).select("td").get(1);
			String registeredOwner = ele.text();
			vessel.setRegisteredOwner(registeredOwner);
			ele = doc.select(".tableforms").get(2).select("tbody").select("tr")
					.get(1).select("td").get(1);
			String ownerOrOperator = ele.text();
			vessel.setOwner(ownerOrOperator);
			logger.info(HttpClientUtils.getBackHtml(Owner_URL));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
