package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class RMRSExecutor extends BaseExecutor {

	static String cookies;
	static String SEARCH_URL = "http://info.rs-head.spb.ru/webFS/regbook/vessel?fleet_id=";
	static String LOGIN_URL = "http://info.rs-head.spb.ru/webFS/regbook/regbookVessel";
	static String LANG_URL = "http://info.rs-head.spb.ru/webFS/regbook/regbookVessel?ln=en";
	
	@Override
	public Result execute(TaskContent task)  throws Exception{
		HttpClientUtils.getBackHtml(LANG_URL);
		
		NameValuePair[] param =new NameValuePair[5];
		param[0] = new BasicNameValuePair("gorod_id1", "0");
		param[1] = new BasicNameValuePair("stran_id1", "0");
		param[2] = new BasicNameValuePair("statgr_id.x", "0");
		param[3] = new BasicNameValuePair("icecat", "");
		param[4] = new BasicNameValuePair("namer", task.getImo());
		String result=HttpClientUtils.postBackHtml(LOGIN_URL, param);
		result=HttpClientUtils.getBackHtml(SEARCH_URL+result.substring(result.indexOf("fleet_id=")+"fleet_id=".length(),result.indexOf("fleet_id=")+"fleet_id=".length()+6));
		HttpClientUtils.closeClient();
		return convertHtmlToBean(result.replace("display:none;", ""));
	}

	public Result convertHtmlToBean(String res){
		Document doc=Jsoup.parse(res);
		Element body=doc.body();
		Result v=new Result();
		v.setName(body.getElementsContainingOwnText("Name of vessel").get(0).nextElementSibling().text());
		v.setCall_sign(body.getElementsContainingOwnText("Call sign").get(0).nextElementSibling().text());
		v.setPort(body.getElementsContainingOwnText("Port of registry").get(0).nextElementSibling().text());
		v.setFlag(body.getElementsContainingOwnText("Flag").get(0).nextElementSibling().text());
		v.setVsl_type(body.getElementsContainingOwnText("Basic type").get(0).nextElementSibling().text());
		v.setBulid_year(body.getElementsContainingOwnText("Date of build").get(0).nextElementSibling().text());
		v.setGt_in_ton(body.getElementsContainingOwnText("Gross tonnage").get(0).nextElementSibling().text());
		v.setNt_in_ton(body.getElementsContainingOwnText("Tonnage").get(1).nextElementSibling().text());
		v.setDwt_on_draft_in_ton(body.getElementsContainingOwnText("Deadweight").get(0).nextElementSibling().text());
		v.setLength_in_m(body.getElementsContainingOwnText("Length overall").get(0).nextElementSibling().text());
		v.setWidth_in_m(body.getElementsContainingOwnText("Moulded breadth").get(0).nextElementSibling().text());
		v.setDraft_in_m(body.getElementsContainingOwnText("Draught").get(0).nextElementSibling().text());
		v.setSpeed(body.getElementsContainingOwnText("Speed").get(1).nextElementSibling().text());
		v.setAutomatic_identification_system("Automatic identification system:"+body.getElementsContainingOwnText("Automatic identification system;")==null?"false":"true");
		v.setTeu(body.getElementsContainingOwnText("Number and type of containers").get(0).nextElementSibling().text());
		return v;
	}
	
}
