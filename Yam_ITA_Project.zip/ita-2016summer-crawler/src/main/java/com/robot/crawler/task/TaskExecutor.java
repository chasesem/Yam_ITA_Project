package com.robot.crawler.task;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.model.TaskContent;

public interface TaskExecutor {
	public Result execute(TaskContent task) throws Exception;
}
