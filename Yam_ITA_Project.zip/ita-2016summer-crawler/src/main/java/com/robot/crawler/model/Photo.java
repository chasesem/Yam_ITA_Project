package com.robot.crawler.model;

import com.alibaba.fastjson.JSONObject;

public class Photo {

	private String url;

	public Photo() {
		super();

	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String toJSONString() {
		return JSONObject.toJSONString(this);
	}
}
