package com.robot.crawler.jersey.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.glassfish.jersey.client.ClientConfig;



public class JClient {
	
	private final static Logger logger = LogManager.getLogger(JClient.class);
	
	public final static String RESPONSE_HOST_PATH = "http://10.222.47.44:8099/";
	public final static String SAVE_RESPONSE_PATH = "save/output";
	public final static String PROFILE_HOST_PATH = "http://10.222.47.44:8092/";
	public final static String GET_PROFILE_PATH = "profile/get/one";
	public final static String UPDATE_HOST = "http://10.222.47.44:8099/";
	public final static String UPDATE_PATH = "save/update";
	
	private Client client;
	
	public JClient(){
		client = ClientBuilder.newClient(new ClientConfig());
	}
	
	public String getProfile(String category){
		WebTarget webTarget = client.target(PROFILE_HOST_PATH);
		webTarget = webTarget.queryParam("category", category);
		return doGet(webTarget,GET_PROFILE_PATH);
	}
	
	public String saveTask(String json){
		WebTarget webTarget = client.target(RESPONSE_HOST_PATH);
		return doPost(webTarget,SAVE_RESPONSE_PATH,json);
	}
	
	public String updateTask(String taskId,String taskStatus){
		WebTarget webTarget = client.target(UPDATE_HOST);
		Form form = new Form();
		form.param("taskId", taskId);
		form.param("taskStatus", taskStatus);
		return doPost(webTarget,UPDATE_PATH,form);
		
	}
	
	private String doPost(WebTarget webTarget,String path,String str){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(str,MediaType.APPLICATION_JSON));
		logger.debug(response.getStatus());
		logger.debug("back+"+response.readEntity(String.class));
		return "SUCCESS";
	}
	
	private String doPost(WebTarget webTarget,String path,Form form){
		Response response = webTarget.path(path).request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(form,MediaType.APPLICATION_FORM_URLENCODED));
		logger.debug(response.getStatus());
		logger.debug("back+"+response.readEntity(String.class));
		return "SUCCESS";
	}

	
	private String doGet(WebTarget webTarget,String path){
		Invocation.Builder invocationBuilder = webTarget.path(path).request(MediaType.TEXT_PLAIN);
		invocationBuilder.header("some-header", "true");
		Response response = invocationBuilder.get();
		logger.debug(response.getStatus());
		String re = response.readEntity(String.class);
		logger.info(re);
		return re;
	}
	
	


}
