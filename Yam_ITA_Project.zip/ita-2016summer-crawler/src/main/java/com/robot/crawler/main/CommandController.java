package com.robot.crawler.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.MessageListener;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.cli.PosixParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.robot.crawler.jms.ExecuteCase;
import com.robot.crawler.jms.JMSConnectionFactory;
import com.robot.crawler.jms.OnJMSMessageHandler;
import com.robot.crawler.jms.QueueRecevier;
import com.robot.crawler.jms.QueueSender;
import com.robot.crawler.model.App;

public class CommandController {
	private final static Logger logger = LogManager.getLogger(CommandController.class);
	
	private final static String JMS_USER = "jms.user";
	private final static String JMS_PASSWOED = "jms.password";
	private final static String JMS_URL = "jms.url";
	private final static String JMS_QUEUE_PRODUCE = "jms.queue.produce";
	private final static String JMS_QUEUE_CONSUME = "jms.queue.consume";
	
	public static void execute(String[] args) throws ParseException, FileNotFoundException, IOException, JMSException{
		Options options = new Options();
		options.addOption("f",true,"set properties file");
		options.addOption("id",true,"set app id");
		CommandLineParser parser = new PosixParser();
		CommandLine cmd = parser.parse(options, args);
		
		if(!cmd.hasOption("id")){
			return;
		}
		App.setvAppId(cmd.getOptionValue("id"));
		if(cmd.hasOption("f")){
			File file = new File(cmd.getOptionValue("f")); 
			Properties prop = new Properties();
			prop.load(new FileInputStream(file));
			System.out.println(prop.getProperty(JMS_USER)+"+"+prop.getProperty(JMS_PASSWOED)+"+"+prop.getProperty(JMS_URL));
			JMSConnectionFactory factory = new JMSConnectionFactory(prop.getProperty(JMS_USER),prop.getProperty(JMS_PASSWOED),prop.getProperty(JMS_URL));
			QueueSender queueSender = QueueSender.getInstance(prop.getProperty(JMS_USER),prop.getProperty(JMS_PASSWOED),prop.getProperty(JMS_URL),prop.getProperty(JMS_QUEUE_PRODUCE));
			ExecuteCase executeCase = new ExecuteCase(queueSender);
			MessageListener messageListener = new OnJMSMessageHandler(executeCase);
			try {
				QueueRecevier queueRecevier = new QueueRecevier(factory.getQueueConnection(),prop.getProperty(JMS_QUEUE_CONSUME));
				queueRecevier.recevieMessage(messageListener);
			} catch (JMSException e) {
				logger.warn(e);
			}; 
		}else{
			System.out.println("need properties file");
		}
	}


}
