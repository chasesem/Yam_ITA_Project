package com.robot.crawler.websocket.core;

import java.io.IOException;

import javax.websocket.ClientEndpoint;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.OnClose;
import javax.websocket.Session;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.robot.crawler.handler.OnErrorHandler;
import com.robot.crawler.handler.OnMessageHandler;
import com.robot.crawler.handler.ReconnectHandler;

@ClientEndpoint
public class WebsocketClient {
	
	private final static Logger logger = LogManager.getLogger(WebsocketClient.class);
	
	private OnErrorHandler onErrorHandler;
	private OnMessageHandler onMessageHandler;
	
	public WebsocketClient(){
		onErrorHandler = new ReconnectHandler();
		onMessageHandler = new OnMessageHandler();
	}

	@OnOpen
	public void onOpen(Session session){
		logger.info("Connected to endpoint"+session.getBasicRemote());
		try {
			session.getBasicRemote().sendText("hello");
		} catch (IOException e) {
			logger.error(e);
		}
	}
	
	@OnMessage
	public void onMessage(String message){
		System.out.println(message);
		onMessageHandler.handlerMessage(message);
	}
	
	@OnError
	public void onError(Throwable t){
		onErrorHandler.handleError();
		logger.error("connect error", t);
	}
	
	@OnClose
	public void OnClose(){
		logger.info("connect close");
//		onErrorHandler.handleError();
	}
	
	
	
}
