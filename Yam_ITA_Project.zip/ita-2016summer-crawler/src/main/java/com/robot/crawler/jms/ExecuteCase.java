package com.robot.crawler.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.robot.crawler.jersey.client.JClient;
import com.robot.crawler.model.App;
import com.robot.crawler.model.Result;
import com.robot.crawler.task.model.Task;
import com.robot.crawler.task.model.TaskCaptured;
import com.robot.crawler.task.model.TaskITranslated;
import com.robot.crawler.task.util.ExecutorUtils;

public class ExecuteCase implements OnMessageCase{
	
	private final static Logger logger = LogManager.getLogger(ExecuteCase.class);
	
	private Sender sender;
	private JClient client;
	private Result vessel;
	private String category;
	
	public ExecuteCase(Sender sender){
		this.sender = sender;
		this.client = new JClient();
	}

	public void action(Message message) throws JMSException {
		TextMessage msg = (TextMessage) message;
		TaskITranslated rTask = JSON.parseObject(msg.getText(), TaskITranslated.class);
		try {
			client.updateTask(rTask.getiTranslatedTaskId(), Task.CAPTUREING);
			category = client.getProfile(rTask.getTaskContent().getCategory());
			vessel = ExecutorUtils.excute(category, rTask.getTaskContent());
			System.out.println("result"+vessel.toJSONString());
			TaskCaptured taskCaptured = new TaskCaptured();
			taskCaptured.setCapturedTaskId(rTask.getiTranslatedTaskId());
			taskCaptured.setProjectOwner(rTask.getProjectOwner());
			taskCaptured.setTaskType(rTask.getTaskType());
			taskCaptured.setCapturedTaskResult(vessel.toJSONString());
			taskCaptured.setAppId(App.getInstance().getAppId());
			taskCaptured.setHostName(App.getInstance().getHostName());
			ActiveMQTextMessage outputMap = new ActiveMQTextMessage();
			outputMap.setText(taskCaptured.toString());
			sender.sendMessage(outputMap);
			client.saveTask(taskCaptured.toString());
		} catch (JMSException e) {
			logger.error("crawler"+e);
		} catch (Exception e) {
			client.updateTask(rTask.getiTranslatedTaskId(), Task.CAPTURED_FAIL);
			logger.error("crawler"+e);
		}
		
	}

}
