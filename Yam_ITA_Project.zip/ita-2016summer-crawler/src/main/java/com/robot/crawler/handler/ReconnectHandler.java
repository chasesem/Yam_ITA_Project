package com.robot.crawler.handler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.robot.crawler.websocket.core.WebsocketClientApp;

public class ReconnectHandler implements OnErrorHandler{
	
	private final static Logger logger = LogManager.getLogger(ReconnectHandler.class);
	
	private static long time = 5;

	public void handleError() {
		WebsocketClientApp clientApp = WebsocketClientApp.getInstance();
		while(!clientApp.getSession().isOpen()){
			clientApp.restart();
			try {
				Thread.currentThread();
				Thread.sleep(time);
			} catch (InterruptedException e) {
				logger.error("handler error",e);
			}
		}
		
	}

}
