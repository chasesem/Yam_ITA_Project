package com.robot.crawler.task.executor;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.robot.crawler.model.Article;
import com.robot.crawler.model.Photo;
import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;
import com.robot.crawler.task.util.TimerUtils;



public class FleetMonExecutor extends BaseExecutor {
	private final static String NEWS_URL = "https://www.fleetmon.com/maritime-news/?page=";
	private final static String HOME_URL = "https://www.fleetmon.com";
	//private final static String COOKIE = "csrftoken=iWQAaEpXPCxoidodfKMDNbB0WoTo8LdG; ajs_anonymous_id=null; _ga=GA1.2.2135148142.1471328448; intercom-visitor-semaphore-kwshk9to=1; fm_remember=\"1471329191_1636967:1bZXvz:nHDkqkbyuXxk-hsr2zRXnmRVxyM\"";
	//private final static String COOKIE1 = "csrftoken=iWQAaEpXPCxoidodfKMDNbB0WoTo8LdG; ajs_anonymous_id=null; _ga=GA1.2.2135148142.1471328448; intercom-visitor-semaphore-kwshk9to=1; fm_remember=\"1471329191_1636967:1bZXvz:nHDkqkbyuXxk-hsr2zRXnmRVxyM\"; fmc_session=otxdhsak75685ota68w1ucq78zgx8jtf; _hjIncludedInSample=1; cookieconsent_dismissed=yes";
	Result Vessel=new Result();

	@Override
	public Result execute(TaskContent task) {
		try {
			List<Article> articleList = new ArrayList<Article>();
			String beginTime = TimerUtils.getbeginTime(task.getWithinHour());
			int page = 1000;
			for (int j = 1; j <= page; j++) {
				String result = HttpClientUtils.getBackHtml(NEWS_URL+j);
				Document doc = Jsoup.parse(result);
				Elements eles = doc.select("article");
				for (int i = 0; i < 20; i++) {
					String publishTime = eles.get(i).select(".news-info")
							.get(0).ownText();
					if (TimerUtils.fleetMoncompare(publishTime, beginTime)) {
						Article article = parseEachNew(eles.get(i));
						article.setSource("FleetMon");
						articleList.add(article);
					} else {
						page = 0;
						break;
					}
				}
			}
			Vessel.setArticles(articleList);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return Vessel;

	}

	protected Article parseEachNew(Element newsEle) {//
		try {
			Article article = new Article();
			Photo photo = new Photo();
			String url = HOME_URL
					+ newsEle.select("h2").select("a").attr("href");
			String articleId = url.split("/")[5];
			article.setArticleId(articleId);
			article.setUrl(url);
			String photoUrl = "https:"
					+ newsEle.select("img").first().attr("src");
			photo.setUrl(photoUrl);
			article.setPhoto(photo);
			String headline = newsEle.select("h2").get(0).text();
			article.setHeadline(headline);
			String publishDateTime = newsEle.select(".news-info").get(0)
					.ownText();
			article.setPublishDateTime(TimerUtils
					.fleetMonParse(publishDateTime));
			String author = newsEle.select(".news-info").get(1).select("a")
					.first().ownText();
			article.setAuthor(author);
			String category = newsEle.select(".news-info").get(2).select("a")
					.first().text();
			article.setCategory(category);
			String bodyPreview = newsEle.select("p").first().ownText();
			article.setBodyPreview(bodyPreview);
			String body = getContent(url);
			article.setBody(body);
			return article;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	protected String getContent(String url) {
		try {
			String result = HttpClientUtils.getBackHtml(url);
			Document doc = Jsoup.parse(result);
			Elements eles = doc.select("#news-text");
			String content = eles.first().text();
			return content;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

}
