package com.robot.crawler.excutor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.robot.crawler.websocket.core.WebsocketClientApp;

public class CommandExcetor implements Excutor{
	
	private final static Logger logger = LogManager.getLogger(CommandExcetor.class);
	
	public static final String KILL = "kill";
	public static final String RESTART = "restart";
	public static final String NOCOMMAND = "not a command";
	
	public void  execute(String command) {
		if(command.equals(KILL))
			WebsocketClientApp.getInstance().stop();
		if(command.equals(RESTART))
			WebsocketClientApp.getInstance().restart();
		else
			logger.warn(NOCOMMAND+":"+command);
	
	}

}
