package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class CCSExecutor extends BaseExecutor {
	private final static String SEARCH_URL = "http://psmis.ccs.org.cn/ship/list.do";
	private final static String Target_URL = "http://psmis.ccs.org.cn/ship/singleship.do?ccsno=111111&language=en";
	Result vessel = new Result();

	@Override
	public Result execute(TaskContent task) {

		try {
			String clzNum = searchClzNum(task);
			String result = HttpClientUtils.getBackHtml(Target_URL.replace(
					"111111", clzNum));
			HttpClientUtils.closeClient();
			Document doc = Jsoup.parse(result);
			Elements tds = doc.select("table tbody tr td");
			String englishName = tds.get(2).text();
			vessel.setName(englishName);
			String signalLetter = tds.get(3).text();
			vessel.setCall_sign(signalLetter);
			String imono = tds.get(4).text();
			vessel.setImo(imono);
			String flagState = tds.get(6).text();
			vessel.setFlag(flagState);
			String por = tds.get(7).text();
			vessel.setPort(por);
			String owner = tds.get(8).text();
			vessel.setOwner(owner);
			String operator = tds.get(9).text();
			vessel.setRegisteredOwner(operator);
			String tosap = tds.get(10).text();
			vessel.setVsl_type(tosap);
			String gt = tds.get(12).text();
			vessel.setGt_in_ton(gt);
			String nt = tds.get(13).text();
			vessel.setNt_in_ton(nt);
			String dw = tds.get(14).text();
			vessel.setDwt_on_draft_in_ton(dw);
			String loa = tds.get(15).text();
			vessel.setLength_in_m(loa);
			String bm = tds.get(17).text();
			vessel.setWidth_in_m(bm);
			String draught = tds.get(20).text();
			vessel.setDraft_in_m(draught);
			String speed = tds.get(21).text();
			vessel.setSpeed(speed);

			String shipBuilder = tds.get(30).text();
			vessel.setShipyard(shipBuilder);
			String dosb = tds.get(32).text();
			vessel.setBulid_year(dosb);
			String cs = tds.get(45).text();
			vessel.setTeu(cs);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return vessel;
	}

	protected String searchClzNum(TaskContent task) {
		try {
			NameValuePair params[] = new BasicNameValuePair[1];
			params[0] = new BasicNameValuePair("ccsimono",
					task.getImo() != null ? task.getImo() : "");
			Document doc = Jsoup.parse(HttpClientUtils.postBackHtml(SEARCH_URL,
					params));
			String clzNum = "";
			if (doc.select(".devil_table").select("tbody").select("tr").size()>0) {
				Element clzNumEle = doc.select(".devil_table").select("tbody")
						.select("tr").select("td a u").get(0);
				clzNum=clzNumEle.text();
			}
			return clzNum;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
