package com.robot.crawler.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;


public class OnJMSMessageHandler implements MessageListener{
	private OnMessageCase onMessageCase;
	
	public OnJMSMessageHandler(){}
	
	public OnJMSMessageHandler(OnMessageCase onMessageCase){
		this.onMessageCase = onMessageCase;
	}
	
	public void setOnMessageCase(OnMessageCase onMessageCase) {
		this.onMessageCase = onMessageCase;
	}

	public void onMessage(Message message) {
		if (message != null) {
            TextMessage msg = (TextMessage) message;
            try {
            	System.out.println("crawler"+msg.getText());
                if(msg.getText()!=null)
                	 onMessageCase.action(message);
            } catch (JMSException e) {
                e.printStackTrace();
            } 
        }
		
		
	}

}
