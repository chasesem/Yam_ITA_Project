package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class CRSExecutor extends BaseExecutor {

	static String cookies;
	static String SEARCH_URL = "http://report.crs.hr/hrbwebreports/Default.aspx";
	static String LOGIN_URL = "";
	@Override
	public Result execute(TaskContent task) throws Exception{
		String result=HttpClientUtils.getBackHtml(SEARCH_URL);
		String __EVENTVALIDATION=result.substring(result.indexOf("id=\"__EVENTVALIDATION\" value=\"")+"id=\"__EVENTVALIDATION\" value=\"".length());
		__EVENTVALIDATION=__EVENTVALIDATION.substring(0,__EVENTVALIDATION.indexOf("\" />"));
		String __VIEWSTATE=result.substring(result.indexOf("id=\"__VIEWSTATE\" value=\"")+"id=\"__VIEWSTATE\" value=\"".length());
		__VIEWSTATE=__VIEWSTATE.substring(0,__VIEWSTATE.indexOf("\" />"));
		NameValuePair[] param =new NameValuePair[7];
		param[0] = new BasicNameValuePair("__EVENTTARGET", "ctl00$contentSearchResults$dgrBrodovi$ctl04$lnkDetails");
		param[1] = new BasicNameValuePair("__EVENTARGUMENT", "");
		param[2] = new BasicNameValuePair("ctl00$contentSearchPanel$txtShipName", "");
		param[3] = new BasicNameValuePair("ctl00$contentSearchPanel$txtImoNo", task.getImo());
		param[4] = new BasicNameValuePair("ctl00$contentSearchPanel$btnSearch","Traži / Search");
		param[5] = new BasicNameValuePair("__EVENTVALIDATION",__EVENTVALIDATION);
		param[6] = new BasicNameValuePair("__VIEWSTATE",__VIEWSTATE);
		result=HttpClientUtils.postBackHtml(SEARCH_URL, param);
		__EVENTVALIDATION=result.substring(result.indexOf("id=\"__EVENTVALIDATION\" value=\"")+"id=\"__EVENTVALIDATION\" value=\"".length());
		__EVENTVALIDATION=__EVENTVALIDATION.substring(0,__EVENTVALIDATION.indexOf("\" />"));
		__VIEWSTATE=result.substring(result.indexOf("id=\"__VIEWSTATE\" value=\"")+"id=\"__VIEWSTATE\" value=\"".length());
		__VIEWSTATE=__VIEWSTATE.substring(0,__VIEWSTATE.indexOf("\" />"));
		param =new NameValuePair[6];
		param[0] = new BasicNameValuePair("__EVENTTARGET", "ctl00$contentSearchResults$dgrBrodovi$ctl04$lnkDetails");
		param[1] = new BasicNameValuePair("__EVENTARGUMENT", "");
		param[2] = new BasicNameValuePair("ctl00$contentSearchPanel$txtShipName", "");
		param[3] = new BasicNameValuePair("ctl00$contentSearchPanel$txtImoNo", task.getImo());
		param[4] = new BasicNameValuePair("__EVENTVALIDATION",__EVENTVALIDATION);
		param[5] = new BasicNameValuePair("__VIEWSTATE",__VIEWSTATE);
		result=HttpClientUtils.postBackHtml(SEARCH_URL, param);
		HttpClientUtils.closeClient();
		return convertHtmlToBean(result,task);
	}

	public Result convertHtmlToBean(String res,TaskContent task){
		Document doc=Jsoup.parse(res);
		Element body=doc.body();
		Result v=new Result();
		if(body.getElementsContainingOwnText("Brod Ship").size()>0){
			v.setName(body.getElementsContainingOwnText("Brod Ship").get(0).parent().nextElementSibling().getAllElements().get(1).text());
			v.setImo(body.getElementsContainingOwnText("Brod Ship").get(0).parent().nextElementSibling().getAllElements().get(3).text());
			v.setOwner(body.getElementsContainingOwnText("Vlasnik Owner").get(0).nextElementSibling().text());
			v.setManager(body.getElementsContainingOwnText("Brodar Manager").get(0).nextElementSibling().text());
			v.setFlag(body.getElementsContainingOwnText("Flag and port of registry").get(0).nextElementSibling().text().split(",")[0]);
			v.setPort(body.getElementsContainingOwnText("Flag and port of registry").get(0).nextElementSibling().text().split(",")[1]);
			v.setCall_sign(body.getElementsContainingOwnText("Call sign").get(0).nextElementSibling().text());
			v.setVsl_type(body.getElementsContainingOwnText("Ship type").get(0).nextElementSibling().text());
			v.setBuilder(body.getElementsContainingOwnText("Builder, Place of build").get(0).nextElementSibling().text().split(",")[0]);
			v.setBuilder_place(body.getElementsContainingOwnText("Builder, Place of build").get(0).nextElementSibling().text().split(",")[1]);
			v.setBulid_year(body.getElementsContainingOwnText("Date build").get(0).nextElementSibling().text());
			v.setLength_in_m(body.getElementsContainingOwnText("Length overall, Loa (m)").get(0).nextElementSibling().text());
			v.setWidth_in_m(body.getElementsContainingOwnText("Breadth (m)").get(0).nextElementSibling().text());
			v.setDraft_in_m(body.getElementsContainingOwnText("Draught (mm)").get(0).nextElementSibling().text());
			v.setGt_in_ton(body.getElementsContainingOwnText("TMC 69 gross tonnage, GT").get(0).nextElementSibling().text());
			v.setNt_in_ton(body.getElementsContainingOwnText("TMC 69 net tonnage, NT").get(0).nextElementSibling().text());
			v.setSpeed(body.getElementsContainingOwnText("Speed (kn)").get(0).nextElementSibling().text());
			v.setTeu(body.getElementsContainingOwnText("No. of containers (TEU)").get(0).nextElementSibling().text());
		}
		return v;
	}





}
