package com.robot.crawler.task.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HttpClientUtils {
	protected static Logger logger = LogManager.getLogger(HttpClientUtils.class
			.getName());
	static CloseableHttpClient closeableHttpClient = HttpClientBuilder.create()
			.build();
//	static RequestConfig config=RequestConfig.custom().setProxy(new HttpHost("52.90.68.181",8083)).build();
	static RequestConfig config=RequestConfig.custom().build();

	public static String getCookies(String url)
			throws ClientProtocolException, IOException {
		HttpPost httppost = new HttpPost(url);
		String set_cookie;
		HttpResponse response = closeableHttpClient.execute(httppost);
		if(response.getFirstHeader("Set-Cookie")!=null){
			set_cookie = response.getFirstHeader("Set-Cookie").getValue();
			logger.info("cookies:"
					+ set_cookie.substring(0, set_cookie.indexOf(";")));
			return set_cookie.substring(0, set_cookie.indexOf(";"));
		}else{
			return null;
		}
	}
	
	public static List<String> getCookiesAndHtml(String url) throws ClientProtocolException, IOException {
		List<String> list = new ArrayList<String>();
		HttpGet httpGet = new HttpGet(url);
		setHeader(httpGet);
		try {
			HttpResponse httpResponse = closeableHttpClient.execute(httpGet);

			if (httpResponse.getLastHeader("Set-Cookie") != null) {
				String set_cookie = httpResponse.getLastHeader("Set-Cookie").getValue();
				logger.info("cookies:" + set_cookie.substring(0, set_cookie.indexOf(";")));
				list.add(set_cookie.substring(0, set_cookie.indexOf(";")));
			}

			HttpEntity entity_re = httpResponse.getEntity();
			StringBuilder result = new StringBuilder();
			if (entity_re != null) {
				InputStream instream = entity_re.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(instream));
				String temp = "";
				while ((temp = br.readLine()) != null) {
					String str = new String(temp.getBytes(), "utf-8");
					result.append(str);
				}

			}
			list.add(result.toString());
			httpGet.releaseConnection();
			return list;
		} catch (IOException e) {
			throw new RuntimeException("请求失败");
		}

	}
	
	public static String getBackHtml(String url) throws RuntimeException{
		HttpGet httpGet = new HttpGet(url);
		setHeader(httpGet);
		try {
			HttpResponse httpResponse = closeableHttpClient.execute(httpGet);
			
			if(httpResponse.getLastHeader("Set-Cookie")!=null){
				String set_cookie = httpResponse.getLastHeader("Set-Cookie").getValue();	
				logger.info("cookies:"
						+ set_cookie.substring(0, set_cookie.indexOf(";")));
			}
			
			HttpEntity entity_re = httpResponse.getEntity();
			StringBuilder result = new StringBuilder();
			if (entity_re != null) {
				InputStream instream = entity_re.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						instream));
				String temp = "";
				while ((temp = br.readLine()) != null) {
					String str = new String(temp.getBytes(), "utf-8");
					result.append(str);
				}

			}
			httpGet.releaseConnection();
			return result.toString();
		} catch (IOException e) {
			throw new RuntimeException("请求失败");
		}
	}
	
	public static String getBackHtmlByCookies(String url,String cookies)
			throws RuntimeException {
		try{
			HttpGet httpGet = new HttpGet(url);
			setHeader(httpGet);
			if (url.contains("www.classnk.or.jp")) {
				httpGet.addHeader("Referer", "https://www.classnk.or.jp/register/regships/regships.aspx");
			}
			httpGet.setHeader("Cookie", cookies);
			
			HttpResponse response = closeableHttpClient.execute(httpGet);
			
			HttpEntity entity_re = response.getEntity();
			StringBuilder result = new StringBuilder();
		
			if (entity_re != null) {
				InputStream instream = entity_re.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						instream));
				String temp = "";
				while ((temp = br.readLine()) != null) {
					String str = new String(temp.getBytes(), "utf-8");
					result.append(str);
				}
				
			}
			httpGet.releaseConnection();
			return result.toString();
		} catch (IOException e) {
			throw new RuntimeException("请求失败");
		}
	}

	public static String getBackJson(String url) throws RuntimeException{
		HttpGet httpGet = new HttpGet(url);
		try {
			httpGet.setConfig(config);
			StringBuilder result = new StringBuilder();
			setHeader(httpGet);
			httpGet.addHeader("Accept", "application/json, text/javascript, */*; q=0.01");


			HttpResponse httpResponse = closeableHttpClient.execute(httpGet);
			HttpEntity entity_re = httpResponse.getEntity();
			//setHeader(httpGet);
			if (entity_re != null) {
				InputStream instream = entity_re.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(
						instream));
				String temp = "";
				while ((temp = br.readLine()) != null) {
					String str = new String(temp.getBytes(), "utf-8");
					result.append(str);
				}

			}
			httpGet.releaseConnection();
			return result.toString();
		} catch (IOException e) {
			throw new RuntimeException("请求失败");
		}
	}
		
	public static String postBackHtml(String url,
			NameValuePair[] params) throws RuntimeException{
		try {
			HttpPost httpPost = new HttpPost(url);
			setHeader(httpPost);
			List<NameValuePair> formparams = new ArrayList<NameValuePair>();
			for (NameValuePair p : params) {
				formparams.add(p);
			}
			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams,
					"UTF-8");
			httpPost.setEntity(entity);
			HttpResponse response;
			
			response = closeableHttpClient.execute(httpPost);
			
			if(response.getLastHeader("Set-Cookie")!=null){
				String set_cookie = response.getLastHeader("Set-Cookie").getValue();	
				logger.info("cookies:"
						+ set_cookie.substring(0, set_cookie.indexOf(";")));
			}
			
			if (response.getStatusLine().getStatusCode() == 302) {  
				String locationUrl=response.getLastHeader("Location").getValue();  
				httpPost.releaseConnection();
				return getBackHtml(url.substring(0,url.indexOf("com/")+4)+locationUrl);//跳转到重定向的url  
			}else
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("请求失败");
			}
			HttpEntity entity_re = response.getEntity();
			StringBuilder result=new StringBuilder();
			if (entity_re != null) {
				InputStream instream = entity_re.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(instream));
				String temp = "";
				while ((temp = br.readLine()) != null) {
					String str = new String(temp.getBytes(), "utf-8");
					result.append(str);
				}

			}
			httpPost.releaseConnection();
			return result.toString();
		} catch (ClientProtocolException e) {
			return null;
		} catch (IOException e) {
			throw new RuntimeException("连接失败", e);
		}
	}

	public static String postBackHtmlByCookies(String url, NameValuePair[] params, String cookie) {
		try {
			HttpPost httpPost = new HttpPost(url);
			setHeader(httpPost);
			httpPost.addHeader("Cookie", cookie);
			List<NameValuePair> formparams = new ArrayList<NameValuePair>();
			for (NameValuePair p : params) {
				formparams.add(p);
			}
			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, "UTF-8");
			httpPost.setEntity(entity);
			HttpResponse response;

			response = closeableHttpClient.execute(httpPost);

			if (response.getLastHeader("Set-Cookie") != null) {
				String set_cookie = response.getLastHeader("Set-Cookie").getValue();
				logger.info("cookies:" + set_cookie.substring(0, set_cookie.indexOf(";")));
			}
			logger.info(response.getStatusLine().getStatusCode());
			// httpPost.releaseConnection();
			// return getBackHtml(url.substring(0, url.indexOf("com/") + 4) +
			// locationUrl);// 跳转到重定向的url
			// } else if (response.getStatusLine().getStatusCode() != 200) {
			// throw new RuntimeException("请求失败");
			// }
			HttpEntity entity_re = response.getEntity();
			StringBuilder result = new StringBuilder();
			if (entity_re != null) {
				InputStream instream = entity_re.getContent();
				BufferedReader br = new BufferedReader(new InputStreamReader(instream));
				String temp = "";
				while ((temp = br.readLine()) != null) {
					String str = new String(temp.getBytes(), "utf-8");
					result.append(str);
				}

			}

			httpPost.releaseConnection();
			return result.toString();
		} catch (ClientProtocolException e) {
			return null;
		} catch (IOException e) {
			throw new RuntimeException("连接失败", e);
		}
	}
	
	public static HttpPost setHeader(HttpPost httppost) {
		httppost.setConfig(config);
		httppost.addHeader("Connection", "keep-alive");
		httppost.addHeader("Cache-Control", "max-age=0");
		httppost.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		httppost.addHeader("Upgrade-Insecure-Requests", "1");
		httppost.addHeader("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36");
		httppost.addHeader("Accept-Encoding", "gzip, deflate, sdch");
		httppost.addHeader("Accept-Language", "en");
		return httppost;
	}
	
	public static HttpGet setHeader(HttpGet httpGet) {
		httpGet.setConfig(config);
		httpGet.addHeader("Connection", "keep-alive");
		httpGet.addHeader("Cache-Control", "max-age=0");
		httpGet.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		httpGet.addHeader("Upgrade-Insecure-Requests", "1");
		httpGet.addHeader("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36");
		httpGet.addHeader("Accept-Encoding", "gzip, deflate, sdch");
		httpGet.addHeader("Accept-Language", "en");
		return httpGet;
	}
	
	public static void closeClient( ) throws IOException {
		closeableHttpClient.close();
		closeableHttpClient = HttpClientBuilder.create().build();
    }
}
