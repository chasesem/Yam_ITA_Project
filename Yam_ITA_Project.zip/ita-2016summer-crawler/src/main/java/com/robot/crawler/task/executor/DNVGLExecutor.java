package com.robot.crawler.task.executor;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class DNVGLExecutor extends BaseExecutor {
	private final static String SEARCH_URL = "http://vesselregister.dnvgl.com/vesselregister/api/vessel?term=111111&includeHistoricalNames=false&includeNonClass=true&chunkSize=20";
	private final static String Target_URL = "http://vesselregister.dnvgl.com/VesselRegister/api/VesselDetails?what=details&vesselId=";
	private final static String Target_URL1 = "http://vesselregister.dnvgl.com/VesselRegister/api/VesselDetails?what=machinery&vesselId=";
	Result vessel = new Result();

	@Override
	public Result execute(TaskContent task) {

		try {
			String vesselid = searchVelId(task);
			String result = HttpClientUtils.getBackJson(Target_URL + vesselid);
			JSONObject jo = JSONObject.parseObject(result);
			String currentname = jo.getString("Currentname");
			vessel.setName(currentname);
			String IMONo = jo.getString("IMONo");
			vessel.setImo(IMONo);
			String SignalLetters = jo.getString("SignalLetters");
			vessel.setCall_sign(SignalLetters);
			String FlagShortName = jo.getString("FlagShortName");
			vessel.setFlag(FlagShortName);
			String RegistryPort = jo.getString("RegistryPort");
			vessel.setPort(RegistryPort);
			String status = jo.getString("OperationalStatusName");
			vessel.setStatus(status);
			String Owner = jo.getString("OwnerName");//
			vessel.setOwner(Owner);
			String GlType = jo.getString("GlTypeName");//
			vessel.setVsl_type(GlType);
			String Yardname = jo.getString("Yardname");
			vessel.setShipyard(Yardname);
			String Loa = jo.getString("Loa");
			vessel.setLength_in_m(Loa);
			String Bm = jo.getString("Bm");
			vessel.setWidth_in_m(Bm);
			String Draught = jo.getString("Draught");
			vessel.setDraft_in_m(Draught);
			String GrossTon = jo.getString("GrossTon");
			vessel.setGt_in_ton(GrossTon);
			String NetTon = jo.getString("NetTon");
			vessel.setNt_in_ton(NetTon);
			String DeadWeight = jo.getString("DeadWeight");
			vessel.setDwt_on_draft_in_ton(DeadWeight);
			String result1 = HttpClientUtils.getBackJson(Target_URL1 + vesselid);
			HttpClientUtils.closeClient();
			jo = JSONObject.parseObject(result1);
			jo = JSONObject.parseObject(jo.getString("Machinery"));
			JSONArray jsonArray = jo.getJSONArray("Components");
			jo = JSONObject.parseObject(jsonArray.getString(9));
			String Propulsion = jo.getString("ProductName");
			vessel.setMain_engine(Propulsion);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vessel;
	}

	protected String searchVelId(TaskContent task) {// 返回和imo对应的vesselid
		try {
			String result = HttpClientUtils.getBackJson(SEARCH_URL.replace("111111", task.getImo()));
			JSONObject jo = JSONObject.parseObject(result);
			JSONArray jsonArray = jo.getJSONArray("Vessels");
			jo = JSONObject.parseObject(jsonArray.getString(0));
			String vesselid=jo.getString("Id");
			return vesselid;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
