package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class BVExecutor extends BaseExecutor {

	static String INDEX = "http://www.veristar.com/portal/veristarinfo/generalinfo/registers/seaGoingShips";
	static String HOST = "http://www.veristar.com";
	static String SEARCH_URL = "";
	static String DETAIL_URL = "";
	String result;
	@Override
	public Result execute(TaskContent task) throws Exception {
		result=HttpClientUtils.getBackHtml(INDEX);
		SEARCH_URL=result.substring(result.indexOf("action=\"/portal/veristarinfo/generalinfo/registers/seaGoingShips"),result.indexOf("&amp;portal:isSecure=false")+26).substring(8).replace("&amp;", "&");
		
		NameValuePair[] param =new NameValuePair[7];
		param[0] = new BasicNameValuePair("imoNumber", task.getImo());
		param[1] = new BasicNameValuePair("modeAllCriteria", "ture");
		param[2] = new BasicNameValuePair("contains", "true");
		param[3] = new BasicNameValuePair("deadWeightComparator", "0");
		param[4] = new BasicNameValuePair("deadWeightComparator", "0");
		param[4] = new BasicNameValuePair("tonnageComparator", "0");
		param[5] = new BasicNameValuePair("yearOfBuildComparator", "0");
		param[6] = new BasicNameValuePair("lengthComparator", "0");
		result=HttpClientUtils.postBackHtml(HOST+SEARCH_URL,param);
		DETAIL_URL=result.substring(result.lastIndexOf("href=\"/portal/veristarinfo/generalinfo/registers/seaGoingShips"),result.lastIndexOf("&amp;portal:isSecure=false")+26).substring(6).replace("&amp;", "&");
		result=HttpClientUtils.getBackHtml(HOST+DETAIL_URL);
		HttpClientUtils.closeClient();
		return convertHtmlToBean(result);
		
	}
	public Result convertHtmlToBean(String res){
		Document doc=Jsoup.parse(res);
		Element body=doc.body();
		Result v=new Result();
		if(body.getElementsContainingOwnText("IMO Number:").size()>0){
			v.setImo(body.getElementsContainingOwnText("IMO Number:").get(0).nextElementSibling().text());
			v.setName(body.getElementsContainingOwnText("Ship Name:").get(0).nextElementSibling().text());
			v.setCall_sign(body.getElementsContainingOwnText("Call Sign:").get(0).nextElementSibling().text());
			v.setVsl_type(body.getElementsContainingOwnText("Type & service:").get(0).nextElementSibling().text());
			v.setOwner(body.getElementsContainingOwnText("Owner:").get(0).nextElementSibling().text());
			v.setFlag(body.getElementsContainingOwnText("Flag:").get(0).nextElementSibling().text());
			v.setPort(body.getElementsContainingOwnText("Port of Registry:").get(0).nextElementSibling().text());
			v.setGt_in_ton(body.getElementsContainingOwnText("Gross Tonnage").get(0).nextElementSibling().text());
			v.setNt_in_ton(body.getElementsContainingOwnText("Net Tonnage").get(0).nextElementSibling().text());
			v.setDwt_on_draft_in_ton(body.getElementsContainingOwnText("Deadweight:").get(0).nextElementSibling().text());
			v.setLength_in_m(body.getElementsContainingOwnText("Overall Length:").get(0).nextElementSibling().text());
			v.setWidth_in_m(body.getElementsContainingOwnText("Breadth:").get(0).nextElementSibling().text());
			v.setDraft_in_m(body.getElementsContainingOwnText("Draught:").get(0).nextElementSibling().text());
			v.setBuilder(body.getElementsContainingOwnText("Builder:").get(0).nextElementSibling().text());
			v.setBulid_year(body.getElementsContainingOwnText("Date of Build:").get(0).nextElementSibling().text());
			v.setLicence(body.getElementsContainingOwnText("Licence:").get(0).nextElementSibling().text());
			v.setSpeed(body.getElementsContainingOwnText("Speed:").get(0).nextElementSibling().text());
			v.setStatus(body.getElementsContainingOwnText("Status:").get(0).nextElementSibling().text());
		}
		return v;
	}







}
