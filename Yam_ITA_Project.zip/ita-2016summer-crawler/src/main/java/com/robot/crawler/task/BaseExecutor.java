package com.robot.crawler.task;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.model.TaskContent;


public class BaseExecutor implements TaskExecutor {
	protected static Logger logger = LogManager.getLogger(BaseExecutor.class.getName());
	
	public Result execute(TaskContent task) throws Exception{
		// TODO Auto-generated method stub
		return null;
	}

}
