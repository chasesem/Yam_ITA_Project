package com.robot.crawler.jms;


import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import com.robot.crawler.model.App;




public class QueueSender implements Sender{
	
	private Connection connection;
	private Session session;
	private MessageProducer producer;
	
	private volatile static QueueSender queueSender;
	
	private QueueSender(String user,String password,String url,String queueName){
		JMSConnectionFactory factory = new JMSConnectionFactory(user,password,url);
		try {
			connection = factory.getQueueConnection();
			connection.setClientID("output producer"+App.getInstance().getAppId());
			session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);
			Queue queue = session.createQueue(queueName);
			producer = session.createProducer(queue);
			producer.setDeliveryMode(DeliveryMode.PERSISTENT);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static QueueSender getInstance(String user,String password,String url,String queueName){
		if(queueSender==null){
			synchronized(QueueSender.class){
				if(queueSender==null)
					queueSender = new QueueSender(user,password,url,queueName);
			}
		}
		return queueSender;
	}
	
	
	
	public void sendMessage(Message msg) {
		try {
			
			producer.send(msg);
			session.commit();
		} catch (JMSException e) {
			e.printStackTrace();
		} finally{
//				try {
//					if(session!=null)
//					session.close();
//				} catch (JMSException e) {
//					e.printStackTrace();
//				}
			
		}
	}
	
	

	
	
}
