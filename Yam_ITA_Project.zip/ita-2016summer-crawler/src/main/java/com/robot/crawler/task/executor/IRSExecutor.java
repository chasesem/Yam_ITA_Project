package com.robot.crawler.task.executor;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class IRSExecutor extends BaseExecutor {

	static String cookies;
	static String SEARCH_URL = "http://eplan.irclass.org:8090/IRS_Ship_Info.aspx?Imo_no=";
	static String LOGIN_URL = "";
	@Override
	public Result execute(TaskContent task)  throws Exception{
		String result=HttpClientUtils.getBackHtml(SEARCH_URL+task.getImo());
		HttpClientUtils.closeClient();
		return convertHtmlToBean(result);
	}

	public Result convertHtmlToBean(String res){
		Document doc=Jsoup.parse(res);
		Element body=doc.body();
		Result v=new Result();
		v.setOwner(body.getElementsContainingOwnText("Registered Owner").get(0).text().split(":")[1].trim());
		v.setBulid_year(body.getElementsContainingOwnText("Date of Build").get(0).nextElementSibling().text());
		v.setImo(body.getElementsContainingOwnText("IMO Number").get(0).nextElementSibling().text());
		v.setCall_sign(body.getElementsContainingOwnText("Call Sign").get(0).nextElementSibling().text());
		v.setName(body.getElementsContainingOwnText("Ship Name").get(1).nextElementSibling().text());
		v.setPort(body.getElementsContainingOwnText("Port of Registry").get(0).nextElementSibling().text());
		v.setFlag(body.getElementsContainingOwnText("Flag").get(1).nextElementSibling().text());
		v.setBulid_year(body.getElementsContainingOwnText("Date of build").get(0).nextElementSibling().text());
		v.setBuilder(body.getElementsContainingOwnText("Builder").get(0).nextElementSibling().text());
		v.setGt_in_ton(body.getElementsContainingOwnText("Gross Tonnage").get(0).nextElementSibling().text());
		v.setNt_in_ton(body.getElementsContainingOwnText("Net Tonnage").get(0).nextElementSibling().text());
		v.setDwt_on_draft_in_ton(body.getElementsContainingOwnText("Deadweight").get(0).nextElementSibling().text());
		v.setLength_in_m(body.getElementsContainingOwnText("Overall Length").get(0).nextElementSibling().text());
		v.setWidth_in_m(body.getElementsContainingOwnText("Breadth").get(0).nextElementSibling().text());
		v.setDraft_in_m(body.getElementsContainingOwnText("Drought").get(0).nextElementSibling().text());
		v.setVsl_type(body.getElementsContainingOwnText("Ship Type").get(0).nextElementSibling().text());
		v.setMain_engine(body.getElementsContainingOwnText("Main Engine Model").get(0).nextElementSibling().text());
		v.setSpeed(body.getElementsContainingOwnText("Speed").get(0).nextElementSibling().text());
		return v;
	}

}
