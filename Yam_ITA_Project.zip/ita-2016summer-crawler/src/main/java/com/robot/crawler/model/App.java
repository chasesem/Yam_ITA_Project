package com.robot.crawler.model;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class App {
	
	private static String hostName;
	private static String appId;
	
	private static String vAppId;
	
	private App(String appId) throws UnknownHostException{
		App.hostName = InetAddress.getLocalHost().getHostName();
		App.appId = appId;
	}
	
	private volatile static App app;
	
	public static App getInstance(){
		if(app==null){
			synchronized(App.class){
				if(app==null)
					try {
						app = new App(vAppId);
					} catch (UnknownHostException e) {
						e.printStackTrace();
					}
			}
		}
		return app;
	}
	
	public String getHostName() {
		return hostName;
	}
	
	public String getAppId() {
		return appId;
	}

	public static void setvAppId(String mvAppId) {
		vAppId = mvAppId;
	}

}
