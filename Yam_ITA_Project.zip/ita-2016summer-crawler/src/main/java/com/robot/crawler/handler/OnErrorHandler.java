package com.robot.crawler.handler;

public interface OnErrorHandler {
	void handleError();
}
