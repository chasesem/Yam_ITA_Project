package com.robot.crawler.handler;

import com.robot.crawler.excutor.CommandExcetor;
import com.robot.crawler.excutor.Excutor;
import com.robot.crawler.excutor.TaskExcutor;

public class OnMessageHandler {
	
	private Excutor[] executors;
	
	public OnMessageHandler(){
		executors = new Excutor[2];
		executors[0] = new TaskExcutor();
		executors[1] = new CommandExcetor();
	}
	
	//wait for coding better
	public void handlerMessage(String message){
		for(Excutor executor:executors){
			executor.execute(message);
		}
	}

}
