package com.robot.crawler.task.model;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;

public class Task {
	
	@JSONField(serialize=false)  
	public final static String NEW = "NEW";
	@JSONField(serialize=false)  
	public final static String REPROCESS = "REPROCESS";
	@JSONField(serialize=false)  
	public final static String RETRY ="RETRY";
	@JSONField(serialize=false)  
	public final static String I_TRANSLATING = "I_TRANSLATING";
	@JSONField(serialize=false)  
	public final static String I_TRANSLATED_FAIL = "I_TRANSLATED_FAIL";
	@JSONField(serialize=false)  
	public final static String I_TRANSLATED = "I_TRANSLATED";
	@JSONField(serialize=false)  
	public final static String CAPTUREING = "CAPTUREING";
	@JSONField(serialize=false)  
	public final static String CAPTURED_FAIL = "CAPTURED_FAIL";
	@JSONField(serialize=false)  
	public final static String CAPTURED = "CAPTURED";
	@JSONField(serialize=false)  
	public final static String R_TRANSLATING = "R_TRANSLATING";
	@JSONField(serialize=false)  
	public final static String R_TRANSLATED_FAIL = "R_TRANSLATED_FAIL";
	@JSONField(serialize=false)  
	public final static String R_TRANSLATED = "R_TRANSLATED";
	
	private String taskId;
	private String taskContent;
	private String taskStatus;
	private String taskCreateTime;
	private String lastUpdateTime;
	private int reprocesTimes;
	private String sender;
	private int priority;
	
	
	
	public String getTaskId() {
		return taskId;
	}



	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}



	public String getTaskContent() {
		return taskContent;
	}



	public void setTaskContent(String taskContent) {
		this.taskContent = taskContent;
	}



	public String getTaskStatus() {
		return taskStatus;
	}



	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}



	public String getTaskCreateTime() {
		return taskCreateTime;
	}



	public void setTaskCreateTime(String taskCreateTime) {
		this.taskCreateTime = taskCreateTime;
	}



	public String getLastUpdateTime() {
		return lastUpdateTime;
	}



	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}



	public int getReprocesTimes() {
		return reprocesTimes;
	}



	public void setReprocesTimes(int reprocesTimes) {
		this.reprocesTimes = reprocesTimes;
	}



	public String getSender() {
		return sender;
	}



	public void setSender(String sender) {
		this.sender = sender;
	}



	public int getPriority() {
		return priority;
	}



	public void setPriority(int priority) {
		this.priority = priority;
	}



	@Override
	public String toString(){
		return JSON.toJSONString(this).toString();
	}

}
