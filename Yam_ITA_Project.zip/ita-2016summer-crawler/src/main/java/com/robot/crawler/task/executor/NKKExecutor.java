package com.robot.crawler.task.executor;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class NKKExecutor extends BaseExecutor {
	private final static String SEARCH_URL1 = "https://www.classnk.or.jp/register/regships/regships.aspx";
	private final static String SEARCH_URL2 = "https://www.classnk.or.jp/register/regships/search.aspx";
	private final static String TARGET_URL = "https://www.classnk.or.jp/register/regships/one.aspx";
	private final static String PARTCOOKIE = "; style=null; _ga=GA1.3.1728125168.1470929970; _gat=1";
	Result vessel = new Result();

	@Override
	public Result execute(TaskContent task) {

		try {
			String cookie = getCookieAndPost(task);
			String cno = getCno(cookie);
			NameValuePair params[] = new BasicNameValuePair[2];
			params[0] = new BasicNameValuePair("cno_one", cno);
			params[1] = new BasicNameValuePair("from_hp", "yes");
			String result = HttpClientUtils.postBackHtmlByCookies(TARGET_URL, params,
					cookie);			
			HttpClientUtils.closeClient();
			Document doc = Jsoup.parse(result);
			Elements eles = doc.select("table tbody tr td");
			String imo = eles.get(2).text().replace("\u00A0", "");
			vessel.setImo(imo);
			String callSign = eles.get(4).text().replace("\u00A0", "");
			vessel.setCall_sign(callSign);
			String flag = eles.get(5).text().replace("\u00A0", "");
			vessel.setFlag(flag);
			String port = eles.get(6).text().replace("\u00A0", "");
			vessel.setPort(port);
			String name = eles.get(7).text().replace("\u00A0", "");
			vessel.setName(name);
			String registerOwner = eles.get(10).text().replace("\u00A0", "");
			vessel.setRegisteredOwner(registerOwner);
			String type = eles.get(22).text().replace("\u00A0", "");
			vessel.setVsl_type(type);
			String tg = eles.get(32).text().replace("\u00A0", "");
			vessel.setGt_in_ton(tg);
			String tn = eles.get(33).text().replace("\u00A0", "");
			vessel.setNt_in_ton(tn);
			String deadWeight = eles.get(34).text().replace("\u00A0", "");
			vessel.setDwt_on_draft_in_ton(deadWeight);
			String draught = eles.get(37).text().replace("\u00A0", "");// /
			vessel.setDraft_in_m(draught);
			String speed = eles.get(39).text().replace("\u00A0", "");// /
			vessel.setSpeed(speed);
			String loa = eles.get(42).text().replace("\u00A0", "");// /
			vessel.setLength_in_m(loa);
			String width = eles.get(43).text().split(" x ")[1];// / split
			vessel.setWidth_in_m(width);
			String tf_eu = eles.get(46).text().replace("\u00A0", "");
			String teu = tf_eu.substring(tf_eu.indexOf("TEU") + 4,
					tf_eu.indexOf("TEU") + 9);
			vessel.setTeu(teu);
			if (2 != tf_eu.split("FEU").length) {//要有两个FEU才行,取第一个
				String feu = tf_eu.substring(tf_eu.indexOf("FEU") + 4,
						tf_eu.indexOf("FEU") + 9);
				vessel.setFeu_max(feu);
			}
			String shipBuilder = eles.get(71).text().replace("\u00A0", "");
			vessel.setShipyard(shipBuilder);
			String buildyear = eles.get(75).text().replace("\u00A0", "");
			vessel.setBulid_year(buildyear);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vessel;
	}

	protected String getCno(String cookie) {// 得到与IMO对应的cno
		try {
			String cnoPage = HttpClientUtils.getBackHtmlByCookies(SEARCH_URL2,
					cookie);
			Document doc1 = Jsoup.parse(cnoPage);
			logger.info(doc1.title());
			Element cnoEle = doc1.select("table[class$=line0 directory]")
					.select("tbody tr td").get(0);
			String cno = cnoEle.text().substring(0, 6);
			return cno;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	protected String getCookieAndPost(TaskContent task) {// 通过get取得cookie，再post SEARCH_URL1
		try {
			List<String> list = HttpClientUtils.getCookiesAndHtml(SEARCH_URL1);
			String cookie = list.get(0) + PARTCOOKIE;
			String result = list.get(1);
			Document doc = Jsoup.parse(result);
			Element ele = doc.select("input[id$=__VIEWSTATE]").first();
			String VIEWSTATE = ele.attr("value");
			ele = doc.select("input[id$=__EVENTVALIDATION]").first();
			String EVENTVALIDATION = ele.attr("value");
			NameValuePair params[] = new BasicNameValuePair[5];
			params[0] = new BasicNameValuePair("TextBox_imo", task.getImo());
			params[1] = new BasicNameValuePair("__EVENTTARGET",
					"LinkButton_Search");
			params[2] = new BasicNameValuePair("__EVENTVALIDATION",
					EVENTVALIDATION);
			params[3] = new BasicNameValuePair("__VIEWSTATE", VIEWSTATE);
			params[4] = new BasicNameValuePair("__VIEWSTATEGENERATOR",
					"7543ADFF");
			HttpClientUtils.postBackHtmlByCookies(SEARCH_URL1, params, cookie);
			return cookie;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
