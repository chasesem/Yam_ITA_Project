package com.robot.crawler.task.executor;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;

public class EquasisExecutor extends BaseExecutor {
	private final static String LOGIN_URL = "http://www.equasis.org/EquasisWeb/authen/HomePage?fs=HomePage";
	private final static String Target_URL = "http://www.equasis.org/EquasisWeb/restricted/ShipList?fs=ShipSearch";

	@Override
	public Result execute(TaskContent task) {
		Result vessel = new Result();
		try {
			login();
			String targetPage=search(task);
			HttpClientUtils.closeClient();
			Document doc=Jsoup.parse(targetPage);
			Elements eles=doc.select(".encart tbody tr td");
			String imo=eles.get(1).text();
			vessel.setImo(imo);
			String nameofship=eles.get(3).text();
			vessel.setName(nameofship);
			String callsign=eles.get(6).text();
			vessel.setCall_sign(callsign);
			String mmsi=eles.get(8).text();
			vessel.setMmsi(mmsi);
			String gt=eles.get(11).text();
			vessel.setGt_in_ton(gt);
			String dwt=eles.get(14).text();
			vessel.setDwt_on_draft_in_ton(dwt);
			String type=eles.get(16).text();
			vessel.setVsl_type(type);
			String buildyear=eles.get(19).text();
			vessel.setBulid_year(buildyear);
			String flag=eles.get(21).text();
			vessel.setFlag(flag);
			String status=eles.get(24).text();
			vessel.setStatus(status);
			String nest=eles.get(4).text();
			vessel.setEft_st_dt(nest);
			eles=doc.select("#bloc .tab").get(1).select("tbody").get(2).select("tr").get(4).select("td");//.get(1).select("tbody").select("tr").get(4).select("td");12
			String registeredOwner=eles.get(2).text();
			vessel.setRegisteredOwner(registeredOwner);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vessel;
	}

	protected void login() {
		try {
			NameValuePair params[] = new BasicNameValuePair[2];
			params[0] = new BasicNameValuePair("j_email",
					"howardztark@gmail.com");
			params[1] = new BasicNameValuePair("j_password", "Ironman201");
			HttpClientUtils.postBackHtml(LOGIN_URL, params);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected String search(TaskContent task) {
		try {
			NameValuePair params[] = new BasicNameValuePair[3];
			params[0] = new BasicNameValuePair("P_IMO",
					task.getImo() != null ? task.getImo() : "");
			params[1] = new BasicNameValuePair("P_PAGE", "1");
			params[2] = new BasicNameValuePair("Submit", "SEARCH");
			String result = HttpClientUtils.postBackHtml(Target_URL, params);
			logger.info(result);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
