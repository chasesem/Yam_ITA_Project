package com.robot.crawler.excutor;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TaskExcutor implements Excutor{
	
	private final static Logger logger = LogManager.getLogger(TaskExcutor.class);
	
	public void execute(String message){
		logger.info("get task:"+message);
	}

	

}
