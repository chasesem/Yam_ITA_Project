package com.robot.crawler.websocket.core;

import java.io.IOException;
import java.net.URI;
import java.util.UUID;

import javax.websocket.ContainerProvider;
import javax.websocket.DeploymentException;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WebsocketClientApp {
	
	private final static Logger logger = LogManager.getLogger(WebsocketClientApp.class);
	
	private  Session session;
	
	private String nodeId;
	private int nodeCode;
	private String baseuri = "ws://localhost:8080/JAHub/connection/";
	private String uri;
	
	private volatile static WebsocketClientApp clientApp = null;
	
	private WebsocketClientApp(){
		nodeId= UUID.randomUUID().toString();
		nodeCode = 1;
		uri = baseuri+nodeId+"/"+nodeCode;
	}
	
	public static WebsocketClientApp getInstance(){
		if(clientApp==null){
			 synchronized (WebsocketClientApp.class){
				 if(clientApp == null){
					 clientApp = new WebsocketClientApp();
				 }
			 }
		}
		return clientApp;
	}
	
	public void start() {
		WebSocketContainer container = ContainerProvider.getWebSocketContainer();
		try {
			session = container.connectToServer(WebsocketClient.class, URI.create(uri));
		} catch (DeploymentException e) {
			logger.error("start error",e);
		} catch (IOException e) {
			logger.error("start error",e);
		}
	}
	
	public void restart(){
		WebSocketContainer container = ContainerProvider.getWebSocketContainer();
		try {
			session.close();
			try {
				session = container.connectToServer(WebsocketClient.class, URI.create(uri));
			} catch (DeploymentException e) {
				logger.error("restart error",e);
			}
		} catch (IOException e) {
			logger.error("restart error",e);
		}
	}
	
	public void stop(){
		try {
			session.close();
		} catch (IOException e) {
			logger.error("close error",e);
		}
	}
	
	public Session getSession(){
		return session;
	}

}
