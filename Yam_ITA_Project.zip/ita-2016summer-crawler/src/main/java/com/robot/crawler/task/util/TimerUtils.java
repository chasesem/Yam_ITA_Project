package com.robot.crawler.task.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimerUtils {

	static SimpleDateFormat FleetMon_FORMAT = new SimpleDateFormat(
			"MM dd, yyyy 'at' HH:mm");
	static SimpleDateFormat Standard_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd'T'HH:mm:ss");

	public static boolean isWithinTime(String comparingTime, String beginTime)
			throws ParseException {

		Date dateTime = Standard_FORMAT.parse(comparingTime);
		Date fromTime = Standard_FORMAT.parse(beginTime);
		if (dateTime.after(fromTime)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean fleetMoncompare(String publishTime, String beginTime)
			throws ParseException {
		String time = publishTime.replace(publishTime.split(" ")[0],
				MonthToNum(publishTime) + "");
		Date date = FleetMon_FORMAT.parse(time);
		String comparingTime = Standard_FORMAT.format(date);

		return isWithinTime(comparingTime, beginTime);
	}

	public static String getbeginTime(int hours) throws ParseException {

		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY) - hours);
		String beginTime = Standard_FORMAT.format(cal.getTime());
		return beginTime;
	}

	public static String getTime() {

		Calendar cal = Calendar.getInstance();
		String currentTime = Standard_FORMAT.format(cal.getTime());
		return currentTime;
	}

	public static String fleetMonParse(String publishTime)
			throws ParseException {
		String dateTime1 = publishTime.replace(publishTime.split(" ")[0],
				MonthToNum(publishTime) + "");
		Date date = FleetMon_FORMAT.parse(dateTime1);
		String standardTime = Standard_FORMAT.format(date);
		return standardTime;
	}

	public static String vslTrackerParse(String publishTime)
			throws ParseException {

		int pTime = Integer.parseInt(publishTime.substring(0, 2).trim());
		Calendar cal = Calendar.getInstance();
		int pastType = getPastType(publishTime);
		switch (pastType) {
		case 0:
			cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) - pTime);
			break;
		case 1:
			cal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY) - pTime);
			break;
		case 2:
			cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH)
					- pTime);
			break;
		}
		String standardTime = Standard_FORMAT.format(cal.getTime());
		return standardTime;
	}

	public static int getPastType(String publishTime) {

		if (publishTime.contains("min")) {
			return 0;
		} else if (publishTime.contains("hour")) {
			return 1;
		} else {
			return 2;
		}

	}

	public static int MonthToNum(String publishTime) {

		String month = publishTime.substring(0, 3).toLowerCase();
		switch (month) {

		case "jan":
			return 1;
		case "feb":
			return 2;
		case "mar":
			return 3;
		case "apr":
			return 4;
		case "may":
			return 5;
		case "jun":
			return 6;
		case "jul":
			return 7;
		case "aug":
			return 8;
		case "sep":
			return 9;
		case "oct":
			return 10;
		case "nov":
			return 11;
		case "dec":
			return 12;

		}
		return 0;
	}
}
