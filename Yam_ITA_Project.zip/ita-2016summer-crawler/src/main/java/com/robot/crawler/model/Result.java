package com.robot.crawler.model;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSON;

public class Result {

	private String imo;
	private String bulid_year;
	private String status;
	private String remark;

	private String gs_name;
	private String vsl_code;
	private String vsl_type;

	private String width_in_m;
	private String length_in_m;
	private String ais_dim_a_in_m;
	private String ais_dim_b_in_m;
	private String ais_dim_c_in_m;
	private String ais_dim_d_in_m;

	private String gt_in_ton;
	private String nt_in_ton;
	private String dwt_on_draft_in_ton;
	private String draft_in_m;
	private String teu;
	private String teu14;
	private String feu_max;

	private String ice_class;
	private String main_engine;
	private String shipyard;
	// /
	private String name;
	private String call_sign;
	private String flag;
	private String port;
	private String owner;
	// / 第二次加
	private String builder;
	private String deliveryDate;
	private String engineManufacturer;
	private String registeredOwner;
	private String speed;
	// junming
	private String builder_place;
	private String licence;
	private String manager;
	private String automatic_identification_system;
	// 第三次
	private String mmsi;
	private String eft_st_dt;
	
	//news
	private List<Article> articles = new ArrayList<Article>();
	
	private String type;
	private String lastKnownPosition;
	private String lastKnownPositionDateTime;
	private String position;
	private String isExcavated;

	public String getEft_st_dt() {
		return eft_st_dt;
	}

	public void setEft_st_dt(String eft_st_dt) {
		this.eft_st_dt = eft_st_dt;
	}

	public String getMmsi() {
		return mmsi;
	}

	public void setMmsi(String mmsi) {
		this.mmsi = mmsi;
	}

	public String getBuilder_place() {
		return builder_place;
	}

	public void setBuilder_place(String builder_place) {
		this.builder_place = builder_place;
	}

	public String getLicence() {
		return licence;
	}

	public void setLicence(String licence) {
		this.licence = licence;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getAutomatic_identification_system() {
		return automatic_identification_system;
	}

	public void setAutomatic_identification_system(
			String automatic_identification_system) {
		this.automatic_identification_system = automatic_identification_system;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public String getRegisteredOwner() {
		return registeredOwner;
	}

	public void setRegisteredOwner(String registeredOwner) {
		this.registeredOwner = registeredOwner;
	}

	public String getEngineManufacturer() {
		return engineManufacturer;
	}

	public void setEngineManufacturer(String engineManufacturer) {
		this.engineManufacturer = engineManufacturer;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getBuilder() {
		return builder;
	}

	public void setBuilder(String builder) {
		this.builder = builder;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getCall_sign() {
		return call_sign;
	}

	public void setCall_sign(String call_sign) {
		this.call_sign = call_sign;
	}

	public String getImo() {
		return imo;
	}

	public void setImo(String imo) {
		this.imo = imo;
	}

	public String getBulid_year() {
		return bulid_year;
	}

	public void setBulid_year(String bulid_year) {
		this.bulid_year = bulid_year;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getGs_name() {
		return gs_name;
	}

	public void setGs_name(String gs_name) {
		this.gs_name = gs_name;
	}

	public String getVsl_code() {
		return vsl_code;
	}

	public void setVsl_code(String vsl_code) {
		this.vsl_code = vsl_code;
	}

	public String getVsl_type() {
		return vsl_type;
	}

	public void setVsl_type(String vsl_type) {
		this.vsl_type = vsl_type;
	}

	public String getWidth_in_m() {
		return width_in_m;
	}

	public void setWidth_in_m(String width_in_m) {
		this.width_in_m = width_in_m;
	}

	public String getLength_in_m() {
		return length_in_m;
	}

	public void setLength_in_m(String length_in_m) {
		this.length_in_m = length_in_m;
	}

	public String getAis_dim_a_in_m() {
		return ais_dim_a_in_m;
	}

	public void setAis_dim_a_in_m(String ais_dim_a_in_m) {
		this.ais_dim_a_in_m = ais_dim_a_in_m;
	}

	public String getAis_dim_b_in_m() {
		return ais_dim_b_in_m;
	}

	public void setAis_dim_b_in_m(String ais_dim_b_in_m) {
		this.ais_dim_b_in_m = ais_dim_b_in_m;
	}

	public String getAis_dim_c_in_m() {
		return ais_dim_c_in_m;
	}

	public void setAis_dim_c_in_m(String ais_dim_c_in_m) {
		this.ais_dim_c_in_m = ais_dim_c_in_m;
	}

	public String getAis_dim_d_in_m() {
		return ais_dim_d_in_m;
	}

	public void setAis_dim_d_in_m(String ais_dim_d_in_m) {
		this.ais_dim_d_in_m = ais_dim_d_in_m;
	}

	public String getGt_in_ton() {
		return gt_in_ton;
	}

	public void setGt_in_ton(String gt_in_ton) {
		this.gt_in_ton = gt_in_ton;
	}

	public String getNt_in_ton() {
		return nt_in_ton;
	}

	public void setNt_in_ton(String nt_in_ton) {
		this.nt_in_ton = nt_in_ton;
	}

	public String getDwt_on_draft_in_ton() {
		return dwt_on_draft_in_ton;
	}

	public void setDwt_on_draft_in_ton(String dwt_on_draft_in_ton) {
		this.dwt_on_draft_in_ton = dwt_on_draft_in_ton;
	}

	public String getDraft_in_m() {
		return draft_in_m;
	}

	public void setDraft_in_m(String draft_in_m) {
		this.draft_in_m = draft_in_m;
	}

	public String getTeu() {
		return teu;
	}

	public void setTeu(String teu) {
		this.teu = teu;
	}

	public String getTeu14() {
		return teu14;
	}

	public void setTeu14(String teu14) {
		this.teu14 = teu14;
	}

	public String getFeu_max() {
		return feu_max;
	}

	public void setFeu_max(String feu_max) {
		this.feu_max = feu_max;
	}

	public String getIce_class() {
		return ice_class;
	}

	public void setIce_class(String ice_class) {
		this.ice_class = ice_class;
	}

	public String getMain_engine() {
		return main_engine;
	}

	public void setMain_engine(String main_engine) {
		this.main_engine = main_engine;
	}

	public String getShipyard() {
		return shipyard;
	}

	public void setShipyard(String shipyard) {
		this.shipyard = shipyard;
	}

	public List<Article> getArticles() {
		return articles;
	}

	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}
	
	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLastKnownPosition() {
		return lastKnownPosition;
	}

	public void setLastKnownPosition(String lastKnownPosition) {
		this.lastKnownPosition = lastKnownPosition;
	}

	public String getLastKnownPositionDateTime() {
		return lastKnownPositionDateTime;
	}

	public void setLastKnownPositionDateTime(String lastKnownPositionDateTime) {
		this.lastKnownPositionDateTime = lastKnownPositionDateTime;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getIsExcavated() {
		return isExcavated;
	}

	public void setIsExcavated(String isExcavated) {
		this.isExcavated = isExcavated;
	}

	public String toJSONString() {
		return JSON.toJSONString(this).toString();
	}
}
