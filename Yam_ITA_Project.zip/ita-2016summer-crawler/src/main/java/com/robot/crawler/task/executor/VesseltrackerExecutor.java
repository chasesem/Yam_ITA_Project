package com.robot.crawler.task.executor;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.robot.crawler.model.Article;
import com.robot.crawler.model.Event;
import com.robot.crawler.model.Port;
import com.robot.crawler.model.Result;
import com.robot.crawler.task.BaseExecutor;
import com.robot.crawler.task.model.TaskContent;
import com.robot.crawler.task.util.HttpClientUtils;
import com.robot.crawler.task.util.TimerUtils;



public class VesseltrackerExecutor extends BaseExecutor {
	private final static String NEWS_URL = "http://www.vesseltracker.com/en/NewsHome.html?hours=11&hide=false";
	private final static String HOME_URL = "http://www.vesseltracker.com";
	Result vessel = new Result();

	@Override
	public Result execute(TaskContent task) {
		try {
			List<Article> articleList = new ArrayList<Article>();
			String result = HttpClientUtils.getBackHtml(NEWS_URL.replace("11", task.getWithinHour() + ""));
			Document doc = Jsoup.parse(result);
			Elements eles = doc.select("#theForm_2").get(0).children();
			int num = eles.size() - 3;
			for (int i = 3; i <= num; i++) {
				String vslType = eles.get(i).select(".newTitleBalk_middle").select("div").get(1).ownText();
				Article article = new Article();
				if (vslType.length() != 1) {
					article = parseEachVslNew(eles.get(i));
				} else {
					article = parseEachPortNew(eles.get(i));
				}
				article.setSource("Vesseltracker");
				articleList.add(article);
			}
			vessel.setArticles(articleList);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return vessel;

	}

	protected Article parseEachVslNew(Element newsEle) {//
		try {
			Article article = new Article();
			Result vessel = new Result();
			Event event = new Event();
			String articleId = newsEle.html().split("--")[1].replace(",", "").replace(" ", "");
			article.setArticleId(articleId);
			String velName = newsEle.select(".newTitleBalk_middle").select("a").get(0).text();//
			vessel.setName(velName);
			String vslType = newsEle.select(".newTitleBalk_middle").select("div").get(1).ownText().replace("(", "")
					.replace(")", "").replace("  ", "").trim();
			vessel.setType(vslType);
			String flag = newsEle.select(".newTitleBalk_middle").select("img").get(1).attr("title");
			vessel.setFlag(flag);
			String url = HOME_URL + newsEle.select(".newTitleBalk_middle").select("a").get(0).attr("href");
			String imo = url.substring(url.indexOf("html") - 8, url.indexOf("html") - 1);
			vessel.setImo(imo);
			article.setVessel(vessel);
			article.setUrl(url);
			String category = newsEle.select(".newTitleBalk_middle").select("img").get(0).attr("title");
			article.setCategory(category);
			String publishTime = newsEle.select("nobr").get(0).ownText();
			String publishDatetime = TimerUtils.vslTrackerParse(publishTime);

			article.setPublishDateTime(publishDatetime);
			event.setEventDateTime(publishDatetime);
			article.setEvent(event);

			String author = newsEle.select(".newTitleBalk_middle").select("a").get(1).text();
			article.setAuthor(author);
			String title = newsEle.child(5).select("div").get(1).ownText();
			article.setHeadline(title);
			String content = newsEle.child(5).ownText();
			article.setBodyPreview(content);
			article.setBody(content);
			return article;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	protected Article parseEachPortNew(Element newsEle) {//
		try {
			Article article = new Article();
			Event event = new Event();
			Port port = new Port();
			String portName = newsEle.select(".newTitleBalk_middle").select("a").get(0).text();//
			port.setName(portName);
			String flag = newsEle.select(".newTitleBalk_middle").select("img").get(1).attr("title");
			port.setFlag(flag);
			article.setPort(port);
			String articleId = newsEle.html().split("--")[1].replace(",", "").replace(" ", "");
			article.setArticleId(articleId);
			String url = HOME_URL + newsEle.select(".newTitleBalk_middle").select("a").get(0).attr("href");
			article.setUrl(url);

			String publishTime = newsEle.select("nobr").get(0).ownText();
			String publishDatetime = TimerUtils.vslTrackerParse(publishTime);

			article.setPublishDateTime(publishDatetime);
			event.setEventDateTime(publishDatetime);
			article.setEvent(event);

			String author = newsEle.select(".newTitleBalk_middle").select("a").get(1).text();
			article.setAuthor(author);
			String title = newsEle.child(5).select("div").get(1).ownText();
			article.setHeadline(title);
			String content = newsEle.child(5).ownText();
			article.setBodyPreview(content);
			article.setBody(content);
			return article;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
