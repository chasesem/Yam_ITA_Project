package com.robot.crawler.jms;


import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicSubscriber;



public class TopicRecevier {
	
	private String topicName;
	private  Connection connection;
	
	private final static String clientID = "66666";
	private final static String name = "heloworld";
	
	public TopicRecevier(Connection connection,String topicName){
		this.connection = connection; 
		this.topicName = topicName; 
	}
	
	public  void recevieMessage() throws JMSException{
		try {
			
			connection.setClientID(clientID);
			connection.start();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Topic topic = session.createTopic(topicName);
			TopicSubscriber subscriber = session.createDurableSubscriber(topic,name);
			subscriber.setMessageListener(new OnJMSMessageHandler());
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
	
	
}
