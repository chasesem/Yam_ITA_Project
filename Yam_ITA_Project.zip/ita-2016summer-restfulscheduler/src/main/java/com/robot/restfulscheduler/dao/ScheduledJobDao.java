package com.robot.restfulscheduler.dao;

import java.util.List;

import com.robot.restfulscheduler.model.ScheduledJob;

public interface ScheduledJobDao {
	List<ScheduledJob> findAll();
	void save(ScheduledJob scheduledJob);
	boolean delete(String id);
	boolean update(ScheduledJob scheduledJob);
	List<ScheduledJob> findMsgByStatus(String status);
	public ScheduledJob findOne(String id);

}
