package com.robot.restfulscheduler.jersey;

import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.robot.restfulscheduler.dao.ScheduledJobDao;
import com.robot.restfulscheduler.dao.ScheduledJobDaoImpl;
import com.robot.restfulscheduler.model.ScheduledJob;

@Path("/update")
public class JobUpdate {
private ScheduledJobDao scheduledJobDao;
	public JobUpdate(){
		scheduledJobDao = new ScheduledJobDaoImpl();
	}
	
	@POST
	@Path("/job")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String update(String job){
		System.out.println(job);
		ScheduledJob sJob=new ScheduledJob();
		ScheduledJob scheduledJob = JSON.parseObject(job, ScheduledJob.class);
		sJob=scheduledJobDao.findOne(scheduledJob.getJobId());
		sJob.setJobContent(scheduledJob.getJobContent());
		sJob.setJobLastUpdateTime(new Date());
		sJob.setJobType(scheduledJob.getJobType());
		sJob.setStatus(scheduledJob.getStatus());
		sJob.setIntervalTime(scheduledJob.getIntervalTime());
		scheduledJobDao.update(sJob);
		return "{\"operation\":\"success\"}";
	}
}
