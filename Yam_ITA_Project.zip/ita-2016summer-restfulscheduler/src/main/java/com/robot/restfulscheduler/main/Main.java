package com.robot.restfulscheduler.main;

import java.io.IOException;
import java.net.URI;

import javax.ws.rs.core.UriBuilder;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

public class Main 
{

	@SuppressWarnings("unused")
	public static void main(String args[]) throws IllegalArgumentException, IOException{
		
		URI baseUri = UriBuilder.fromUri("http://127.0.0.1").port(8071).build();
		 ResourceConfig config = new ResourceConfig().packages("com.robot.restfulscheduler.jersey");
	     HttpServer server  = GrizzlyHttpServerFactory.createHttpServer(baseUri,config); 
	     System.out.println("restScheduler");  
	}

}
