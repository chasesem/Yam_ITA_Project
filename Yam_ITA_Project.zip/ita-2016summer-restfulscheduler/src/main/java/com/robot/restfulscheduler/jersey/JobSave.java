package com.robot.restfulscheduler.jersey;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.robot.restfulscheduler.dao.ScheduledJobDao;
import com.robot.restfulscheduler.dao.ScheduledJobDaoImpl;
import com.robot.restfulscheduler.model.ScheduledJob;

@Path("/save")
public class JobSave {
	private ScheduledJobDao scheduledJobDao;
	
	public JobSave(){
		scheduledJobDao = new ScheduledJobDaoImpl();
	}
	
	@POST
	@Path("/job")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String save(String job){
		ScheduledJob scheduledJob = JSON.parseObject(job, ScheduledJob.class);
		scheduledJobDao.save(scheduledJob);
		return "{\"operation\":\"success\"}";
	}
}
