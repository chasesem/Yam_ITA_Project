package com.robot.restfulscheduler.dao;

import com.mongodb.client.MongoDatabase;

public class BasicDao {
	private MongoDatabase dataBase;
	
	public BasicDao(){
		dataBase = DataSource.getInstance().getDatabase();
	}
	public MongoDatabase getDataBase(){
		return dataBase;
	}
}
