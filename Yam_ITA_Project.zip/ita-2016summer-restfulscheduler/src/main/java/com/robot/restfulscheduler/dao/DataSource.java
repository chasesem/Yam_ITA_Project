package com.robot.restfulscheduler.dao;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;

public class DataSource {
	
	private final static String HOST = "10.222.232.40";
	private final static int PORT = 27017;
	private final static String DB_NAME = "controller";
	
	private MongoClient client;
	private MongoDatabase database;
	
	private volatile static DataSource dataSource = null;
	
	private  DataSource(){
		client = new MongoClient(new MongoClientURI("mongodb://"+HOST+":"+PORT));
		database = client.getDatabase(DB_NAME);
	}
	
	public static DataSource getInstance(){
		if(dataSource==null){
			synchronized(DataSource.class){
				if(dataSource==null){
					dataSource = new DataSource();
				}
			}
		}
		
		return dataSource;
	}
	
	public MongoDatabase getDatabase(){
		return database;
	}
}
