package com.robot.restfulscheduler.jersey;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.robot.restfulscheduler.dao.ScheduledJobDao;
import com.robot.restfulscheduler.dao.ScheduledJobDaoImpl;
import com.robot.restfulscheduler.model.ScheduledJob;

@Path("/jobs")
public class JobGet {
	private ScheduledJobDao scheduledJobDao;
	
	public JobGet(){
		scheduledJobDao = new ScheduledJobDaoImpl();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/all")
	public String getJob(){
		List<ScheduledJob> scheduledJobList = scheduledJobDao.findAll();
		return JSON.toJSONString(scheduledJobList);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/finMsgByStatus/{status}")
	public String findMsg(@PathParam("status")  String status){
		List<ScheduledJob> scheduledJobList = scheduledJobDao.findMsgByStatus(status);
		return JSON.toJSONString(scheduledJobList);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/findOne/{id}")
	public String findOne(@PathParam("id")  String id){
		ScheduledJob scheduledJob = scheduledJobDao.findOne(id);
		return JSON.toJSONString(scheduledJob);
	}
	
	
}
