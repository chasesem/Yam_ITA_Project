package com.robot.restfulscheduler.dao;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.robot.restfulscheduler.model.ScheduledJob;


public class ScheduledJobDaoImpl extends BasicDao implements ScheduledJobDao{
	private final static String TABLE_NAME = "scheduledJob";
	MongoCollection<Document> collection;
	public ScheduledJobDaoImpl(){
		super();
		collection = getDataBase().getCollection(TABLE_NAME);
	}
	
	public List<ScheduledJob> findAll(){
		List<Document> documents = collection.find().into(new ArrayList<Document>());
		List<ScheduledJob>  taskList = new ArrayList<ScheduledJob>();
		for(Document document:documents){
			taskList.add(toTask(document));
		}
		return taskList;
	}
	
	public void save(ScheduledJob scheduledJob){
		collection.insertOne(toDocument(scheduledJob));
	}
	public boolean delete(String id) {
		BasicDBObject doc = new BasicDBObject("_id", new ObjectId(id));
		try {
			collection.findOneAndDelete(doc);
			//collection.deleteOne(Filters.eq("id", id));
			return true;  
		} catch (Exception e) {
			// TODO: handle exception
			return false;  
		}
	}
	public boolean update(ScheduledJob scheduledJob){
		Document document = toDocument(scheduledJob);
		//Document document = collection.find(eq("_id",scheduledJob.getJobId())).first();
		
		try {
			collection.replaceOne(eq("_id",scheduledJob.getJobId()), document);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	public ScheduledJob findOne(String id) {
		Document document = collection.find(eq("_id",new ObjectId(id))).first();
		ScheduledJob scheduledJob=toTask(document);
		return scheduledJob;
	}

	private ScheduledJob toTask(Document document) {
		ScheduledJob scheduledJob = new ScheduledJob();
		scheduledJob.setJobId(document.getObjectId("_id").toString());
		scheduledJob.setProjectOwner(document.getString("projectOwner"));
		scheduledJob.setJobContent(document.getString("jobContent"));
		scheduledJob.setJobCreateTime(document.getDate("jobCreateTime"));
		scheduledJob.setJobCreator(document.getString("jobCreator"));
		scheduledJob.setJobLastUpdateTime(document.getDate("jobLastUpdateTime"));
		scheduledJob.setJobType(document.getString("jobType"));
		scheduledJob.setIntervalTime(document.getString("intervalTime"));
		scheduledJob.setStatus(document.getString("status"));
		return scheduledJob;
	}
	
	private Document toDocument(ScheduledJob scheduledJob){
		Document document = new Document();
		document.append("projectOwner", scheduledJob.getProjectOwner());
		document.append("jobContent", scheduledJob.getJobContent());
		document.append("jobCreateTime", scheduledJob.getJobCreateTime());
		document.append("jobCreator", scheduledJob.getJobCreator());
		document.append("jobLastUpdateTime", scheduledJob.getJobLastUpdateTime());
		document.append("jobType", scheduledJob.getJobType());
		document.append("intervalTime", scheduledJob.getIntervalTime());
		document.append("status", scheduledJob.getStatus());
		return document;
	}

	public List<ScheduledJob> findMsgByStatus(String status) {
		// TODO Auto-generated method stub
			List<Document> documents=collection.find(Filters.eq("status", status)).into(new ArrayList<Document>());
			List<ScheduledJob>  taskList = new ArrayList<ScheduledJob>();
			for(Document document:documents){
				taskList.add(toTask(document));
			}
			return taskList;
	}


	

}
