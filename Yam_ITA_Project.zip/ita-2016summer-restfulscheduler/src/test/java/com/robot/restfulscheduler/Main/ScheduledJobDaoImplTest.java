package com.robot.restfulscheduler.Main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.robot.restfulscheduler.dao.ScheduledJobDaoImpl;
import com.robot.restfulscheduler.model.JobContent;
import com.robot.restfulscheduler.model.ScheduledJob;

import junit.framework.TestCase;

public class ScheduledJobDaoImplTest extends TestCase {
   ScheduledJobDaoImpl sDaoImpl=new ScheduledJobDaoImpl();
	protected void setUp() throws Exception {
		super.setUp();
	}

//	public void testScheduledJobDaoImpl() {
////		boolean result=false;
////		result=sDaoImpl.delete("1");
////		if (result) {
////			System.out.println("delete succ");
////		}else{
////			System.out.println("delete fail");
////		}
//		//////////////////////////////////////
//		System.out.println("dfs");
//		ScheduledJob job=new ScheduledJob();
		//job.setIntervalTime();
//		job.setJobContent("test1");
//		job.setJobCreateTime(new Date());
//		job.setJobCreator("test1");
//		job.setJobId("8");
//		job.setJobLastUpdateTime(new Date());
//		job.setJobType("test1");
//		job.setProjectOwner("test1");
//		job.setStatus("test1");
//		job=sDaoImpl.findOne("8");
//		job.setJobLastUpdateTime(new Date());
//		sDaoImpl.update(job);
//	}


//	public void testFindAll() {
//		//List<ScheduledJob> list=new ArrayList<ScheduledJob>();
//		ScheduledJob scheduledJob=sDaoImpl.findOne("57e2738f9d77cb3e245bce09");
//		System.out.println("hhhh::"+scheduledJob.getStatus());
//	
//	}
	

	public void testSave() throws ParseException {
		System.out.println("dfsdfasdf");
		SimpleDateFormat sdf =  new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
		Date date = sdf.parse("2016-09-18 12:10:12");
		Date date1 = sdf.parse("2016-09-19 13:13:12");
		ScheduledJob job=new ScheduledJob();
		JobContent jobContent=new JobContent();
		jobContent.setCategory("Europe");
		jobContent.setSender("Scheduler");
		job.setIntervalTime("60seconds");
		job.setJobContent(jobContent.toString());
		job.setJobCreateTime(date);
		job.setJobCreator("grace");
		//job.setJobId("12");
		job.setJobLastUpdateTime(date1);
		job.setJobType("WebCapture");
		job.setProjectOwner("swindy");
		job.setStatus("DISABLE");
		sDaoImpl.save(job);
	}
	

}
